#pragma once
#include <stdint.h>

/*
 * Butterworth lowpass coefficients exported from Python csi_preprocessing.py:
 * signal.butter(order=8, Wn=20/(100/2), btype="lowpass")
 * Used by MCU filtfilt implementation to approximate scipy.signal.filtfilt(b, a, x).
 */
#define UI_FILTER_NTAPS       9
#define UI_FILTER_STATE_LEN   8
#define UI_FILTER_PADLEN      27

static const float ui_filter_b[UI_FILTER_NTAPS] = {
    0.002271840323f,
    0.01817472258f,
    0.06361152902f,
    0.1272230580f,
    0.1590288225f,
    0.1272230580f,
    0.06361152902f,
    0.01817472258f,
    0.002271840323f
};

static const float ui_filter_a[UI_FILTER_NTAPS] = {
    1.000000000f,
   -1.590566497f,
    2.083813300f,
   -1.532625556f,
    0.8694409150f,
   -0.3191759433f,
    0.08209013163f,
   -0.01224667018f,
    0.000861368381f
};

/* scipy.signal.lfilter_zi(ui_filter_b, ui_filter_a) */
static const float ui_filter_zi[UI_FILTER_STATE_LEN] = {
    0.9977281597f,
   -0.6110130550f,
    1.409188718f,
   -0.2506598753f,
    0.4597522250f,
    0.01335325001f,
    0.03183186119f,
    0.001410471363f
};
