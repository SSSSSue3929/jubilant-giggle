
// ===== HARDWARE V3 STABILITY =====
static int last_label = -1;
static int stable_count = 0;
#define STABLE_THRESHOLD 2


// ===== HARDWARE V3 SAFETY =====
static inline float clampf(float x, float a, float b)
{
    if(x < a) return a;
    if(x > b) return b;
    return x;
}


// ===== HARDWARE V3 IDLE GATE =====
static inline int is_idle_state(int input_max, int input_min, long active_count)
{
    int range = input_max - input_min;
    if(range <= 3 && active_count < 50)
        return 1;
    return 0;
}

/********************************** (C) COPYRIGHT *******************************
 * File Name          : hardware.c
 * Version            : V12.5.0-python-filtfilt-normalizer
 * Description        : UART2 921600 ���� ESP ���͵� CSI_26_DATA �����С�
 *                      ESP ���Ѿ���� raw CSI �� 26 ά��ֵ��ת����
 *                      MCU �˱��� 130x26 ģ������ߴ粻�䡣
 *                      Ԥ����˳�� Python ģ��ִ�У�
 *                      26ά֡ -> ����ͻ���޸� -> ��ͨ -> ǰ10֡���� ->
 *                      normalizer��׼�� -> int8���� -> NNoM������
 *                      UART3 ����������ɾ�������������Զ�������
 *                      ����Ĭ��ֻ��ӡ������״̬������ˢ����
 *******************************************************************************/

#include "hardware.h"
#include "debug.h"
#include "string.h"
#include "stdint.h"

#include "uart.h"

#include "nnom.h"
#include "weights.h"
#include "normalizer.h"
#include "mcu_input.h"
#include "ui_filter.h"

/* ============================================================
 * ģ�Ͳ���������ģ�����벻�䣺130 x 26 = 3380��
 * ============================================================ */
#define CSI_DIM_NUM                 26
#define CSI_WINDOW_FRAMES           130
#define CSI_STRIDE_FRAMES           10
#define CSI_INPUT_LEN               3380
#define CSI_CLASS_NUM               6
#define CSI_BASELINE_FRAMES         10

/* ============================================================
 * ���ڲ�����
 * UART2 ���� ESP ������ CSI_26_DATA��
 * LOG ����ֻ���ڴ�ӡ�Զ����������
 * ���ļ����ٱ��� UART3 ���������
 * ============================================================ */
#define LOG_UART_BAUDRATE           115200
#define CSI_UART_BAUDRATE           921600
#define UART2_ARRAY_BUF_LEN         256

/* ============================================================
 * Python ���Ԥ����������
 * Python �ο����̣�
 * decode -> median_filter_waveform -> lowpass -> front baseline��
 *
 * ESP �Ѿ���ɽ���� 26 ά��ֵ��ȡ������ MCU �ӽ������ 26 ά��ֵ֡��ʼ��
 *
 * Python �е� SciPy butter+filtfilt �������� Butterworth ϵ����odd padding��
 * lfilter_zi ��ʼ״̬��ǰ���� IIR �������̡�
 * ============================================================ */
#define UI_OUTLIER_DELTA_FLOAT      2.0f
#define UI_OUTLIER_ROW_THRESHOLD    16

/*
 * Python ��ѵ�������� normalizer.transform() ֮���ٽ���ģ�͡�
 * MCU ��ͨ�� normalizer.h + mcu_input.h ���̣�
 *     normalized = (x - mean[d]) / std[d]
 *     int8 = round(normalized * CSI_INPUT_SCALE + CSI_INPUT_OFFSET)
 */

/* ���Ŷȼ�������ȶ��������� */
#define OUTPUT_STABLE_N             3
#define OUTPUT_MIN_MARGIN           10

/*
 * �����ӡ���ԡ�
 * Ĭ��ֻ��ӡһ�С�������״̬�������ٴ�ӡԤ����ͳ�ơ�ģ�ͺ�ѡ����� 6 �����ֵ��
 * �������ڲ���Ƶ��ˢ����ͬʱ���ܿ�����ǰ�Ƿ��ȶ����Ƿ����������ơ�
 */
#define PRINT_MODEL_EACH_TIME       0
#define PRINT_MODEL_NEURON_VALUES   0
#define PRINT_UNSTABLE_WAITING      0
#define PRINT_PREPROCESS_SUMMARY    0

static const char *gesture_name[CSI_CLASS_NUM] = {
    "����(Clap)",       /* 0 */
    "����(Down)",       /* 1 */
    "��Ч(Invalid)",    /* 2 */
    "����(Left)",       /* 3 */
    "����(Right)",      /* 4 */
    "����(Up)"          /* 5 */
};

static nnom_model_t *model = NULL;

/* ���λ��������� ESP ������ 26 ά��ֵ��ʹ�� int16��������ǰ�ü��� int8�� */
static int16_t live_frame_ring[CSI_WINDOW_FRAMES][CSI_DIM_NUM];
static uint32_t live_write_frame_index = 0;
static uint32_t live_total_frames = 0;
static uint8_t live_window_ready = 0;
static uint32_t frames_since_last_infer = 0;

/* Ԥ��������������������Ϊ static������ռ�ù����ջ�ռ䡣 */
static float preproc_stage_a[CSI_WINDOW_FRAMES][CSI_DIM_NUM];
static float preproc_stage_b[CSI_WINDOW_FRAMES][CSI_DIM_NUM];

/* filtfilt ������������130 + 2 * 27 = 184 ���㡣 */
#define FILTFILT_EXT_LEN            (CSI_WINDOW_FRAMES + 2 * UI_FILTER_PADLEN)
static float filtfilt_ext[FILTFILT_EXT_LEN];
static float filtfilt_tmp[FILTFILT_EXT_LEN];
static float filtfilt_rev[FILTFILT_EXT_LEN];
static float filtfilt_out[FILTFILT_EXT_LEN];

/* �̶�Ԥ�������ء�UART ��������Ѿ�ɾ���� */
static uint8_t auto_infer_enable = 1;
static uint8_t median_filter_enable = 1;
static uint8_t lowpass_filter_enable = 1;

/* UART2 �� CSI_26_DATA �ı�����״̬�� */
static const char uart2_key[] = "CSI_26_DATA";
static uint32_t uart2_key_match = 0;
static uint8_t uart2_wait_array = 0;
static uint8_t uart2_in_array = 0;
static char uart2_array_buf[UART2_ARRAY_BUF_LEN];
static uint32_t uart2_array_len = 0;

/* ����ͳ����Ϣ�� */
static uint32_t uart2_rx_byte_count = 0;
static uint32_t uart2_parse_ok_count = 0;
static uint32_t uart2_parse_fail_count = 0;
static uint32_t uart2_array_overflow_count = 0;
static uint32_t uart2_key_count = 0;
static uint32_t median_repair_count = 0;
static uint32_t infer_count = 0;

/* �ȶ����״̬�� */
static int last_raw_label = -100;
static int repeat_count = 0;
static int last_final_label = -100;

/*********************************************************************
 * ������־����������
 *********************************************************************/
static void LOG_SendSignedLong(long num)
{
    char buf[16];
    int i = 0;
    int j = 0;
    char temp;

    if(num == 0)
    {
        LOG_SendChar('0');
        return;
    }

    if(num < 0)
    {
        LOG_SendChar('-');
        num = -num;
    }

    while(num > 0 && i < (int)sizeof(buf))
    {
        buf[i++] = (char)('0' + (num % 10));
        num /= 10;
    }

    for(j = 0; j < i / 2; j++)
    {
        temp = buf[j];
        buf[j] = buf[i - 1 - j];
        buf[i - 1 - j] = temp;
    }

    for(j = 0; j < i; j++)
    {
        LOG_SendChar((uint8_t)buf[j]);
    }
}

static void LOG_SendSignedInt(int num)
{
    LOG_SendSignedLong((long)num);
}

static void LOG_SendLine(const char *s)
{
    LOG_SendString(s);
    LOG_SendString("\r\n");
}

/*********************************************************************
 * ��ֵ����������
 *********************************************************************/
static int8_t Clip_Int8(int32_t v)
{
    if(v > 127)
    {
        v = 127;
    }
    else if(v < -128)
    {
        v = -128;
    }

    return (int8_t)v;
}

static int16_t Saturate_Int16(int32_t v)
{
    if(v > 32767)
    {
        v = 32767;
    }
    else if(v < -32768)
    {
        v = -32768;
    }

    return (int16_t)v;
}

static int32_t Round_Float_To_Int32(float x)
{
    if(x >= 0.0f)
    {
        return (int32_t)(x + 0.5f);
    }
    else
    {
        return (int32_t)(x - 0.5f);
    }
}

static float Median_Float(float *values, uint32_t len)
{
    float temp;

    for(uint32_t i = 0; i < len; i++)
    {
        for(uint32_t j = i + 1; j < len; j++)
        {
            if(values[j] < values[i])
            {
                temp = values[i];
                values[i] = values[j];
                values[j] = temp;
            }
        }
    }

    if((len % 2) == 0)
    {
        return (values[len / 2 - 1] + values[len / 2]) * 0.5f;
    }

    return values[len / 2];
}

static int16_t Median_Int16(int16_t *values, uint32_t len)
{
    int16_t temp;

    for(uint32_t i = 0; i < len; i++)
    {
        for(uint32_t j = i + 1; j < len; j++)
        {
            if(values[j] < values[i])
            {
                temp = values[i];
                values[i] = values[j];
                values[j] = temp;
            }
        }
    }

    if((len % 2) == 0)
    {
        int32_t mid_sum = (int32_t)values[len / 2 - 1] + (int32_t)values[len / 2];
        return Saturate_Int16(mid_sum / 2);
    }

    return values[len / 2];
}

/*********************************************************************
 * ���� [x1,x2,...,x26] �����е� ASCII ������
 *********************************************************************/
static int Parse_Int(const char **pp, int *out)
{
    const char *p = *pp;
    int sign = 1;
    int val = 0;
    int has_digit = 0;

    while(*p == ' ' || *p == '\t')
    {
        p++;
    }

    if(*p == '-')
    {
        sign = -1;
        p++;
    }
    else if(*p == '+')
    {
        p++;
    }

    while(*p >= '0' && *p <= '9')
    {
        has_digit = 1;
        val = val * 10 + (*p - '0');
        p++;
    }

    if(has_digit == 0)
    {
        return -1;
    }

    *out = val * sign;
    *pp = p;

    return 0;
}

static int Parse_CSI_26_From_Array_Text(const char *text, int16_t out26[CSI_DIM_NUM])
{
    const char *p = text;
    int value = 0;

    for(int i = 0; i < CSI_DIM_NUM; i++)
    {
        while(*p == ' ' || *p == '\t')
        {
            p++;
        }

        if(Parse_Int(&p, &value) != 0)
        {
            return -1;
        }

        if(value > 32767)
        {
            value = 32767;
        }
        else if(value < -32768)
        {
            value = -32768;
        }

        out26[i] = (int16_t)value;

        while(*p == ' ' || *p == '\t')
        {
            p++;
        }

        if(i < CSI_DIM_NUM - 1)
        {
            if(*p != ',')
            {
                return -2;
            }
            p++;
        }
    }

    return 0;
}

/*********************************************************************
 * ģ�ʹ�����
 *********************************************************************/
static int CSI_Model_Create_If_Needed(void)
{
    if(model != NULL)
    {
        return 0;
    }

    LOG_SendLine("[ģ��] ���ڴ��� NNoM ģ��...");
    model = nnom_model_create();

    if(model == NULL)
    {
        LOG_SendLine("[����] NNoM ģ�ʹ���ʧ�ܡ�");
        return -1;
    }

    LOG_SendLine("[ģ��] NNoM ģ�ʹ�����ɡ�");
    return 0;
}

/*********************************************************************
 * ���λ���������������
 *********************************************************************/
static uint32_t Get_Chronological_Frame_Index(uint32_t order)
{
    uint32_t index;

    if(live_window_ready)
    {
        index = live_write_frame_index + order;
        if(index >= CSI_WINDOW_FRAMES)
        {
            index -= CSI_WINDOW_FRAMES;
        }
    }
    else
    {
        index = order;
    }

    return index;
}

static void Copy_Live_Window_To_Chronological_Float(float dst[CSI_WINDOW_FRAMES][CSI_DIM_NUM])
{
    for(uint32_t f = 0; f < CSI_WINDOW_FRAMES; f++)
    {
        uint32_t idx = Get_Chronological_Frame_Index(f);
        for(uint32_t d = 0; d < CSI_DIM_NUM; d++)
        {
            dst[f][d] = (float)live_frame_ring[idx][d];
        }
    }
}

static void Live_CSI_Add_Frame(int16_t raw26[CSI_DIM_NUM])
{
    uint8_t was_ready = live_window_ready;

    for(int i = 0; i < CSI_DIM_NUM; i++)
    {
        live_frame_ring[live_write_frame_index][i] = raw26[i];
    }

    live_write_frame_index++;
    if(live_write_frame_index >= CSI_WINDOW_FRAMES)
    {
        live_write_frame_index = 0;
    }

    live_total_frames++;
    if(live_total_frames >= CSI_WINDOW_FRAMES)
    {
        live_window_ready = 1;
    }

    if(live_window_ready)
    {
        if(was_ready == 0)
        {
            frames_since_last_infer = CSI_STRIDE_FRAMES;
        }
        else
        {
            frames_since_last_infer++;
        }
    }
}

/*********************************************************************
 * Python ���Ĵ��ڼ�Ԥ������
 *
 * �� csi_preprocessing.py ���룺
 *   median_filter_waveform()
 *   signal.filtfilt(UI_FILTER_B, UI_FILTER_A, median_filtered.T).T
 *   estimate_front_static_baseline()
 *   normalizer.transform()
 *********************************************************************/
static void Apply_Python_Style_Median_Filter(
    float src[CSI_WINDOW_FRAMES][CSI_DIM_NUM],
    float dst[CSI_WINDOW_FRAMES][CSI_DIM_NUM])
{
    for(uint32_t f = 0; f < CSI_WINDOW_FRAMES; f++)
    {
        for(uint32_t d = 0; d < CSI_DIM_NUM; d++)
        {
            dst[f][d] = src[f][d];
        }
    }

    if(median_filter_enable == 0)
    {
        return;
    }

    for(uint32_t f = 1; f < CSI_WINDOW_FRAMES - 1; f++)
    {
        int outlier_count = 0;

        for(uint32_t d = 0; d < CSI_DIM_NUM; d++)
        {
            float current_value = src[f][d];
            float prev_delta = src[f - 1][d] - current_value;
            float next_delta = src[f + 1][d] - current_value;

            if(((prev_delta > UI_OUTLIER_DELTA_FLOAT) && (next_delta > UI_OUTLIER_DELTA_FLOAT)) ||
               ((prev_delta < -UI_OUTLIER_DELTA_FLOAT) && (next_delta < -UI_OUTLIER_DELTA_FLOAT)))
            {
                outlier_count++;
            }
        }

        if(outlier_count > UI_OUTLIER_ROW_THRESHOLD)
        {
            /* ���� Python��ֻ�޸��м��У�������0�к����1�С� */
            for(uint32_t d = 1; d < CSI_DIM_NUM - 1; d++)
            {
                dst[f][d] = (src[f - 1][d] + src[f + 1][d]) * 0.5f;
            }
            median_repair_count++;
        }
    }
}

static void LFilter_DF2T(
    const float *b,
    const float *a,
    const float *zi,
    float zi_scale,
    const float *x,
    float *y,
    uint32_t len)
{
    float z[UI_FILTER_STATE_LEN];

    for(uint32_t i = 0; i < UI_FILTER_STATE_LEN; i++)
    {
        z[i] = zi[i] * zi_scale;
    }

    for(uint32_t n = 0; n < len; n++)
    {
        float xn = x[n];
        float yn = b[0] * xn + z[0];

        for(uint32_t k = 0; k < UI_FILTER_STATE_LEN - 1; k++)
        {
            z[k] = b[k + 1] * xn + z[k + 1] - a[k + 1] * yn;
        }

        z[UI_FILTER_STATE_LEN - 1] =
            b[UI_FILTER_STATE_LEN] * xn - a[UI_FILTER_STATE_LEN] * yn;

        y[n] = yn;
    }
}

static void Apply_Scipy_Style_Filtfilt_One_Dim(const float *x, float *y)
{
    const uint32_t edge = UI_FILTER_PADLEN;
    const uint32_t n = CSI_WINDOW_FRAMES;
    const uint32_t ext_len = FILTFILT_EXT_LEN;

    /* odd extension���� scipy.signal.filtfilt Ĭ�� padtype='odd' ���롣 */
    for(uint32_t i = 0; i < edge; i++)
    {
        filtfilt_ext[i] = 2.0f * x[0] - x[edge - i];
    }

    for(uint32_t i = 0; i < n; i++)
    {
        filtfilt_ext[edge + i] = x[i];
    }

    for(uint32_t i = 0; i < edge; i++)
    {
        filtfilt_ext[edge + n + i] = 2.0f * x[n - 1] - x[n - 2 - i];
    }

    /* forward filter, zi * first_value�� */
    LFilter_DF2T(
        ui_filter_b,
        ui_filter_a,
        ui_filter_zi,
        filtfilt_ext[0],
        filtfilt_ext,
        filtfilt_tmp,
        ext_len
    );

    /* reverse�� */
    for(uint32_t i = 0; i < ext_len; i++)
    {
        filtfilt_rev[i] = filtfilt_tmp[ext_len - 1 - i];
    }

    /* backward filter, zi * first_value_after_reverse�� */
    LFilter_DF2T(
        ui_filter_b,
        ui_filter_a,
        ui_filter_zi,
        filtfilt_rev[0],
        filtfilt_rev,
        filtfilt_out,
        ext_len
    );

    /* reverse back and remove padding�� */
    for(uint32_t i = 0; i < n; i++)
    {
        y[i] = filtfilt_out[ext_len - 1 - (edge + i)];
    }
}

static void Apply_Window_Lowpass_Filter(
    float src[CSI_WINDOW_FRAMES][CSI_DIM_NUM],
    float dst[CSI_WINDOW_FRAMES][CSI_DIM_NUM])
{
    if(lowpass_filter_enable == 0)
    {
        for(uint32_t f = 0; f < CSI_WINDOW_FRAMES; f++)
        {
            for(uint32_t d = 0; d < CSI_DIM_NUM; d++)
            {
                dst[f][d] = src[f][d];
            }
        }
        return;
    }

    float x_col[CSI_WINDOW_FRAMES];
    float y_col[CSI_WINDOW_FRAMES];

    for(uint32_t d = 0; d < CSI_DIM_NUM; d++)
    {
        for(uint32_t f = 0; f < CSI_WINDOW_FRAMES; f++)
        {
            x_col[f] = src[f][d];
        }

        Apply_Scipy_Style_Filtfilt_One_Dim(x_col, y_col);

        for(uint32_t f = 0; f < CSI_WINDOW_FRAMES; f++)
        {
            dst[f][d] = y_col[f];
        }
    }
}

static float Estimate_Front_Baseline_Median(
    float waveform[CSI_WINDOW_FRAMES][CSI_DIM_NUM],
    uint32_t dim)
{
    float values[CSI_BASELINE_FRAMES];

    for(uint32_t f = 0; f < CSI_BASELINE_FRAMES; f++)
    {
        values[f] = waveform[f][dim];
    }

    return Median_Float(values, CSI_BASELINE_FRAMES);
}

/*********************************************************************
 * �ѵ�ǰʵʱ���ڸ��Ƴ� NNoM ���롣
 * ����˳��Ϊʱ�����ȣ���0֡26ά��Ȼ���1֡26ά���������С�
 *********************************************************************/
static int Live_Window_Copy_To_NNoM_Input(void)
{
    uint32_t dst = 0;
    float baseline[CSI_DIM_NUM];

    if(live_window_ready == 0)
    {
        LOG_SendLine("[�ȴ�] ��ǰ���� 130 ֡���ݲ�������");
        return -1;
    }

    Copy_Live_Window_To_Chronological_Float(preproc_stage_a);
    Apply_Python_Style_Median_Filter(preproc_stage_a, preproc_stage_b);
    Apply_Window_Lowpass_Filter(preproc_stage_b, preproc_stage_a);

    for(uint32_t d = 0; d < CSI_DIM_NUM; d++)
    {
        baseline[d] = Estimate_Front_Baseline_Median(preproc_stage_a, d);
    }

    for(uint32_t f = 0; f < CSI_WINDOW_FRAMES; f++)
    {
        for(uint32_t d = 0; d < CSI_DIM_NUM; d++)
        {
            float v = preproc_stage_a[f][d] - baseline[d];
            float normalized = (v - csi_normalizer_mean[d]) / csi_normalizer_std[d];
            int32_t q = Round_Float_To_Int32(normalized * CSI_INPUT_SCALE + CSI_INPUT_OFFSET);
            nnom_input_data[dst++] = Clip_Int8(q);
        }
    }

    return 0;
}

/*********************************************************************
 * �������������
 *********************************************************************/
static void Print_Gesture_Name(int label)
{
    if(label >= 0 && label < CSI_CLASS_NUM)
    {
        LOG_SendString(gesture_name[label]);
    }
    else
    {
        LOG_SendString("δ֪");
    }
}

static void Print_Input_Config(void)
{
    LOG_SendString("[����] ����=130֡, ά��=26, ��������=");
    LOG_SendSignedInt(CSI_STRIDE_FRAMES);
    LOG_SendString(", ����֡��=");
    LOG_SendSignedInt(CSI_BASELINE_FRAMES);
    LOG_SendString(", ����scale=");
    LOG_SendSignedInt((int)CSI_INPUT_SCALE);
    LOG_SendString(", ͻ���޸�����=");
    LOG_SendSignedInt((int)median_filter_enable);
    LOG_SendString(", ��ͨ=Butterworth filtfilt����SciPy");
    LOG_SendString("\r\n");
}

static int Output_Stable_Filter(int label)
{
    if(label == last_raw_label)
    {
        repeat_count++;
    }
    else
    {
        last_raw_label = label;
        repeat_count = 1;
    }

    if(label >= 0 && repeat_count >= OUTPUT_STABLE_N)
    {
        return label;
    }

    return -1;
}

static int Print_Model_Output(void)
{
    int8_t max_val = -128;
    int8_t second_val = -128;
    int predicted_label = -1;
    int second_label = -1;
    int tie_count = 0;
    int margin;
    int stable;

    /* 1. ��ȡ 6 �� NNoM �����Ԫ���õ�����ģ���жϡ� */
    for(int i = 0; i < CSI_CLASS_NUM; i++)
    {
        if(nnom_output_data[i] > max_val)
        {
            max_val = nnom_output_data[i];
            predicted_label = i;
        }
    }

    for(int i = 0; i < CSI_CLASS_NUM; i++)
    {
        if(nnom_output_data[i] == max_val)
        {
            tie_count++;
        }
    }

    for(int i = 0; i < CSI_CLASS_NUM; i++)
    {
        if(i == predicted_label)
        {
            continue;
        }

        if(nnom_output_data[i] > second_val)
        {
            second_val = nnom_output_data[i];
            second_label = i;
        }
    }

    margin = (int)max_val - (int)second_val;

#if PRINT_MODEL_EACH_TIME
    LOG_SendString("[ģ�ͱ����ж�] ��");
    LOG_SendSignedLong((long)infer_count);
    LOG_SendString("������, ��ѡ��ǩ=");
    LOG_SendSignedInt(predicted_label);
    LOG_SendString(", ��ѡ����=");
    Print_Gesture_Name(predicted_label);
    LOG_SendString(", ������=");
    LOG_SendSignedInt((int)max_val);
    LOG_SendString(", �ڶ���ǩ=");
    LOG_SendSignedInt(second_label);
    LOG_SendString(", �ڶ����=");
    LOG_SendSignedInt((int)second_val);
    LOG_SendString(", ���Ų�=");
    LOG_SendSignedInt(margin);
    LOG_SendString(", ���������=");
    LOG_SendSignedInt(tie_count);
    LOG_SendString("\r\n");
#endif

#if PRINT_MODEL_NEURON_VALUES
    LOG_SendString("[ģ��6�����ֵ] ����=");
    LOG_SendSignedInt((int)nnom_output_data[0]);
    LOG_SendString(", ����=");
    LOG_SendSignedInt((int)nnom_output_data[1]);
    LOG_SendString(", ��Ч=");
    LOG_SendSignedInt((int)nnom_output_data[2]);
    LOG_SendString(", ����=");
    LOG_SendSignedInt((int)nnom_output_data[3]);
    LOG_SendString(", ����=");
    LOG_SendSignedInt((int)nnom_output_data[4]);
    LOG_SendString(", ����=");
    LOG_SendSignedInt((int)nnom_output_data[5]);
    LOG_SendString("\r\n");
#endif

    /* 2. ���Ŷȼ�飺���ֵ���л����Ų�̫С�����β���Ϊ�������ơ� */
    if(tie_count >= 2 || margin < OUTPUT_MIN_MARGIN)
    {
        Output_Stable_Filter(-1);

#if PRINT_UNSTABLE_WAITING
        LOG_SendString("[������״̬] �������������ԭ��=");
        if(tie_count >= 2)
        {
            LOG_SendString("���ֵ����");
        }
        else
        {
            LOG_SendString("���Ų��");
        }
        LOG_SendString(", �������Ʋ�����\r\n");
#endif

        return -1;
    }

    /* 3. �ȶ��Լ�飺ͬһ����Ч��ǩ�������� N �Σ���������ս���� */
    stable = Output_Stable_Filter(predicted_label);

    if(stable >= 0)
    {
        last_final_label = stable;

        LOG_SendString("[������״̬] �������������=");
        Print_Gesture_Name(stable);
        LOG_SendString(", ��ǩ=");
        LOG_SendSignedInt(stable);
        LOG_SendString(", �ȶ�=");
        LOG_SendSignedInt(OUTPUT_STABLE_N);
        LOG_SendString("/");
        LOG_SendSignedInt(OUTPUT_STABLE_N);
        LOG_SendString(", ���Ų�=");
        LOG_SendSignedInt(margin);
        LOG_SendString("\r\n");

        return stable;
    }

#if PRINT_UNSTABLE_WAITING
    LOG_SendString("[������״̬] �ȴ��ȶ�����ѡ����=");
    Print_Gesture_Name(predicted_label);
    LOG_SendString(", ��ǩ=");
    LOG_SendSignedInt(predicted_label);
    LOG_SendString(", �ȶ�=");
    LOG_SendSignedInt(repeat_count);
    LOG_SendString("/");
    LOG_SendSignedInt(OUTPUT_STABLE_N);
    LOG_SendString(", �ݲ������������\r\n");
#endif

    return -1;
}

static int CSI_Model_Run_With_Live_Window(char reason)
{
    if(live_window_ready == 0)
    {
        return -1;
    }

    if(CSI_Model_Create_If_Needed() != 0)
    {
        return -2;
    }

    if(Live_Window_Copy_To_NNoM_Input() != 0)
    {
        return -3;
    }

    long input_sum = 0;
    int input_min = 127;
    int input_max = -128;

    for(uint32_t i = 0; i < CSI_INPUT_LEN; i++)
    {
        int v = (int)nnom_input_data[i];
        input_sum += v;
        if(v < input_min)
        {
            input_min = v;
        }
        if(v > input_max)
        {
            input_max = v;
        }
    }

    infer_count++;

#if PRINT_PREPROCESS_SUMMARY
    LOG_SendString("\r\n[Ԥ�������] ����=");
    if(reason == 'A')
    {
        LOG_SendString("�Զ�(A)");
    }
    else
    {
        LOG_SendChar((uint8_t)reason);
    }
    LOG_SendString(", ��֡��=");
    LOG_SendSignedLong((long)live_total_frames);
    LOG_SendString(", �ѽ���֡=");
    LOG_SendSignedLong((long)uart2_parse_ok_count);
    LOG_SendString(", ͻ���޸��ۼ�=");
    LOG_SendSignedLong((long)median_repair_count);
    LOG_SendString(", ������ģ�������=");
    LOG_SendSignedLong(input_sum);
    LOG_SendString(", ������������Сֵ=");
    LOG_SendSignedInt(input_min);
    LOG_SendString(", �������������ֵ=");
    LOG_SendSignedInt(input_max);
    LOG_SendString("\r\n");
#else
    (void)reason;
    (void)input_sum;
    (void)input_min;
    (void)input_max;
#endif

    nnom_status_t run_status = model_run(model);
    if(run_status != NN_SUCCESS)
    {
        LOG_SendString("[����] model_run ����ʧ�ܣ�������=");
        LOG_SendSignedInt((int)run_status);
        LOG_SendString("\r\n");
        return -4;
    }

    return Print_Model_Output();
}

/*********************************************************************
 * UART2 �� CSI_26_DATA ��ʽ������
 * ƥ�䵽 "CSI_26_DATA" ��Ѱ�ҵ�һ�� '['������������ 26 ��������
 *********************************************************************/
static void UART2_Reset_Parse_State(void)
{
    uart2_key_match = 0;
    uart2_wait_array = 0;
    uart2_in_array = 0;
    uart2_array_len = 0;
}

static void UART2_Stream_CSI26_Receive_Task(void)
{
    uint8_t ch;
    int16_t frame26[CSI_DIM_NUM];
    int ret;

    while(CSI_UART2_Available())
    {
        ch = CSI_UART2_ReadByte();
        uart2_rx_byte_count++;

        if(uart2_wait_array == 0 && uart2_in_array == 0)
        {
            if(ch == (uint8_t)uart2_key[uart2_key_match])
            {
                uart2_key_match++;
                if(uart2_key[uart2_key_match] == '\0')
                {
                    uart2_key_count++;
                    uart2_wait_array = 1;
                    uart2_key_match = 0;
                }
            }
            else
            {
                if(ch == (uint8_t)uart2_key[0])
                {
                    uart2_key_match = 1;
                }
                else
                {
                    uart2_key_match = 0;
                }
            }
            continue;
        }

        if(uart2_wait_array && uart2_in_array == 0)
        {
            if(ch == '[')
            {
                uart2_in_array = 1;
                uart2_wait_array = 0;
                uart2_array_len = 0;
                continue;
            }

            if(ch == '\n' || ch == '\r')
            {
                UART2_Reset_Parse_State();
                continue;
            }

            continue;
        }

        if(uart2_in_array)
        {
            if(ch == ']')
            {
                uart2_array_buf[uart2_array_len] = '\0';
                ret = Parse_CSI_26_From_Array_Text(uart2_array_buf, frame26);

                if(ret == 0)
                {
                    uart2_parse_ok_count++;
                    Live_CSI_Add_Frame(frame26);

                    if(auto_infer_enable && live_window_ready)
                    {
                        if(frames_since_last_infer >= CSI_STRIDE_FRAMES)
                        {
                            frames_since_last_infer = 0;
                            CSI_Model_Run_With_Live_Window('A');
                        }
                    }
                }
                else
                {
                    uart2_parse_fail_count++;
                    LOG_SendString("[��������] ����ֵ=");
                    LOG_SendSignedInt(ret);
                    LOG_SendString(", ԭʼ����=");
                    LOG_SendString(uart2_array_buf);
                    LOG_SendString("\r\n");
                }

                UART2_Reset_Parse_State();
                continue;
            }

            if(ch == '\n' || ch == '\r')
            {
                uart2_parse_fail_count++;
                UART2_Reset_Parse_State();
                continue;
            }

            if(uart2_array_len < UART2_ARRAY_BUF_LEN - 1)
            {
                uart2_array_buf[uart2_array_len++] = (char)ch;
            }
            else
            {
                uart2_array_overflow_count++;
                uart2_parse_fail_count++;
                UART2_Reset_Parse_State();
                LOG_SendLine("[��������] CSI_26_DATA ���黺����������Ѷ�����֡��");
                continue;
            }
        }
    }
}

static void Clear_Live_Buffer(void)
{
    memset(live_frame_ring, 0, sizeof(live_frame_ring));
    memset(preproc_stage_a, 0, sizeof(preproc_stage_a));
    memset(preproc_stage_b, 0, sizeof(preproc_stage_b));

    live_write_frame_index = 0;
    live_total_frames = 0;
    live_window_ready = 0;
    frames_since_last_infer = 0;

    UART2_Reset_Parse_State();

    uart2_rx_byte_count = 0;
    uart2_parse_ok_count = 0;
    uart2_parse_fail_count = 0;
    uart2_array_overflow_count = 0;
    uart2_key_count = 0;
    median_repair_count = 0;
    infer_count = 0;

    last_raw_label = -100;
    repeat_count = 0;
    last_final_label = -100;
}

/*********************************************************************
 * Ӳ����ѭ����
 *********************************************************************/
void Hardware(void)
{
    if(NVIC_GetCurrentCoreID() == 0)
    {
        while(1)
        {
            Delay_Ms(100);
        }
    }
    else
    {
        UART_All_Init(LOG_UART_BAUDRATE, CSI_UART_BAUDRATE);
        Delay_Ms(500);

        Clear_Live_Buffer();

        LOG_SendString("\r\n\r\n");
        LOG_SendLine("====== NNoM CSI �Զ����� V12.4 ���ľ�����־�� ======");
        LOG_SendLine("UART2 CSI����: 921600�����ʣ�ESP���� CSI_26_DATA 26ά���ݡ�");
        LOG_SendLine("UART3��������: ��ɾ�������������Զ�������");
        LOG_SendLine("Ԥ��������: ����26ά -> ͻ���޸� -> Butterworth filtfilt -> ǰ10֡���� -> normalizer -> int8������");
        LOG_SendLine("��ǩ˵��: 0=����, 1=����, 2=��Ч, 3=����, 4=����, 5=���ϡ�");
        Print_Input_Config();
        LOG_SendLine("������130֡��ʼ������֮��ÿ10֡�Զ�����һ�Ρ�");
        LOG_SendLine("===========================================");

        while(1)
        {
            /* 921600�������£��������ȴ���UART2���ա� */
            UART2_Stream_CSI26_Receive_Task();

            /* ��ɾ�� UART3 �������񣬴˴�������ʱ�� */
        }
    }
}
