#pragma once
#include <stdint.h>

/* 此文件由训练脚本自动生成，请勿手工修�? scale�? */
#define CSI_INPUT_DEC_BITS 2
#define CSI_INPUT_SCALE 4.0f
#define CSI_INPUT_OFFSET 0.0f
#define CSI_NNOM_INPUT_SHIFT_MACRO_NAME "INPUT_2_OUTPUT_SHIFT"
