#ifndef __UART_H
#define __UART_H

#ifdef __cplusplus
extern "C" {
#endif

#include "debug.h"
#include <stdint.h>

/*
 * USART3: ���Դ�ӡ / ���������
 * PB10 = USART3_TX
 * PB11 = USART3_RX
 */
void LOG_UART3_Init(uint32_t baudrate);

/*
 * USART2: CSI ���ݴ���
 * PD5 = USART2_TX
 * PD6 = USART2_RX
 */
void CSI_UART2_Init(uint32_t baudrate);

/*
 * һ���Գ�ʼ�� USART3 �� USART2
 */
void UART_All_Init(uint32_t log_baudrate, uint32_t csi_baudrate);

/*
 * USART3 ����
 */
void LOG_SendChar(uint8_t ch);
void LOG_SendString(const char *s);
void LOG_SendBuffer(uint8_t *buf, uint32_t len);
void LOG_Flush(void);

/*
 * USART3 ����
 */
uint8_t LOG_UART3_Available(void);
uint8_t LOG_UART3_ReadByte(void);

/*
 * USART2 ����
 */
uint8_t CSI_UART2_Available(void);
uint8_t CSI_UART2_ReadByte(void);

/*
 * USART2 ����
 */
void CSI_UART2_SendByte(uint8_t ch);
void CSI_UART2_SendString(const char *s);
void CSI_UART2_SendBuffer(uint8_t *buf, uint32_t len);

#ifdef __cplusplus
}
#endif

#endif