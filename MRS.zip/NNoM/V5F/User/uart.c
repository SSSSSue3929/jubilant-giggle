#include "uart.h"

/*
 * ============================================================
 * USART3: ���Դ�ӡ���� / ���������
 *
 * USART3_TX = PB10(AF7) -> USB-TTL RX
 * USART3_RX = PB11(AF7) -> USB-TTL TX
 * GND                  -> USB-TTL GND
 * ============================================================
 */
void LOG_UART3_Init(uint32_t baudrate)
{
    GPIO_InitTypeDef  GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};

    RCC_HB1PeriphClockCmd(RCC_HB1Periph_USART3, ENABLE);
    RCC_HB2PeriphClockCmd(RCC_HB2Periph_AFIO | RCC_HB2Periph_GPIOB, ENABLE);

    /*
     * PB10 -> USART3_TX
     */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF7);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Very_High;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /*
     * PB11 -> USART3_RX
     */
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF7);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate            = baudrate;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;

    USART_Init(USART3, &USART_InitStructure);
    USART_Cmd(USART3, ENABLE);
}


/*
 * ============================================================
 * USART2: CSI ���ݽ��մ���
 *
 * USART2_TX = PD5(AF7)
 * USART2_RX = PD6(AF7)
 * ============================================================
 */
void CSI_UART2_Init(uint32_t baudrate)
{
    GPIO_InitTypeDef  GPIO_InitStructure = {0};
    USART_InitTypeDef USART_InitStructure = {0};

    RCC_HB1PeriphClockCmd(RCC_HB1Periph_USART2, ENABLE);
    RCC_HB2PeriphClockCmd(RCC_HB2Periph_AFIO | RCC_HB2Periph_GPIOD, ENABLE);

    /*
     * PD5 -> USART2_TX
     */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF7);

    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_Very_High;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    /*
     * PD6 -> USART2_RX
     */
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource6, GPIO_AF7);

    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate            = baudrate;
    USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits            = USART_StopBits_1;
    USART_InitStructure.USART_Parity              = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;

    USART_Init(USART2, &USART_InitStructure);
    USART_Cmd(USART2, ENABLE);
}


/*
 * ============================================================
 * һ���Գ�ʼ����������
 * ============================================================
 */
void UART_All_Init(uint32_t log_baudrate, uint32_t csi_baudrate)
{
    LOG_UART3_Init(log_baudrate);
    CSI_UART2_Init(csi_baudrate);
}


/*
 * ============================================================
 * USART3 ���ͺ���
 * ============================================================
 */
void LOG_SendChar(uint8_t ch)
{
    while(USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
    USART_SendData(USART3, ch);
}

void LOG_SendString(const char *s)
{
    while(*s)
    {
        LOG_SendChar((uint8_t)*s++);
    }
}

void LOG_SendBuffer(uint8_t *buf, uint32_t len)
{
    uint32_t i;

    for(i = 0; i < len; i++)
    {
        LOG_SendChar(buf[i]);
    }
}

void LOG_Flush(void)
{
    while(USART_GetFlagStatus(USART3, USART_FLAG_TC) == RESET);
}


/*
 * ============================================================
 * USART3 ���պ���
 * ============================================================
 */
uint8_t LOG_UART3_Available(void)
{
    return (USART_GetFlagStatus(USART3, USART_FLAG_RXNE) != RESET);
}

uint8_t LOG_UART3_ReadByte(void)
{
    return (uint8_t)USART_ReceiveData(USART3);
}


/*
 * ============================================================
 * USART2 ���պ���
 * ============================================================
 */
uint8_t CSI_UART2_Available(void)
{
    return (USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET);
}

uint8_t CSI_UART2_ReadByte(void)
{
    return (uint8_t)USART_ReceiveData(USART2);
}


/*
 * ============================================================
 * USART2 ���ͺ���
 * ============================================================
 */
void CSI_UART2_SendByte(uint8_t ch)
{
    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    USART_SendData(USART2, ch);
}

void CSI_UART2_SendString(const char *s)
{
    while(*s)
    {
        CSI_UART2_SendByte((uint8_t)*s++);
    }
}

void CSI_UART2_SendBuffer(uint8_t *buf, uint32_t len)
{
    uint32_t i;

    for(i = 0; i < len; i++)
    {
        CSI_UART2_SendByte(buf[i]);
    }
}