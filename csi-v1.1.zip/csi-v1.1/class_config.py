"""共享的手势分类数量配置。

修改 ``CLASSIFICATION_COUNT`` 后：
1. 训练侧会按数据集中实际发现的类别顺序，动态选取前 n 个类别参与训练。
2. 实时识别侧会要求加载的 checkpoint 与该 n 分类数量保持一致。
"""

from __future__ import annotations


# 修改这里即可切换当前采用的 n 分类数量。
CLASSIFICATION_COUNT = 6

def validate_classification_count(max_count: int) -> int:
    """校验当前配置的分类数是否合法。"""
    count = int(CLASSIFICATION_COUNT)
    if not 1 <= count <= max_count:
        raise ValueError(
            f"CLASSIFICATION_COUNT 必须在 1 到 {max_count} 之间，当前为 {count}。"
        )
    return count


def select_configured_class_names(available_class_names: list[str]) -> list[str]:
    """按共享配置，从数据集实际类别中动态选取前 n 个类别。"""
    normalized_class_names = list(available_class_names)
    if not normalized_class_names:
        raise RuntimeError(
            "数据集中未发现任何类别目录，无法根据分类数配置选择类别。"
        )
    selected_count = validate_classification_count(len(normalized_class_names))
    return normalized_class_names[:selected_count]


def validate_runtime_class_count(runtime_class_names: list[str]) -> None:
    """校验实时识别模型的类别数量是否与共享配置一致。"""
    runtime_count = len(list(runtime_class_names))
    configured_count = int(CLASSIFICATION_COUNT)
    if runtime_count != configured_count:
        raise ValueError(
            "当前模型 checkpoint 的分类数量与共享配置不一致。"
            f"共享配置为 {configured_count} 分类；"
            f"checkpoint 实际为 {runtime_count} 分类：{list(runtime_class_names)}。"
            "请重新训练并更新 best_model.pt，或修改 class_config.py 中的分类数配置。"
        )
