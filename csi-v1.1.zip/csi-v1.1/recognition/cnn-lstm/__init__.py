"""CSI CNN-LSTM 识别训练与推理项目。"""
