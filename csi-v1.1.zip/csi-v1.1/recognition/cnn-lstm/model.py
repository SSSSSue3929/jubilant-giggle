"""CSI CNN-LSTM 分类模型定义。"""

from __future__ import annotations

import torch
from torch import nn


MODEL_TYPE = "cnn-lstm"
MODEL_EXTRA_KWARGS: dict[str, int | float] = {
    "cnn_channels": 64,
    "kernel_size": 5,
}


class CSICNNLSTMClassifier(nn.Module):
    """先用 1D-CNN 提取局部时序特征，再用 LSTM 学习动作时间依赖。"""

    def __init__(
        self,
        input_size: int = 26,
        cnn_channels: int = 64,
        hidden_size: int = 128,
        num_layers: int = 2,
        num_classes: int = 5,
        dropout: float = 0.3,
        kernel_size: int = 5,
    ) -> None:
        super().__init__()
        if input_size <= 0:
            raise ValueError(f"input_size must be positive, got {input_size}.")
        if cnn_channels <= 0:
            raise ValueError(f"cnn_channels must be positive, got {cnn_channels}.")
        if kernel_size <= 0 or kernel_size % 2 == 0:
            raise ValueError(f"kernel_size must be a positive odd number, got {kernel_size}.")

        padding = kernel_size // 2
        lstm_dropout = dropout if num_layers > 1 else 0.0

        # Conv1d 在时间轴上滑动，输入通道是每帧 CSI 子载波特征数。
        self.cnn = nn.Sequential(
            nn.Conv1d(
                in_channels=input_size,
                out_channels=cnn_channels,
                kernel_size=kernel_size,
                padding=padding,
            ),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(
                in_channels=cnn_channels,
                out_channels=cnn_channels,
                kernel_size=3,
                padding=1,
            ),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
        )
        # LSTM 接收 CNN 提取后的逐帧局部特征，继续建模动作随时间的变化。
        self.lstm = nn.LSTM(
            input_size=cnn_channels,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=lstm_dropout,
        )
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """执行前向推理，并返回各类别 logits。"""

        if x.ndim == 4:
            if x.size(1) != 1:
                raise ValueError(
                    f"Expected a single CSI channel, got input shape {tuple(x.shape)}."
                )
            x = x[:, 0, :, :]
        elif x.ndim != 3:
            raise ValueError(
                "Expected input shape [batch, seq, feat] or [batch, 1, seq, feat], "
                f"got {tuple(x.shape)}."
            )

        # [B, T, F] -> [B, F, T]，让 Conv1d 沿时间轴提取局部模式。
        local_features = self.cnn(x.transpose(1, 2))
        # [B, C, T] -> [B, T, C]，转换回 LSTM 需要的序列格式。
        sequence_features = local_features.transpose(1, 2)
        output, _ = self.lstm(sequence_features)
        output = self.dropout(output[:, -1, :])
        return self.fc(output)


# 兼容 recognition/lstm/train.py 和 predict.py 中已有的模型类名。
CSILSTMClassifier = CSICNNLSTMClassifier
