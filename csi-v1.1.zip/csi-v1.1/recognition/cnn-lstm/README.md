# recognition/CNN-LSTM

`recognition/CNN-LSTM` 在统一训练流程上替换为 `1D-CNN + LSTM` 模型结构。

## 主要用途

- 先用一维卷积提取局部时序特征。
- 再用 LSTM 学习动作的时间依赖关系。
- 复用与 `LSTM` 相同的数据发现、预处理、切分和评估逻辑。

## 推荐用法

```powershell
conda run -n esp-csi python .\recognition\train.py --model cnn-lstm
conda run -n esp-csi python .\recognition\predict.py --model cnn-lstm --input .\data
```

## 说明

- 默认数据集根目录为 `data/`。
- 训练输出位于 `recognition/CNN-LSTM/outputs/`。
- 默认 checkpoint 位于 `recognition/CNN-LSTM/checkpoints/`。

## 目录结构

```text
recognition/CNN-LSTM/               # CNN-LSTM 模型项目
├── checkpoints/                    # 训练生成的 checkpoint
├── outputs/                        # 评估报告与训练结果
├── model.py                        # CNN-LSTM 模型定义
├── predict.py                      # 模型验证与推理脚本
└── train.py                        # 模型训练脚本
```
