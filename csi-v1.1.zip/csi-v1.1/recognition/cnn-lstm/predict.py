"""CNN-LSTM 推理入口。

推理流程复用 `recognition/lstm/predict.py`，但模型结构来自本目录的
`model.py`，默认 checkpoint 路径也会落在 `recognition/cnn-lstm/checkpoints`。
"""

from __future__ import annotations

import sys
from pathlib import Path


CURRENT_DIR = Path(__file__).resolve().parent
# 统一复用 LSTM 项目的推理主流程，只在当前目录覆盖模型定义。
LSTM_PROJECT_DIR = CURRENT_DIR.parent / "LSTM"

if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))
if str(LSTM_PROJECT_DIR) not in sys.path:
    sys.path.insert(1, str(LSTM_PROJECT_DIR))

_LSTM_PREDICT_PATH = LSTM_PROJECT_DIR / "predict.py"
_LSTM_PREDICT_SOURCE = _LSTM_PREDICT_PATH.read_text(encoding="utf-8").replace(
    "Run inference with the CSI LSTM model.",
    "Run inference with the CSI CNN-LSTM model.",
)

exec(compile(_LSTM_PREDICT_SOURCE, str(Path(__file__).resolve()), "exec"), globals())
