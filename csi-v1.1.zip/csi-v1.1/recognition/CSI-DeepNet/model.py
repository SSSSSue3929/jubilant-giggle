"""CSI-DeepNet 分类模型定义。"""

from __future__ import annotations

import torch
from torch import nn


MODEL_TYPE = "csi-deepnet"
MODEL_EXTRA_KWARGS: dict[str, int | float] = {
    "stem_channels": 12,
    "ds1_channels": 32,
    "ds2_channels": 64,
    "ds3_channels": 128,
    "ds4_channels": 256,
    "dense_hidden_size": 64,
}


class DepthwiseSeparableConvBlock(nn.Module):
    """CSI-DeepNet 中使用的深度可分离卷积块。"""

    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(
                in_channels,
                in_channels,
                kernel_size=3,
                stride=2,
                padding=1,
                groups=in_channels,
                bias=False,
            ),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class FeatureAttentionBlock(nn.Module):
    """参考论文中的 Feature Attention，对二维 CSI 特征图做空间注意力。"""

    def __init__(self) -> None:
        super().__init__()
        self.attention = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size=3, padding=1, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg_map = torch.mean(x, dim=1, keepdim=True)
        max_map = torch.amax(x, dim=1, keepdim=True)
        attention_map = self.attention(torch.cat([avg_map, max_map], dim=1))
        return x * attention_map


class ResidualBlock(nn.Module):
    """参考论文中的残差块，用拼接式残差融合增强局部特征。"""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.branch = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.LeakyReLU(negative_slope=0.1, inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channels),
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(channels),
            nn.LeakyReLU(negative_slope=0.1, inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        branch_features = self.branch(x)
        return self.fuse(torch.cat([x, branch_features], dim=1))


class CSIDeepNetClassifier(nn.Module):
    """参考 CSI-DeepNet 论文拓扑实现的轻量手势识别网络。"""

    def __init__(
        self,
        input_size: int = 26,
        stem_channels: int = 12,
        ds1_channels: int = 32,
        ds2_channels: int = 64,
        ds3_channels: int = 128,
        ds4_channels: int = 256,
        dense_hidden_size: int = 64,
        num_classes: int = 5,
        dropout: float = 0.3,
        **_: int | float,
    ) -> None:
        super().__init__()
        if input_size <= 0:
            raise ValueError(f"input_size must be positive, got {input_size}.")

        self.stem = nn.Sequential(
            nn.Conv2d(1, stem_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(stem_channels),
            nn.ReLU(inplace=True),
        )
        self.ds_block1 = DepthwiseSeparableConvBlock(stem_channels, ds1_channels)
        self.attention1 = FeatureAttentionBlock()
        self.residual1 = ResidualBlock(ds1_channels)

        self.ds_block2 = DepthwiseSeparableConvBlock(ds1_channels, ds2_channels)
        self.attention2 = FeatureAttentionBlock()
        self.residual2 = ResidualBlock(ds2_channels)

        self.ds_block3 = DepthwiseSeparableConvBlock(ds2_channels, ds3_channels)
        self.ds_block4 = DepthwiseSeparableConvBlock(ds3_channels, ds4_channels)

        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.dropout = nn.Dropout(dropout)
        self.fc1 = nn.Linear(ds4_channels, dense_hidden_size)
        self.relu = nn.ReLU(inplace=True)
        self.classifier = nn.Linear(dense_hidden_size, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """执行前向推理，并返回各类别 logits。"""

        if x.ndim == 3:
            x = x.unsqueeze(1)
        elif x.ndim != 4:
            raise ValueError(
                "Expected input shape [batch, seq, feat] or [batch, 1, seq, feat], "
                f"got {tuple(x.shape)}."
            )

        if x.size(1) != 1:
            raise ValueError(
                f"Expected a single CSI channel, got input shape {tuple(x.shape)}."
            )

        x = self.stem(x)
        x = self.ds_block1(x)
        x = self.attention1(x)
        x = self.residual1(x)

        x = self.ds_block2(x)
        x = self.attention2(x)
        x = self.residual2(x)

        x = self.ds_block3(x)
        x = self.ds_block4(x)

        x = self.global_pool(x)
        x = torch.flatten(x, start_dim=1)
        x = self.dropout(x)
        x = self.fc1(x)
        x = self.relu(x)
        return self.classifier(x)


# 兼容 recognition/lstm/train.py 和 predict.py 中已有的模型类名。
CSILSTMClassifier = CSIDeepNetClassifier
