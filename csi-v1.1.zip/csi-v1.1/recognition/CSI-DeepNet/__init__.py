"""CSI-DeepNet 手势识别训练与推理项目。"""
