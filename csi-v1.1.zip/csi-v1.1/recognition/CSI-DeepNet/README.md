# recognition/CSI-DeepNet

`recognition/CSI-DeepNet` 参考 CSI-DeepNet 论文拓扑实现轻量卷积模型，并继续复用当前项目的训练与预处理流程。

## 主要用途

- 对比纯 LSTM、CNN-LSTM 与轻量卷积模型的识别效果。
- 保持当前项目已有的样本输入、低通滤波、baseline 校准和标准化策略。
- 训练出的 checkpoint 可直接供 PC 端实时识别加载。

## 推荐用法

```powershell
conda run -n esp-csi python .\recognition\train.py --model csi-deepnet
conda run -n esp-csi python .\recognition\predict.py --model csi-deepnet --input .\data
```

## 说明

- 默认数据集根目录为 `data/`。
- 当前实现复用项目现有输入管线，模型实际输入为 `[batch, 1, 130, 26]`。
- 训练输出位于 `recognition/CSI-DeepNet/outputs/`。

## 目录结构

```text
recognition/CSI-DeepNet/            # CSI-DeepNet 模型项目
├── checkpoints/                    # 训练生成的 checkpoint
├── outputs/                        # 评估报告与训练结果
├── model.py                        # CSI-DeepNet 模型定义
├── predict.py                      # 模型验证与推理脚本
└── train.py                        # 模型训练脚本
```
