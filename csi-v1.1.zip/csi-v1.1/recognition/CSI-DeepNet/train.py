"""CSI-DeepNet 训练入口。

本项目复用 `recognition/lstm/train.py` 中已经验证过的数据发现、预处理、
same/cross-session 切分、评估和工件保存逻辑；由于当前目录优先提供
`model.py`，训练时会自动使用本目录的 CSI-DeepNet 模型。
"""

from __future__ import annotations

import sys
from pathlib import Path


CURRENT_DIR = Path(__file__).resolve().parent
# 统一复用 LSTM 项目的训练主流程，只在当前目录覆盖模型定义。
LSTM_PROJECT_DIR = CURRENT_DIR.parent / "LSTM"

if str(CURRENT_DIR) not in sys.path:
    sys.path.insert(0, str(CURRENT_DIR))
if str(LSTM_PROJECT_DIR) not in sys.path:
    sys.path.insert(1, str(LSTM_PROJECT_DIR))

_LSTM_TRAIN_PATH = LSTM_PROJECT_DIR / "train.py"
_LSTM_TRAIN_SOURCE = _LSTM_TRAIN_PATH.read_text(encoding="utf-8").replace(
    "Train a CSI LSTM classifier.",
    "Train a CSI-DeepNet classifier.",
)
_LSTM_TRAIN_SOURCE = _LSTM_TRAIN_SOURCE.replace(
    "Dropout used inside the LSTM stack and before the classifier layer.",
    "Dropout used before the CSI-DeepNet classifier head.",
)

# 用当前文件名编译执行，使复用训练脚本中的默认 outputs/checkpoints 指向 CSI-DeepNet。
exec(compile(_LSTM_TRAIN_SOURCE, str(Path(__file__).resolve()), "exec"), globals())
