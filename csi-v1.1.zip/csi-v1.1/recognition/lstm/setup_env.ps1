param(
    [string]$EnvName = "esp-csi",
    [string]$PythonVersion = "3.10",
    [ValidateSet("auto", "cpu", "cuda")]
    [string]$TorchBackend = "auto"
)

$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Resolve-Path (Join-Path $scriptDir "..\..")
$requirementsPath = Join-Path $scriptDir "requirements.txt"
$logDir = Join-Path $repoRoot "log\log_env"
New-Item -ItemType Directory -Force $logDir | Out-Null

$CondaExe = $null
$candidatePaths = @(
    "E:\App\miniconda3\Scripts\conda.exe",
    "C:\Users\hsj\miniconda3\Scripts\conda.exe"
)
foreach ($candidate in $candidatePaths) {
    if (Test-Path $candidate) {
        $CondaExe = $candidate
        break
    }
}
if (-not $CondaExe) {
    $condaExeCommand = Get-Command conda.exe -ErrorAction SilentlyContinue
    if ($condaExeCommand) {
        $CondaExe = $condaExeCommand.Source
    }
}

function Resolve-EnvPython {
    param([string]$Name)
    $roots = @(
        "C:\Users\hsj\.conda\envs",
        "E:\App\miniconda3\envs",
        (Join-Path $env:USERPROFILE ".conda\envs")
    )
    foreach ($root in $roots) {
        if (-not $root) {
            continue
        }
        $candidate = Join-Path $root "$Name\python.exe"
        if (Test-Path $candidate) {
            return $candidate
        }
    }
    return $null
}

function Invoke-Conda {
    param([string[]]$Arguments)
    & $CondaExe --no-plugins @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Conda command failed: $CondaExe --no-plugins $($Arguments -join ' ')"
    }
}

function Invoke-CondaPython {
    param(
        [string]$Name,
        [string[]]$Arguments
    )
    $envPython = Resolve-EnvPython -Name $Name
    if ($envPython) {
        & $envPython @Arguments
    } else {
        & $CondaExe --no-plugins run -n $Name python @Arguments
    }
    if ($LASTEXITCODE -ne 0) {
        throw "Python command failed in conda env '$Name': python $($Arguments -join ' ')"
    }
}

function Test-CondaEnv {
    param([string]$Name)
    & $CondaExe --no-plugins run -n $Name python --version *> $null
    return $LASTEXITCODE -eq 0
}

if (-not $CondaExe) {
    throw "conda.exe was not found."
}

$resolvedBackend = $TorchBackend
if ($TorchBackend -eq "auto") {
    $resolvedBackend = if (Get-Command nvidia-smi -ErrorAction SilentlyContinue) {
        "cuda"
    } else {
        "cpu"
    }
}

if (-not (Test-CondaEnv -Name $EnvName)) {
    Write-Host "Creating conda environment '$EnvName' with Python $PythonVersion ..."
    Invoke-Conda @("create", "-n", $EnvName, "python=$PythonVersion", "-y")
} else {
    Write-Host "Conda environment '$EnvName' already exists."
}

Write-Host "Upgrading pip ..."
Invoke-CondaPython -Name $EnvName -Arguments @("-m", "pip", "install", "--upgrade", "pip")

Write-Host "Installing torch backend: $resolvedBackend ..."
if ($resolvedBackend -eq "cuda") {
    Invoke-CondaPython -Name $EnvName -Arguments @(
        "-m", "pip", "install", "torch",
        "--index-url", "https://download.pytorch.org/whl/cu121"
    )
} else {
    Invoke-CondaPython -Name $EnvName -Arguments @(
        "-m", "pip", "install", "torch",
        "--index-url", "https://download.pytorch.org/whl/cpu"
    )
}

Write-Host "Installing project dependencies from requirements.txt ..."
Invoke-CondaPython -Name $EnvName -Arguments @("-m", "pip", "install", "-r", $requirementsPath)

$versionProbe = @'
import importlib
import json
import platform

names = ["torch", "numpy", "pandas", "sklearn", "tqdm"]
payload = {"python": platform.python_version()}
for name in names:
    module = importlib.import_module(name)
    payload[name] = getattr(module, "__version__", "unknown")
payload["matplotlib"] = importlib.import_module("matplotlib").__version__
print(json.dumps(payload, ensure_ascii=False))
'@

$envPython = Resolve-EnvPython -Name $EnvName
if (-not $envPython) {
    throw "Failed to resolve python.exe for conda env '$EnvName'."
}
$versionJson = $versionProbe | & $envPython -
if ($LASTEXITCODE -ne 0) {
    throw "Failed to collect installed package versions."
}

$versions = $versionJson | ConvertFrom-Json
$logPath = Join-Path $logDir ("{0}.md" -f (Get-Date -Format "yyyy-MM-dd"))
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$lines = @(
    "## $timestamp"
    ""
    "### Reason"
    "- Added the recognition/lstm PyTorch LSTM environment setup script and executed dependency installation."
    ""
    "### Environment"
    "- conda env: $EnvName"
    "- python: $($versions.python)"
    "- torch backend: $resolvedBackend"
    ""
    "### Installed Packages"
    "- torch: $($versions.torch)"
    "- numpy: $($versions.numpy)"
    "- pandas: $($versions.pandas)"
    "- scikit-learn: $($versions.sklearn)"
    "- tqdm: $($versions.tqdm)"
    "- matplotlib: $($versions.matplotlib)"
    ""
    "### Reproduce"
    "- powershell -ExecutionPolicy Bypass -File recognition/lstm/setup_env.ps1 -EnvName $EnvName -TorchBackend $resolvedBackend"
    ""
    "### Summary"
    "- Updated the conda environment for the CSI LSTM classifier, installed the selected PyTorch backend, and recorded the package versions."
    ""
)

Add-Content -Path $logPath -Value $lines -Encoding utf8
Write-Host "Environment setup completed. Log written to $logPath"
