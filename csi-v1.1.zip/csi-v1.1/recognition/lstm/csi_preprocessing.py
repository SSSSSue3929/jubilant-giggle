"""离线推理与训练共享的 CSI 预处理工具。"""

from __future__ import annotations

import sys
from typing import Any

import numpy as np
from scipy import signal

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
COLLECT_PC_TOOL_ROOT = PROJECT_ROOT / "collect" / "PC"
if str(COLLECT_PC_TOOL_ROOT) not in sys.path:
    sys.path.append(str(COLLECT_PC_TOOL_ROOT))

from model_input_config import (
    get_model_decoded_feature_dim,
    get_model_raw_feature_dim,
)

UI_FILTER_SAMPLE_RATE = 100
UI_FILTER_ORDER = 8
UI_FILTER_CUTOFF_HZ = 20
UI_OUTLIER_DELTA = 2.0
UI_OUTLIER_ROW_THRESHOLD = 16
DEFAULT_FRONT_BASELINE_FRAMES = 10
RAW_CSI_FEATURE_DIM = get_model_raw_feature_dim()
MODEL_INPUT_FEATURE_DIM = get_model_decoded_feature_dim()
UI_FILTER_B, UI_FILTER_A = signal.butter(
    UI_FILTER_ORDER,
    UI_FILTER_CUTOFF_HZ / (UI_FILTER_SAMPLE_RATE / 2),
    "lowpass",
)


def decode_raw_frame_to_amplitudes(frame: np.ndarray) -> np.ndarray:
    """将单帧原始 CSI 字节解码为子载波幅值向量。"""

    vector = np.asarray(frame, dtype=np.float32).reshape(-1)
    if vector.size == MODEL_INPUT_FEATURE_DIM:
        return vector.astype(np.float32, copy=False)
    if vector.size != RAW_CSI_FEATURE_DIM:
        raise ValueError(
            f"Expected raw CSI frame length {RAW_CSI_FEATURE_DIM} or decoded length "
            f"{MODEL_INPUT_FEATURE_DIM}, got {vector.size}."
        )

    amplitudes = np.zeros(MODEL_INPUT_FEATURE_DIM, dtype=np.float32)
    for subcarrier_index in range(MODEL_INPUT_FEATURE_DIM):
        data_index = subcarrier_index * 4
        real_high = int(vector[data_index + 1])
        imag_high = int(vector[data_index + 3])
        real_low = int(vector[data_index]) & 0xFF
        imag_low = int(vector[data_index + 2]) & 0xFF

        real = (((real_high << 12) >> 4) | real_low)
        imag = (((imag_high << 12) >> 4) | imag_low)
        if real > 32767:
            real -= 65536
        if imag > 32767:
            imag -= 65536

        amplitudes[subcarrier_index] = float(np.abs(complex(real, imag)))
    return amplitudes


def decode_raw_sample_to_amplitudes(raw_sample: np.ndarray) -> np.ndarray:
    """逐帧解码整个样本，得到 `[T, F]` 幅值序列。"""

    return np.stack(
        [decode_raw_frame_to_amplitudes(frame) for frame in raw_sample],
        axis=0,
    ).astype(np.float32)


def median_filter_waveform(waveform: np.ndarray) -> np.ndarray:
    """使用与上位机一致的整行突刺修复逻辑去除异常帧。"""

    filtered = waveform.copy()
    for row_index in range(1, waveform.shape[0] - 1):
        outliers_count = 0
        for column_index in range(waveform.shape[1]):
            current_value = waveform[row_index, column_index]
            prev_delta = waveform[row_index - 1, column_index] - current_value
            next_delta = waveform[row_index + 1, column_index] - current_value
            if (
                (prev_delta > UI_OUTLIER_DELTA and next_delta > UI_OUTLIER_DELTA)
                or (prev_delta < -UI_OUTLIER_DELTA and next_delta < -UI_OUTLIER_DELTA)
            ):
                outliers_count += 1

        if outliers_count > UI_OUTLIER_ROW_THRESHOLD:
            for column_index in range(1, waveform.shape[1] - 1):
                filtered[row_index, column_index] = (
                    waveform[row_index - 1, column_index] + waveform[row_index + 1, column_index]
                ) / 2
    return filtered


def apply_ui_lowpass_filter(waveform: np.ndarray) -> np.ndarray:
    """执行与上位机图表一致的低通滤波流程。"""

    median_filtered = median_filter_waveform(waveform)
    try:
        return signal.filtfilt(UI_FILTER_B, UI_FILTER_A, median_filtered.T).T.astype(np.float32)
    except ValueError:
        return median_filtered.astype(np.float32)


def estimate_front_static_baseline(
    waveform: np.ndarray,
    baseline_frames: int,
) -> np.ndarray:
    """使用前静止段中位数估计单样本静态基线。"""

    if baseline_frames <= 0:
        raise ValueError(f"baseline_frames must be positive, got {baseline_frames}.")
    front_window_size = min(int(baseline_frames), int(waveform.shape[0]))
    if front_window_size <= 0:
        raise ValueError("Cannot estimate a baseline from an empty waveform.")
    return np.median(waveform[:front_window_size], axis=0).astype(np.float32)


class PerSampleBaselinePreprocessor:
    """对单个样本执行解码、滤波和前静止段基线扣除。"""

    def __init__(self, baseline_frames: int = DEFAULT_FRONT_BASELINE_FRAMES) -> None:
        baseline_frames = int(baseline_frames)
        if baseline_frames <= 0:
            raise ValueError(f"baseline_frames must be positive, got {baseline_frames}.")
        self.baseline_frames = baseline_frames

    def preprocess(self, raw_sample: np.ndarray) -> np.ndarray:
        amplitudes = decode_raw_sample_to_amplitudes(raw_sample)
        filtered = apply_ui_lowpass_filter(amplitudes)
        baseline = estimate_front_static_baseline(filtered, self.baseline_frames)
        return (filtered - baseline).astype(np.float32)

    def to_dict(self) -> dict[str, Any]:
        return {
            "raw_feature_dim": RAW_CSI_FEATURE_DIM,
            "feature_dim": MODEL_INPUT_FEATURE_DIM,
            "decode_mode": "esp_csi_tool_raw_bytes_to_amplitudes",
            "filter": {
                "name": "ui_lowpass",
                "sample_rate_hz": UI_FILTER_SAMPLE_RATE,
                "order": UI_FILTER_ORDER,
                "cutoff_hz": UI_FILTER_CUTOFF_HZ,
            },
            "sample_baseline": {
                "mode": "per_sample_front_static",
                "frames": self.baseline_frames,
                "statistic": "median",
                "apply_before_filter": False,
                "apply_after_filter": True,
            },
        }
