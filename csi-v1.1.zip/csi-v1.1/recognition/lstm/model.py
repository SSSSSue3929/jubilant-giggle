"""CSI LSTM 分类模型定义。"""

from __future__ import annotations

import torch
from torch import nn


MODEL_TYPE = "lstm"
MODEL_EXTRA_KWARGS: dict[str, int | float] = {}


class CSILSTMClassifier(nn.Module):
    """接收 `[batch, 1, T, F]` 或 `[batch, T, F]` 输入的 LSTM 分类器。"""

    def __init__(
        self,
        input_size: int = 104,
        hidden_size: int = 128,
        num_layers: int = 2,
        num_classes: int = 5,
        dropout: float = 0.3,
    ) -> None:
        super().__init__()
        lstm_dropout = dropout if num_layers > 1 else 0.0
        # LSTM 负责提取时间维度上的动态特征。
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=lstm_dropout,
        )
        # 末端使用 ReLU + Dropout + 全连接层输出分类 logits。
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """执行前向推理，并返回各类别的未归一化分数。"""

        if x.ndim == 4:
            if x.size(1) != 1:
                raise ValueError(
                    f"Expected a single CSI channel, got input shape {tuple(x.shape)}."
                )
            x = x[:, 0, :, :]
        elif x.ndim != 3:
            raise ValueError(
                f"Expected input shape [batch, seq, feat] or [batch, 1, seq, feat], got {tuple(x.shape)}."
            )

        output, _ = self.lstm(x)
        output = output[:, -1, :]
        output = self.relu(output)
        output = self.dropout(output)
        return self.fc(output)
