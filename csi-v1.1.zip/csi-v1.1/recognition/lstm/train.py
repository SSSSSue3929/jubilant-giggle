"""CSI LSTM 训练入口，负责预处理、切分、训练、评估与工件导出。"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path
import sys
from typing import Any

import numpy as np
import torch
from scipy import signal
from torch import nn
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

PROJECT_ROOT = Path(__file__).resolve().parents[2]
# 复用 PC 端 CSI 预处理实现，确保训练链路与实时识别链路保持一致。
COLLECT_PC_TOOL_ROOT = PROJECT_ROOT / "collect" / "PC"
if str(COLLECT_PC_TOOL_ROOT) not in sys.path:
    # 追加到 sys.path 末尾，避免覆盖训练目录下本地的 model.py / dataset.py。
    sys.path.append(str(COLLECT_PC_TOOL_ROOT))

from dataset import (
    DEFAULT_DATA_DIR,
    FeatureNormalizer,
    build_cross_session_split,
    build_label_mapping,
    build_same_session_split,
    build_split_manifest,
    discover_class_names,
    discover_samples,
    discover_sessions,
    load_sample_array,
    summarize_samples,
)
from class_config import CLASSIFICATION_COUNT
from model_input_config import (
    format_model_input_shape,
    get_model_decoded_feature_dim,
    get_model_raw_feature_dim,
    get_model_sequence_length,
)
import model as model_module
from model import CSILSTMClassifier
from utils import (
    compute_classification_metrics,
    describe_device,
    ensure_dir,
    load_json,
    save_confusion_matrix_csv,
    save_confusion_matrix_plot,
    save_history_csv,
    save_training_history_plots,
    save_json,
    select_device,
    set_seed,
    timestamp_for_log,
    timestamp_for_name,
)

ALL_EVAL_MODES = [
    "same-session",
    "cross-session",
]
# 当一次运行包含多种评估模式时，按该优先级更新默认 checkpoint。
DEFAULT_CHECKPOINT_PRIORITY = [
    "cross-session",
    "same-session",
]
BEST_ARTIFACT_FILENAMES = [
    "best_model.pt",
    "label_mapping.json",
    "normalizer.json",
    "preprocessing.json",
    "best_confusion_matrix.csv",
    "best_confusion_matrix.png",
]

# 训练侧与上位机侧统一共用一份输入尺度配置，后续只改一个变量即可同步生效。
MODEL_SEQUENCE_LENGTH = get_model_sequence_length()
RAW_CSI_FEATURE_DIM = get_model_raw_feature_dim()
MODEL_INPUT_FEATURE_DIM = get_model_decoded_feature_dim()
MODEL_TYPE = str(getattr(model_module, "MODEL_TYPE", "lstm")).strip() or "lstm"
MODEL_EXTRA_KWARGS = dict(getattr(model_module, "MODEL_EXTRA_KWARGS", {}))
UI_FILTER_SAMPLE_RATE = 100
UI_FILTER_ORDER = 8
UI_FILTER_CUTOFF_HZ = 20
UI_OUTLIER_DELTA = 2.0
UI_OUTLIER_ROW_THRESHOLD = 16
DEFAULT_FRONT_BASELINE_FRAMES = 10
FIXED_SPLIT_CONFIG_VERSION = 1
DEFAULT_SPLIT_CONFIG_PATH = PROJECT_ROOT / "recognition" / "fixed_split_config.json"
UI_FILTER_B, UI_FILTER_A = signal.butter(
    UI_FILTER_ORDER,
    UI_FILTER_CUTOFF_HZ / (UI_FILTER_SAMPLE_RATE / 2),
    "lowpass",
)


class EarlyStopping:
    """根据验证集指标提前终止训练，避免无效迭代。"""

    def __init__(self, patience: int, min_delta: float = 0.0) -> None:
        self.patience = patience
        self.min_delta = min_delta
        self.best_score: float | None = None
        self.counter = 0

    def step(self, score: float) -> bool:
        if self.best_score is None or score > self.best_score + self.min_delta:
            self.best_score = score
            self.counter = 0
            return False
        self.counter += 1
        return self.counter >= self.patience


def split_mode_slug(split_mode: str) -> str:
    """将评估模式名转换为适合路径和 JSON key 的格式。"""

    return split_mode.replace("-", "_")


def deduplicate_preserve_order(items: list[str]) -> list[str]:
    """去重同时保持原有顺序不变。"""

    deduplicated: list[str] = []
    seen: set[str] = set()
    for item in items:
        if item in seen:
            continue
        deduplicated.append(item)
        seen.add(item)
    return deduplicated


def decode_raw_frame_to_amplitudes(frame: np.ndarray) -> np.ndarray:
    """将单帧 104 维原始 CSI 字节解码为 26 个子载波幅度。"""

    vector = np.asarray(frame, dtype=np.float32).reshape(-1)
    if vector.size == MODEL_INPUT_FEATURE_DIM:
        return vector.astype(np.float32, copy=False)
    if vector.size != RAW_CSI_FEATURE_DIM:
        raise ValueError(
            f"Expected raw CSI frame length {RAW_CSI_FEATURE_DIM} or decoded length "
            f"{MODEL_INPUT_FEATURE_DIM}, got {vector.size}."
        )

    amplitudes = np.zeros(MODEL_INPUT_FEATURE_DIM, dtype=np.float32)
    # Rebuild one complex subcarrier from every 4 raw bytes, just like the UI plot decoder.
    for subcarrier_index in range(MODEL_INPUT_FEATURE_DIM):
        data_index = subcarrier_index * 4
        real_high = int(vector[data_index + 1])
        imag_high = int(vector[data_index + 3])
        real_low = int(vector[data_index]) & 0xFF
        imag_low = int(vector[data_index + 2]) & 0xFF

        real = (((real_high << 12) >> 4) | real_low)
        imag = (((imag_high << 12) >> 4) | imag_low)
        if real > 32767:
            real -= 65536
        if imag > 32767:
            imag -= 65536

        amplitudes[subcarrier_index] = float(np.abs(complex(real, imag)))
    return amplitudes


def decode_raw_sample_to_amplitudes(raw_sample: np.ndarray) -> np.ndarray:
    """逐帧解码整个样本，得到 `[T, 26]` 幅度序列。"""

    return np.stack(
        [decode_raw_frame_to_amplitudes(frame) for frame in raw_sample],
        axis=0,
    ).astype(np.float32)


def median_filter_waveform(waveform: np.ndarray) -> np.ndarray:
    """先用 UI 同款中值判定逻辑去除突刺帧。"""

    filtered = waveform.copy()
    for row_index in range(1, waveform.shape[0] - 1):
        outliers_count = 0
        for column_index in range(waveform.shape[1]):
            current_value = waveform[row_index, column_index]
            prev_delta = waveform[row_index - 1, column_index] - current_value
            next_delta = waveform[row_index + 1, column_index] - current_value
            if (
                (prev_delta > UI_OUTLIER_DELTA and next_delta > UI_OUTLIER_DELTA)
                or (prev_delta < -UI_OUTLIER_DELTA and next_delta < -UI_OUTLIER_DELTA)
            ):
                outliers_count += 1

        if outliers_count > UI_OUTLIER_ROW_THRESHOLD:
            for column_index in range(1, waveform.shape[1] - 1):
                filtered[row_index, column_index] = (
                    waveform[row_index - 1, column_index] + waveform[row_index + 1, column_index]
                ) / 2
    return filtered


def apply_ui_lowpass_filter(waveform: np.ndarray) -> np.ndarray:
    """执行与上位机图表一致的低通滤波流程。"""

    median_filtered = median_filter_waveform(waveform)
    try:
        return signal.filtfilt(UI_FILTER_B, UI_FILTER_A, median_filtered.T).T.astype(np.float32)
    except ValueError:
        return median_filtered.astype(np.float32)


def estimate_front_static_baseline(
    waveform: np.ndarray,
    baseline_frames: int,
) -> np.ndarray:
    """用样本前段静止帧的中位数估计当前样本基线。"""

    if baseline_frames <= 0:
        raise ValueError(f"baseline_frames must be positive, got {baseline_frames}.")
    front_window_size = min(int(baseline_frames), int(waveform.shape[0]))
    if front_window_size <= 0:
        raise ValueError("Cannot estimate a baseline from an empty waveform.")
    # Use the front static segment only, so later motion does not leak into the baseline.
    return np.median(waveform[:front_window_size], axis=0).astype(np.float32)


class PerSampleBaselinePreprocessor:
    """对单个样本执行解码、滤波和前静止段基线校准。"""

    def __init__(self, baseline_frames: int = DEFAULT_FRONT_BASELINE_FRAMES) -> None:
        baseline_frames = int(baseline_frames)
        if baseline_frames <= 0:
            raise ValueError(f"baseline_frames must be positive, got {baseline_frames}.")
        self.baseline_frames = baseline_frames

    def preprocess(self, raw_sample: np.ndarray) -> np.ndarray:
        amplitudes = decode_raw_sample_to_amplitudes(raw_sample)
        filtered = apply_ui_lowpass_filter(amplitudes)
        # Estimate the static reference from the filtered front segment so baseline
        # subtraction is less sensitive to impulsive raw-frame noise.
        baseline = estimate_front_static_baseline(filtered, self.baseline_frames)
        return (filtered - baseline).astype(np.float32)

    def to_dict(self) -> dict[str, Any]:
        return {
            "raw_feature_dim": RAW_CSI_FEATURE_DIM,
            "feature_dim": MODEL_INPUT_FEATURE_DIM,
            "decode_mode": "esp_csi_tool_raw_bytes_to_amplitudes",
            "filter": {
                "name": "ui_lowpass",
                "sample_rate_hz": UI_FILTER_SAMPLE_RATE,
                "order": UI_FILTER_ORDER,
                "cutoff_hz": UI_FILTER_CUTOFF_HZ,
            },
            "sample_baseline": {
                "mode": "per_sample_front_static",
                "frames": self.baseline_frames,
                "statistic": "median",
                "apply_before_filter": False,
                "apply_after_filter": True,
            },
        }


def fit_preprocessed_normalizer(
    data_dir: Path,
    samples: list[dict[str, Any]],
    preprocessor: PerSampleBaselinePreprocessor,
) -> FeatureNormalizer:
    """在训练样本经过预处理后统计标准化参数。"""

    sum_vector = np.zeros(MODEL_INPUT_FEATURE_DIM, dtype=np.float64)
    sum_square_vector = np.zeros(MODEL_INPUT_FEATURE_DIM, dtype=np.float64)
    total_rows = 0

    for sample in samples:
        raw_sample = load_sample_array(
            Path(data_dir) / str(sample["relative_path"]),
            sequence_length=MODEL_SEQUENCE_LENGTH,
            feature_dim=RAW_CSI_FEATURE_DIM,
        )
        processed_sample = preprocessor.preprocess(raw_sample)
        flattened = processed_sample.reshape(-1, MODEL_INPUT_FEATURE_DIM)
        sum_vector += flattened.sum(axis=0)
        sum_square_vector += np.square(flattened).sum(axis=0)
        total_rows += flattened.shape[0]

    mean = sum_vector / total_rows
    variance = np.maximum(sum_square_vector / total_rows - np.square(mean), 1e-12)
    std = np.sqrt(variance)
    std[std < 1e-6] = 1.0
    return FeatureNormalizer(mean=mean.astype(np.float32), std=std.astype(np.float32))


class PreprocessedCSIDataset(Dataset[tuple[torch.Tensor, int]]):
    """预加载预处理后的样本，并输出模型直接可用的张量。"""

    def __init__(
        self,
        data_dir: Path,
        samples: list[dict[str, Any]],
        preprocessor: PerSampleBaselinePreprocessor,
        normalizer: FeatureNormalizer | None = None,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.samples = samples
        self.preprocessor = preprocessor
        self.normalizer = normalizer
        self._items: list[tuple[torch.Tensor, int]] = []
        self._preload()

    def _preload(self) -> None:
        for sample in self.samples:
            raw_sample = load_sample_array(
                self.data_dir / str(sample["relative_path"]),
                sequence_length=MODEL_SEQUENCE_LENGTH,
                feature_dim=RAW_CSI_FEATURE_DIM,
            )
            processed_sample = self.preprocessor.preprocess(raw_sample)
            if self.normalizer is not None:
                processed_sample = self.normalizer.transform(processed_sample)
            # 最终张量保持为 [1, 时间窗长度, 解码后特征维度]，与当前模型输入约定一致。
            tensor = torch.from_numpy(processed_sample.astype(np.float32)).unsqueeze(0)
            label = int(sample["label"])
            self._items.append((tensor, label))

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, int]:
        return self._items[index]


def parse_args() -> argparse.Namespace:
    """解析训练脚本命令行参数。"""

    parser = argparse.ArgumentParser(description="Train a CSI LSTM classifier.")
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=DEFAULT_DATA_DIR,
        help="Dataset root that contains session folders.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "outputs",
        help="Directory used to save training reports.",
    )
    parser.add_argument(
        "--checkpoint-dir",
        type=Path,
        default=Path(__file__).resolve().parent / "checkpoints",
        help="Directory used to store default model checkpoints.",
    )
    parser.add_argument(
        "--device",
        choices=["auto", "cpu", "cuda"],
        default="auto",
        help="Training device selection strategy.",
    )
    parser.add_argument(
        "--eval-modes",
        nargs="+",
        choices=ALL_EVAL_MODES,
        default=None,
        help=(
            "One or more evaluation modes to run. "
            "Defaults to all supported modes for the current dataset."
        ),
    )
    parser.add_argument(
        "--eval-mode",
        choices=ALL_EVAL_MODES + ["both", "all"],
        default=None,
        help=argparse.SUPPRESS,
    )
    parser.add_argument("--epochs", type=int, default=100, help="Number of training epochs.")
    parser.add_argument("--batch-size", type=int, default=16, help="Mini-batch size.")
    parser.add_argument("--lr", type=float, default=1e-3, help="Learning rate.")
    parser.add_argument(
        "--weight-decay",
        type=float,
        default=1e-4,
        help="Weight decay used by the Adam optimizer.",
    )
    parser.add_argument(
        "--dropout",
        type=float,
        default=0.4,
        help="Dropout used inside the LSTM stack and before the classifier layer.",
    )
    parser.add_argument(
        "--baseline-frames",
        type=int,
        default=DEFAULT_FRONT_BASELINE_FRAMES,
        help="Number of front frames used to estimate each sample's static baseline.",
    )
    parser.add_argument(
        "--early-stop-patience",
        type=int,
        default=10,
        help="Stop training when validation F1 does not improve for this many epochs.",
    )
    parser.add_argument(
        "--early-stop-min-delta",
        type=float,
        default=0.0,
        help="Minimum validation F1 improvement required to reset early stopping.",
    )
    parser.add_argument(
        "--scheduler-patience",
        type=int,
        default=3,
        help="ReduceLROnPlateau patience measured in epochs.",
    )
    parser.add_argument(
        "--scheduler-factor",
        type=float,
        default=0.5,
        help="Factor used by ReduceLROnPlateau when validation F1 plateaus.",
    )
    parser.add_argument(
        "--min-lr",
        type=float,
        default=1e-5,
        help="Minimum learning rate used by ReduceLROnPlateau.",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed.")
    parser.add_argument(
        "--val-ratio",
        type=float,
        default=0.2,
        help="Validation split ratio. 0.2 means a 4:1 train/validation split.",
    )
    parser.add_argument(
        "--num-workers",
        type=int,
        default=0,
        help="DataLoader worker count. Keep 0 on Windows unless you need more.",
    )
    parser.add_argument(
        "--run-name",
        type=str,
        default="",
        help="Optional run name. Defaults to a timestamp.",
    )
    parser.add_argument(
        "--split-config-path",
        type=Path,
        default=DEFAULT_SPLIT_CONFIG_PATH,
        help=(
            "Shared split configuration path. The first training run generates this file, "
            "and later runs reuse the same dataset split."
        ),
    )
    parser.add_argument(
        "--regenerate-split-config",
        action="store_true",
        help="Overwrite the existing shared split configuration with the current dataset split.",
    )
    return parser.parse_args()


def resolve_requested_eval_modes(args: argparse.Namespace) -> tuple[list[str], bool]:
    """解析用户请求的评估模式，并返回是否启用严格校验。"""

    if args.eval_modes and args.eval_mode:
        raise RuntimeError("Use either --eval-modes or --eval-mode, not both.")

    if args.eval_modes:
        return deduplicate_preserve_order(args.eval_modes), True

    if args.eval_mode:
        if args.eval_mode == "both":
            return ["same-session", "cross-session"], True
        if args.eval_mode == "all":
            return list(ALL_EVAL_MODES), False
        return [args.eval_mode], True

    #return list(ALL_EVAL_MODES), False
    return ["same-session", "cross-session"], False


def validate_eval_mode(
    eval_mode: str,
    session_count: int,
) -> str | None:
    """检查指定评估模式在当前数据集下是否可执行。"""

    if eval_mode == "same-session":
        return None if session_count >= 1 else "same-session evaluation requires at least one session."
    if eval_mode == "cross-session":
        return (
            None
            if session_count >= 2
            else "cross-session evaluation requires at least two sessions."
        )
    raise ValueError(f"Unsupported evaluation mode: {eval_mode}")


def build_fixed_split_entry(
    *,
    train_samples: list[dict[str, Any]],
    val_samples: list[dict[str, Any]],
    train_sessions: list[str],
    val_sessions: list[str],
) -> dict[str, Any]:
    """将一次固定划分整理为可复用的配置片段。"""

    return {
        "train_sessions": list(train_sessions),
        "val_sessions": list(val_sessions),
        "train_summary": summarize_samples(train_samples),
        "val_summary": summarize_samples(val_samples),
        "train_relative_paths": [str(sample["relative_path"]) for sample in train_samples],
        "val_relative_paths": [str(sample["relative_path"]) for sample in val_samples],
    }


def build_sample_index(samples: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """按相对路径索引样本，便于从固定划分配置中恢复样本列表。"""

    sample_index: dict[str, dict[str, Any]] = {}
    for sample in samples:
        relative_path = str(sample["relative_path"])
        if relative_path in sample_index:
            raise RuntimeError(f"Duplicate sample path detected: {relative_path}")
        sample_index[relative_path] = {
            "relative_path": relative_path,
            "session_name": str(sample["session_name"]),
            "class_name": str(sample["class_name"]),
            "label": int(sample["label"]),
        }
    return sample_index


def resolve_samples_from_relative_paths(
    *,
    sample_index: dict[str, dict[str, Any]],
    relative_paths: list[str],
    split_name: str,
) -> list[dict[str, Any]]:
    """根据固定配置中保存的相对路径，恢复本次训练使用的样本列表。"""

    resolved_samples: list[dict[str, Any]] = []
    for relative_path in relative_paths:
        key = str(relative_path)
        if key not in sample_index:
            raise RuntimeError(
                f"Fixed split config references missing sample {key} in {split_name}."
            )
        resolved_samples.append(dict(sample_index[key]))
    return resolved_samples


def build_fixed_split_config(
    *,
    data_dir: Path,
    class_names: list[str],
    label_mapping: dict[str, int],
    session_names: list[str],
    all_samples: list[dict[str, Any]],
    seed: int,
    val_ratio: float,
) -> dict[str, Any]:
    """首次训练时生成共享的数据集划分配置。"""

    same_train, same_val, same_train_sessions, same_val_sessions = build_same_session_split(
        data_dir=data_dir,
        label_mapping=label_mapping,
        val_ratio=val_ratio,
        seed=seed,
    )

    split_payload: dict[str, Any] = {
        "same_session": build_fixed_split_entry(
            train_samples=same_train,
            val_samples=same_val,
            train_sessions=same_train_sessions,
            val_sessions=same_val_sessions,
        )
    }

    if len(session_names) >= 2:
        cross_train, cross_val, cross_train_sessions, cross_val_sessions = (
            build_cross_session_split(
                data_dir=data_dir,
                label_mapping=label_mapping,
                val_ratio=val_ratio,
                seed=seed,
            )
        )
        split_payload["cross_session"] = build_fixed_split_entry(
            train_samples=cross_train,
            val_samples=cross_val,
            train_sessions=cross_train_sessions,
            val_sessions=cross_val_sessions,
        )

    return {
        "version": FIXED_SPLIT_CONFIG_VERSION,
        "generated_at": timestamp_for_log(),
        "dataset_root": str(Path(data_dir).resolve()),
        "class_names": list(class_names),
        "label_mapping": dict(label_mapping),
        "session_names": list(session_names),
        "all_samples_summary": summarize_samples(all_samples),
        "all_samples": [dict(sample) for sample in all_samples],
        "split_args": {
            "seed": int(seed),
            "val_ratio": float(val_ratio),
        },
        "splits": split_payload,
    }


def validate_fixed_split_config(
    *,
    fixed_split_config: dict[str, Any],
    data_dir: Path,
    class_names: list[str],
    label_mapping: dict[str, int],
    session_names: list[str],
    all_samples: list[dict[str, Any]],
) -> None:
    """校验共享划分配置与当前数据集是否一致。"""

    version = int(fixed_split_config.get("version", 0) or 0)
    if version != FIXED_SPLIT_CONFIG_VERSION:
        raise RuntimeError(
            "Unsupported fixed split config version. "
            f"Expected {FIXED_SPLIT_CONFIG_VERSION}, got {version}."
        )

    config_dataset_root = Path(str(fixed_split_config.get("dataset_root", ""))).resolve()
    if config_dataset_root != Path(data_dir).resolve():
        raise RuntimeError(
            "The fixed split config was generated for a different dataset root: "
            f"{config_dataset_root} != {Path(data_dir).resolve()}. "
            "If you intentionally switched datasets, rerun with --regenerate-split-config."
        )

    config_class_names = list(fixed_split_config.get("class_names", []))
    if config_class_names != class_names:
        raise RuntimeError(
            "The fixed split config class order does not match the current dataset: "
            f"{config_class_names} != {class_names}. "
            "If the dataset classes changed, rerun with --regenerate-split-config."
        )

    config_label_mapping = dict(fixed_split_config.get("label_mapping", {}))
    if config_label_mapping != label_mapping:
        raise RuntimeError(
            "The fixed split config label mapping does not match the current dataset. "
            "If the class configuration changed, rerun with --regenerate-split-config."
        )

    config_session_names = list(fixed_split_config.get("session_names", []))
    if config_session_names != session_names:
        raise RuntimeError(
            "The fixed split config session list does not match the current dataset. "
            "If the session set changed, rerun with --regenerate-split-config."
        )

    config_samples = fixed_split_config.get("all_samples", [])
    if not isinstance(config_samples, list):
        raise RuntimeError("The fixed split config is missing the all_samples list.")

    current_paths = {str(sample["relative_path"]) for sample in all_samples}
    config_paths = {
        str(sample.get("relative_path", ""))
        for sample in config_samples
        if isinstance(sample, dict)
    }
    missing_paths = sorted(config_paths - current_paths)
    extra_paths = sorted(current_paths - config_paths)
    if missing_paths or extra_paths:
        preview: list[str] = []
        if missing_paths:
            preview.append(f"missing={missing_paths[:5]}")
        if extra_paths:
            preview.append(f"extra={extra_paths[:5]}")
        raise RuntimeError(
            "The current dataset contents do not match the fixed split config. "
            + "; ".join(preview)
            + ". If you intentionally updated the dataset, rerun with "
            "--regenerate-split-config."
        )


def prepare_fixed_split_config(
    *,
    config_path: Path,
    regenerate: bool,
    data_dir: Path,
    class_names: list[str],
    label_mapping: dict[str, int],
    session_names: list[str],
    all_samples: list[dict[str, Any]],
    seed: int,
    val_ratio: float,
) -> dict[str, Any]:
    """首次生成共享划分配置，后续训练直接复用。"""

    resolved_config_path = Path(config_path)
    config_exists = resolved_config_path.exists()
    if regenerate or not config_exists:
        fixed_split_config = build_fixed_split_config(
            data_dir=data_dir,
            class_names=class_names,
            label_mapping=label_mapping,
            session_names=session_names,
            all_samples=all_samples,
            seed=seed,
            val_ratio=val_ratio,
        )
        save_json(resolved_config_path, fixed_split_config)
        action = "Regenerated" if regenerate and config_exists else "Generated"
        print(
            f"[{timestamp_for_log()}] {action} shared split config: {resolved_config_path}"
        )
        return fixed_split_config

    fixed_split_config = load_json(resolved_config_path)
    validate_fixed_split_config(
        fixed_split_config=fixed_split_config,
        data_dir=data_dir,
        class_names=class_names,
        label_mapping=label_mapping,
        session_names=session_names,
        all_samples=all_samples,
    )
    stored_args = dict(fixed_split_config.get("split_args", {}))
    print(
        f"[{timestamp_for_log()}] Loaded shared split config from {resolved_config_path}. "
        f"Stored split args: seed={stored_args.get('seed')}, "
        f"val_ratio={stored_args.get('val_ratio')}."
    )
    return fixed_split_config


def resolve_single_split_from_fixed_config(
    *,
    fixed_split_config: dict[str, Any],
    split_mode: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[str]]:
    """从共享划分配置中恢复单次切分实验所需的数据。"""

    split_key = split_mode_slug(split_mode)
    splits_payload = dict(fixed_split_config.get("splits", {}))
    split_entry = splits_payload.get(split_key)
    if not isinstance(split_entry, dict):
        raise RuntimeError(f"Fixed split config does not contain {split_key}.")

    sample_index = build_sample_index(list(fixed_split_config.get("all_samples", [])))
    train_samples = resolve_samples_from_relative_paths(
        sample_index=sample_index,
        relative_paths=list(split_entry.get("train_relative_paths", [])),
        split_name=f"{split_key}.train",
    )
    val_samples = resolve_samples_from_relative_paths(
        sample_index=sample_index,
        relative_paths=list(split_entry.get("val_relative_paths", [])),
        split_name=f"{split_key}.val",
    )
    return (
        train_samples,
        val_samples,
        list(split_entry.get("train_sessions", [])),
        list(split_entry.get("val_sessions", [])),
    )


def train_one_epoch(
    model: nn.Module,
    dataloader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    class_names: list[str],
    epoch_index: int,
    total_epochs: int,
    split_mode: str,
) -> dict[str, Any]:
    """执行一个训练 epoch，并返回完整训练分类指标。"""

    model.train()
    total_loss = 0.0
    total_correct = 0
    total_items = 0
    y_true: list[int] = []
    y_pred: list[int] = []

    progress = tqdm(
        dataloader,
        desc=f"{split_mode} Epoch {epoch_index}/{total_epochs} [train]",
        leave=False,
    )
    for features, labels in progress:
        features = features.to(device)
        labels = labels.to(device)

        optimizer.zero_grad(set_to_none=True)
        logits = model(features)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()

        predictions = torch.argmax(logits, dim=1)
        batch_size = labels.size(0)
        total_loss += loss.item() * batch_size
        total_correct += (predictions == labels).sum().item()
        total_items += batch_size
        y_true.extend(labels.detach().cpu().tolist())
        y_pred.extend(predictions.detach().cpu().tolist())

        progress.set_postfix(
            loss=f"{total_loss / max(total_items, 1):.4f}",
            acc=f"{total_correct / max(total_items, 1):.4f}",
        )

    metrics = compute_classification_metrics(
        y_true=y_true,
        y_pred=y_pred,
        label_ids=list(range(len(class_names))),
    )
    metrics["loss"] = total_loss / max(total_items, 1)
    return metrics


def evaluate(
    model: nn.Module,
    dataloader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
    class_names: list[str],
    epoch_index: int,
    total_epochs: int,
    split_mode: str,
) -> dict[str, Any]:
    """在验证集上评估模型，并返回完整分类指标。"""

    model.eval()
    total_loss = 0.0
    total_items = 0
    y_true: list[int] = []
    y_pred: list[int] = []

    progress = tqdm(
        dataloader,
        desc=f"{split_mode} Epoch {epoch_index}/{total_epochs} [val]",
        leave=False,
    )
    with torch.no_grad():
        for features, labels in progress:
            features = features.to(device)
            labels = labels.to(device)
            logits = model(features)
            loss = criterion(logits, labels)

            predictions = torch.argmax(logits, dim=1)
            batch_size = labels.size(0)
            total_loss += loss.item() * batch_size
            total_items += batch_size

            y_true.extend(labels.cpu().tolist())
            y_pred.extend(predictions.cpu().tolist())

            running_accuracy = sum(int(a == b) for a, b in zip(y_true, y_pred)) / max(
                len(y_true), 1
            )
            progress.set_postfix(
                loss=f"{total_loss / max(total_items, 1):.4f}",
                acc=f"{running_accuracy:.4f}",
            )

    metrics = compute_classification_metrics(
        y_true=y_true,
        y_pred=y_pred,
        label_ids=list(range(len(class_names))),
    )
    metrics["loss"] = total_loss / max(total_items, 1)
    return metrics


def save_best_artifacts(
    target_dir: Path,
    checkpoint_payload: dict[str, Any],
    label_mapping: dict[str, int],
    normalizer_payload: dict[str, Any],
    preprocessing_payload: dict[str, Any],
    confusion_matrix: list[list[int]],
    class_names: list[str],
) -> None:
    """保存当前最优模型及其配套元数据。"""

    ensure_dir(target_dir)
    torch.save(checkpoint_payload, target_dir / "best_model.pt")
    save_json(target_dir / "label_mapping.json", label_mapping)
    save_json(target_dir / "normalizer.json", normalizer_payload)
    save_json(target_dir / "preprocessing.json", preprocessing_payload)
    save_confusion_matrix_csv(
        target_dir / "best_confusion_matrix.csv",
        confusion_matrix,
        class_names,
    )
    save_confusion_matrix_plot(
        target_dir / "best_confusion_matrix.png",
        confusion_matrix,
        class_names,
        normalize=True,
        title="Best Validation Confusion Matrix",
    )


def copy_best_artifacts(source_dir: Path, target_dir: Path) -> None:
    """将指定模式下的最佳工件复制为默认 checkpoint。"""

    ensure_dir(target_dir)
    for filename in BEST_ARTIFACT_FILENAMES:
        shutil.copy2(source_dir / filename, target_dir / filename)


def select_default_checkpoint_mode(executed_eval_modes: list[str]) -> str | None:
    """按预设优先级选择默认导出的评估模式。"""

    for eval_mode in DEFAULT_CHECKPOINT_PRIORITY:
        if eval_mode in executed_eval_modes:
            return eval_mode
    return executed_eval_modes[0] if executed_eval_modes else None


def run_single_split_training(
    *,
    split_mode: str,
    display_name: str,
    args: argparse.Namespace,
    device: torch.device,
    class_names: list[str],
    label_mapping: dict[str, int],
    run_dir: Path,
    train_samples: list[dict[str, Any]],
    val_samples: list[dict[str, Any]],
    train_sessions: list[str],
    val_sessions: list[str],
    extra_summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """运行一次固定切分训练，并保存该切分的全部结果。"""

    split_slug = split_mode_slug(split_mode)
    # Each sample first subtracts its own front static baseline, then the train set
    # provides the global normalization statistics.
    preprocessor = PerSampleBaselinePreprocessor(
        baseline_frames=args.baseline_frames,
    )
    preprocessing_payload = preprocessor.to_dict()
    normalizer = fit_preprocessed_normalizer(args.data_dir, train_samples, preprocessor)
    normalizer_payload = normalizer.to_dict()

    split_manifest = build_split_manifest(
        dataset_root=args.data_dir,
        train_samples=train_samples,
        val_samples=val_samples,
        split_mode=split_slug,
        train_sessions=train_sessions,
        val_sessions=val_sessions,
    )
    save_json(run_dir / "split_manifest.json", split_manifest)
    save_json(run_dir / "label_mapping.json", label_mapping)
    save_json(run_dir / "normalizer.json", normalizer_payload)
    save_json(run_dir / "preprocessing.json", preprocessing_payload)

    train_dataset = PreprocessedCSIDataset(
        args.data_dir,
        train_samples,
        preprocessor=preprocessor,
        normalizer=normalizer,
    )
    val_dataset = PreprocessedCSIDataset(
        args.data_dir,
        val_samples,
        preprocessor=preprocessor,
        normalizer=normalizer,
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )

    model_kwargs = {
        "input_size": MODEL_INPUT_FEATURE_DIM,
        "hidden_size": 128,
        "num_layers": 2,
        "num_classes": len(class_names),
        "dropout": args.dropout,
    }
    # 不同模型只需在各自 model.py 声明额外参数，训练与实时推理会一起保存和恢复。
    model_kwargs.update(MODEL_EXTRA_KWARGS)
    model = CSILSTMClassifier(**model_kwargs).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )
    scheduler = ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=args.scheduler_factor,
        patience=args.scheduler_patience,
        min_lr=args.min_lr,
    )
    early_stopper = EarlyStopping(
        patience=args.early_stop_patience,
        min_delta=args.early_stop_min_delta,
    )

    print(
        f"[{timestamp_for_log()}] {display_name} train sessions: {train_sessions} | "
        f"val sessions: {val_sessions}"
    )
    print(
        f"[{timestamp_for_log()}] {display_name} train samples: {len(train_samples)}, "
        f"val samples: {len(val_samples)}."
    )

    history: list[dict[str, Any]] = []
    best_epoch = -1
    best_metrics: dict[str, Any] | None = None
    stopped_early = False
    final_epoch = 0

    for epoch_index in range(1, args.epochs + 1):
        final_epoch = epoch_index
        train_metrics = train_one_epoch(
            model=model,
            dataloader=train_loader,
            criterion=criterion,
            optimizer=optimizer,
            device=device,
            class_names=class_names,
            epoch_index=epoch_index,
            total_epochs=args.epochs,
            split_mode=display_name,
        )
        val_metrics = evaluate(
            model=model,
            dataloader=val_loader,
            criterion=criterion,
            device=device,
            class_names=class_names,
            epoch_index=epoch_index,
            total_epochs=args.epochs,
            split_mode=display_name,
        )

        epoch_record = {
            "epoch": epoch_index,
            "lr": round(float(optimizer.param_groups[0]["lr"]), 8),
            "train_loss": round(train_metrics["loss"], 6),
            "train_accuracy": round(train_metrics["accuracy"], 6),
            "train_precision": round(train_metrics["precision"], 6),
            "train_recall": round(train_metrics["recall"], 6),
            "train_f1": round(train_metrics["f1"], 6),
            "val_loss": round(val_metrics["loss"], 6),
            "val_accuracy": round(val_metrics["accuracy"], 6),
            "val_precision": round(val_metrics["precision"], 6),
            "val_recall": round(val_metrics["recall"], 6),
            "val_f1": round(val_metrics["f1"], 6),
        }
        history.append(epoch_record)
        print(
            f"{display_name} Epoch {epoch_index:02d}/{args.epochs} | "
            f"lr={optimizer.param_groups[0]['lr']:.6f} "
            f"train_loss={train_metrics['loss']:.4f} "
            f"train_acc={train_metrics['accuracy']:.4f} "
            f"train_f1={train_metrics['f1']:.4f} "
            f"val_loss={val_metrics['loss']:.4f} "
            f"val_acc={val_metrics['accuracy']:.4f} "
            f"val_precision={val_metrics['precision']:.4f} "
            f"val_recall={val_metrics['recall']:.4f} "
            f"val_f1={val_metrics['f1']:.4f}"
        )

        if best_metrics is None or val_metrics["f1"] > best_metrics["f1"]:
            best_epoch = epoch_index
            best_metrics = val_metrics
            checkpoint_payload = {
                "model_type": MODEL_TYPE,
                "model_kwargs": model_kwargs,
                "model_state_dict": model.state_dict(),
                "input_size": MODEL_INPUT_FEATURE_DIM,
                "input_channels": 1,
                "hidden_size": 128,
                "num_layers": 2,
                "num_classes": len(class_names),
                "configured_class_count": CLASSIFICATION_COUNT,
                "dropout": args.dropout,
                "class_names": class_names,
                "label_mapping": label_mapping,
                "normalizer": normalizer_payload,
                "preprocessing": preprocessing_payload,
                "best_epoch": best_epoch,
                "best_metrics": {
                    key: value
                    for key, value in val_metrics.items()
                    if key != "confusion_matrix"
                },
                "sequence_length": MODEL_SEQUENCE_LENGTH,
                "raw_input_shape": [MODEL_SEQUENCE_LENGTH, RAW_CSI_FEATURE_DIM],
                "model_input_shape": [MODEL_SEQUENCE_LENGTH, MODEL_INPUT_FEATURE_DIM],
                "split_mode": split_slug,
                "train_sessions": train_sessions,
                "val_sessions": val_sessions,
            }
            save_best_artifacts(
                target_dir=run_dir,
                checkpoint_payload=checkpoint_payload,
                label_mapping=label_mapping,
                normalizer_payload=normalizer_payload,
                preprocessing_payload=preprocessing_payload,
                confusion_matrix=val_metrics["confusion_matrix"],
                class_names=class_names,
            )

        scheduler.step(val_metrics["f1"])
        if early_stopper.step(val_metrics["f1"]):
            stopped_early = True
            print(
                f"[{timestamp_for_log()}] {display_name} early stopping triggered at epoch "
                f"{epoch_index}. Best epoch remains {best_epoch}."
            )
            break

    if best_metrics is None:
        raise RuntimeError("Training finished without producing validation metrics.")

    save_history_csv(run_dir / "history.csv", history)
    history_plot_paths = save_training_history_plots(run_dir, history)
    summary: dict[str, Any] = {
        "run_name": run_dir.name,
        "split_mode": split_slug,
        "display_name": display_name,
        "data_dir": str(args.data_dir),
        "device": str(device),
        "class_names": class_names,
        "configured_class_count": CLASSIFICATION_COUNT,
        "input_size": MODEL_INPUT_FEATURE_DIM,
        "raw_input_size": RAW_CSI_FEATURE_DIM,
        "raw_input_shape": [MODEL_SEQUENCE_LENGTH, RAW_CSI_FEATURE_DIM],
        "model_input_shape": [MODEL_SEQUENCE_LENGTH, MODEL_INPUT_FEATURE_DIM],
        "train_sessions": train_sessions,
        "val_sessions": val_sessions,
        "train_summary": summarize_samples(train_samples),
        "val_summary": summarize_samples(val_samples),
        "seed": args.seed,
        "epochs": args.epochs,
        "completed_epochs": final_epoch,
        "batch_size": args.batch_size,
        "learning_rate": args.lr,
        "weight_decay": args.weight_decay,
        "dropout": args.dropout,
        "scheduler_factor": args.scheduler_factor,
        "scheduler_patience": args.scheduler_patience,
        "min_lr": args.min_lr,
        "early_stop_patience": args.early_stop_patience,
        "early_stop_min_delta": args.early_stop_min_delta,
        "stopped_early": stopped_early,
        "best_epoch": best_epoch,
        "best_metrics": {
            key: value for key, value in best_metrics.items() if key != "confusion_matrix"
        },
        "history_plot_paths": history_plot_paths,
        "preprocessing": preprocessing_payload,
        "train_size": len(train_samples),
        "val_size": len(val_samples),
    }
    if extra_summary:
        summary.update(extra_summary)
    save_json(run_dir / "summary.json", summary)
    print(f"[{timestamp_for_log()}] {display_name} training completed. Best epoch: {best_epoch}.")
    print(
        f"[{timestamp_for_log()}] {display_name} best val metrics: "
        f"acc={best_metrics['accuracy']:.4f}, "
        f"precision={best_metrics['precision']:.4f}, "
        f"recall={best_metrics['recall']:.4f}, "
        f"f1={best_metrics['f1']:.4f}."
    )
    return summary


def run_single_mode_experiment(
    *,
    split_mode: str,
    args: argparse.Namespace,
    device: torch.device,
    class_names: list[str],
    label_mapping: dict[str, int],
    mode_run_dir: Path,
    prepared_split: (
        tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[str]] | None
    ) = None,
) -> dict[str, Any]:
    """执行 same-session 或 cross-session 单次切分实验。"""

    if prepared_split is not None:
        train_samples, val_samples, train_sessions, val_sessions = prepared_split
    elif split_mode == "same-session":
        train_samples, val_samples, train_sessions, val_sessions = build_same_session_split(
            data_dir=args.data_dir,
            label_mapping=label_mapping,
            val_ratio=args.val_ratio,
            seed=args.seed,
        )
    elif split_mode == "cross-session":
        train_samples, val_samples, train_sessions, val_sessions = build_cross_session_split(
            data_dir=args.data_dir,
            label_mapping=label_mapping,
            val_ratio=args.val_ratio,
            seed=args.seed,
        )
    else:
        raise ValueError(f"Unsupported single-split mode: {split_mode}")

    summary = run_single_split_training(
        split_mode=split_mode,
        display_name=split_mode,
        args=args,
        device=device,
        class_names=class_names,
        label_mapping=label_mapping,
        run_dir=mode_run_dir,
        train_samples=train_samples,
        val_samples=val_samples,
        train_sessions=train_sessions,
        val_sessions=val_sessions,
    )
    return {
        "summary": summary,
        "artifact_dir": mode_run_dir,
    }


def compute_generalization_gap(
    same_session_summary: dict[str, Any],
    cross_session_summary: dict[str, Any],
) -> dict[str, float]:
    """计算 same-session 与 cross-session 之间的泛化差距。"""

    gap: dict[str, float] = {}
    for metric_name in ["accuracy", "precision", "recall", "f1", "loss"]:
        same_value = same_session_summary["best_metrics"][metric_name]
        cross_value = cross_session_summary["best_metrics"][metric_name]
        gap[f"{metric_name}_gap"] = float(same_value - cross_value)
    return gap


def main() -> None:
    """训练脚本主入口。"""

    args = parse_args()
    set_seed(args.seed)

    session_names = discover_sessions(args.data_dir)
    if not session_names:
        raise RuntimeError(f"No session directories were found under {args.data_dir}.")

    requested_eval_modes, strict_validation = resolve_requested_eval_modes(args)
    class_names = discover_class_names(args.data_dir, session_names=session_names)
    label_mapping = build_label_mapping(class_names=class_names)
    all_samples = discover_samples(args.data_dir, label_mapping)
    fixed_split_config = prepare_fixed_split_config(
        config_path=args.split_config_path,
        regenerate=args.regenerate_split_config,
        data_dir=args.data_dir,
        class_names=class_names,
        label_mapping=label_mapping,
        session_names=session_names,
        all_samples=all_samples,
        seed=args.seed,
        val_ratio=args.val_ratio,
    )

    executable_eval_modes: list[str] = []
    skipped_eval_modes: dict[str, str] = {}
    for eval_mode in requested_eval_modes:
        validation_error = validate_eval_mode(
            eval_mode=eval_mode,
            session_count=len(session_names),
        )
        if validation_error is None:
            executable_eval_modes.append(eval_mode)
            continue
        if strict_validation:
            raise RuntimeError(validation_error)
        skipped_eval_modes[split_mode_slug(eval_mode)] = validation_error
        print(f"[{timestamp_for_log()}] Skipping {eval_mode}: {validation_error}")

    if not executable_eval_modes:
        raise RuntimeError("No evaluation modes can run with the current dataset.")

    print(f"[{timestamp_for_log()}] Loading dataset from {args.data_dir}.")
    print(f"[{timestamp_for_log()}] Discovered sessions: {session_names}")
    print(
        f"[{timestamp_for_log()}] Configured classification count: "
        f"{CLASSIFICATION_COUNT}"
    )
    print(
        f"[{timestamp_for_log()}] Configured raw model input shape: "
        f"{format_model_input_shape()}"
    )
    print(f"[{timestamp_for_log()}] Discovered classes: {class_names}")
    print(f"[{timestamp_for_log()}] Requested eval modes: {requested_eval_modes}")
    print(f"[{timestamp_for_log()}] Executing eval modes: {executable_eval_modes}")

    device = select_device(args.device)
    print(f"[{timestamp_for_log()}] {describe_device(device)}")

    run_name = args.run_name or f"train_{timestamp_for_name()}"
    root_run_dir = ensure_dir(args.output_dir / run_name)
    checkpoint_dir = ensure_dir(args.checkpoint_dir)
    use_mode_subdirs = len(executable_eval_modes) > 1

    experiment_summaries: dict[str, dict[str, Any]] = {}
    artifact_sources: dict[str, Path] = {}
    for eval_mode in executable_eval_modes:
        mode_slug = split_mode_slug(eval_mode)
        mode_run_dir = ensure_dir(root_run_dir / mode_slug) if use_mode_subdirs else root_run_dir

        if eval_mode in {"same-session", "cross-session"}:
            prepared_split = resolve_single_split_from_fixed_config(
                fixed_split_config=fixed_split_config,
                split_mode=eval_mode,
            )
            result = run_single_mode_experiment(
                split_mode=eval_mode,
                args=args,
                device=device,
                class_names=class_names,
                label_mapping=label_mapping,
                mode_run_dir=mode_run_dir,
                prepared_split=prepared_split,
            )
        else:
            raise ValueError(f"Unsupported evaluation mode: {eval_mode}")

        experiment_summaries[mode_slug] = result["summary"]
        artifact_sources[eval_mode] = result["artifact_dir"]

    default_checkpoint_mode = select_default_checkpoint_mode(executable_eval_modes)
    default_checkpoint_source: str | None = None
    if default_checkpoint_mode is not None:
        default_source_dir = artifact_sources[default_checkpoint_mode]
        copy_best_artifacts(default_source_dir, checkpoint_dir)
        default_checkpoint_source = str(default_source_dir)
        print(
            f"[{timestamp_for_log()}] Updated default checkpoint from {default_checkpoint_mode}: "
            f"{default_source_dir}"
        )

    comparison_summary: dict[str, Any] = {
        "run_name": run_name,
        "data_dir": str(args.data_dir),
        "class_names": class_names,
        "configured_class_count": CLASSIFICATION_COUNT,
        "raw_input_shape": [MODEL_SEQUENCE_LENGTH, RAW_CSI_FEATURE_DIM],
        "model_input_shape": [MODEL_SEQUENCE_LENGTH, MODEL_INPUT_FEATURE_DIM],
        "sessions": session_names,
        "requested_eval_modes": requested_eval_modes,
        "executed_eval_modes": executable_eval_modes,
        "skipped_eval_modes": skipped_eval_modes,
        "fixed_split_config_path": str(Path(args.split_config_path).resolve()),
        "default_checkpoint_mode": default_checkpoint_mode,
        "default_checkpoint_source": default_checkpoint_source,
        "summaries": experiment_summaries,
    }
    if "same_session" in experiment_summaries and "cross_session" in experiment_summaries:
        generalization_gap = compute_generalization_gap(
            same_session_summary=experiment_summaries["same_session"],
            cross_session_summary=experiment_summaries["cross_session"],
        )
        comparison_summary["generalization_gap"] = generalization_gap
        print(
            f"[{timestamp_for_log()}] Generalization gap (same-session - cross-session): "
            f"acc={generalization_gap['accuracy_gap']:.4f}, "
            f"f1={generalization_gap['f1_gap']:.4f}."
        )
    save_json(root_run_dir / "generalization_summary.json", comparison_summary)


if __name__ == "__main__":
    main()
