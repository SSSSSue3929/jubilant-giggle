"""CSI LSTM 识别训练与推理包。"""
