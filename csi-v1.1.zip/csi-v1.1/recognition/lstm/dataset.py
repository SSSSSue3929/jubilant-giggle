"""LSTM 训练侧的数据发现、切分、标准化与样本加载工具。"""

from __future__ import annotations

import ast
import csv
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from class_config import select_configured_class_names

# 训练数据根目录已经迁移到仓库根目录下的 data。
DEFAULT_DATA_DIR = PROJECT_ROOT / "data"
DEFAULT_SEQUENCE_LENGTH = 130
DEFAULT_FEATURE_DIM = 104
DEFAULT_CHANNEL_DIM = 1


@dataclass
class FeatureNormalizer:
    """保存逐特征均值与标准差，并负责执行标准化。"""

    mean: np.ndarray
    std: np.ndarray

    def transform(self, sample: np.ndarray) -> np.ndarray:
        return (sample - self.mean) / self.std

    def to_dict(self) -> dict[str, Any]:
        return {
            "mean": self.mean.astype(float).tolist(),
            "std": self.std.astype(float).tolist(),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "FeatureNormalizer":
        return cls(
            mean=np.asarray(payload["mean"], dtype=np.float32),
            std=np.asarray(payload["std"], dtype=np.float32),
        )


def discover_sessions(data_dir: Path = DEFAULT_DATA_DIR) -> list[str]:
    """发现数据根目录下可参与训练的 session 文件夹。"""

    root_dir = Path(data_dir)
    if not root_dir.exists():
        return []
    return sorted(
        entry.name
        for entry in root_dir.iterdir()
        if entry.is_dir() and not entry.name.startswith(".")
    )


def discover_session_class_names(session_dir: Path) -> list[str]:
    """读取单个 session 下的类别目录名称。"""

    return sorted(
        entry.name
        for entry in Path(session_dir).iterdir()
        if entry.is_dir() and not entry.name.startswith(".")
    )


def discover_class_names(
    data_dir: Path = DEFAULT_DATA_DIR,
    session_names: list[str] | None = None,
) -> list[str]:
    """校验各 session 的类别目录一致，并返回当前配置允许的类别顺序。"""

    root_dir = Path(data_dir)
    sessions = session_names or discover_sessions(root_dir)
    if not sessions:
        return []

    reference_class_names: list[str] | None = None
    inconsistent_sessions: list[str] = []
    for session_name in sessions:
        class_names = discover_session_class_names(root_dir / session_name)
        if not class_names:
            raise RuntimeError(f"No class directories were found under session {session_name}.")
        if reference_class_names is None:
            reference_class_names = class_names
            continue
        if class_names != reference_class_names:
            inconsistent_sessions.append(session_name)

    if reference_class_names is None:
        return []

    if inconsistent_sessions:
        raise RuntimeError(
            "All sessions must expose the same class directories. "
            f"Sessions with mismatched classes: {inconsistent_sessions}"
        )
    return select_configured_class_names(reference_class_names)


def build_label_mapping(
    class_names: list[str] | None = None,
    data_dir: Path | None = None,
    session_names: list[str] | None = None,
) -> dict[str, int]:
    """根据类别顺序构建稳定的 class_name -> label_id 映射。"""

    names = list(class_names) if class_names is not None else discover_class_names(
        data_dir or DEFAULT_DATA_DIR,
        session_names=session_names,
    )
    if not names:
        raise RuntimeError(
            f"No class directories were found under {data_dir or DEFAULT_DATA_DIR}."
        )
    return {class_name: index for index, class_name in enumerate(names)}


def load_sample_array(
    csv_path: Path,
    sequence_length: int = DEFAULT_SEQUENCE_LENGTH,
    feature_dim: int = DEFAULT_FEATURE_DIM,
    verbose: bool = False,
) -> np.ndarray:
    """读取单个样本 CSV，并裁剪或补齐为固定的 `[T, F]` 形状。"""

    rows: list[np.ndarray] = []
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames or "data" not in reader.fieldnames:
            raise ValueError(f"{csv_path} does not contain a 'data' column.")

        for row_index, row in enumerate(reader):
            try:
                parsed = ast.literal_eval(row.get("data", "[]"))
            except (SyntaxError, ValueError) as exc:
                if verbose:
                    print(f"[warn] {csv_path.name} row {row_index}: parse failed ({exc}).")
                parsed = []

            vector = np.asarray(parsed, dtype=np.float32).reshape(-1)
            if vector.size < feature_dim:
                if verbose:
                    print(
                        f"[warn] {csv_path.name} row {row_index}: "
                        f"feature length {vector.size} < {feature_dim}, padded."
                    )
                vector = np.pad(vector, (0, feature_dim - vector.size))
            elif vector.size > feature_dim:
                if verbose:
                    print(
                        f"[warn] {csv_path.name} row {row_index}: "
                        f"feature length {vector.size} > {feature_dim}, truncated."
                    )
                vector = vector[:feature_dim]
            rows.append(vector)

    if len(rows) < sequence_length:
        if verbose:
            print(
                f"[warn] {csv_path.name}: row count {len(rows)} < {sequence_length}, padded."
            )
        rows.extend(
            [np.zeros(feature_dim, dtype=np.float32) for _ in range(sequence_length - len(rows))]
        )
    elif len(rows) > sequence_length:
        if verbose:
            print(
                f"[warn] {csv_path.name}: row count {len(rows)} > {sequence_length}, truncated."
            )
        rows = rows[:sequence_length]

    return np.stack(rows, axis=0).astype(np.float32)


def discover_samples(
    data_dir: Path,
    label_mapping: dict[str, int] | None = None,
    session_names: list[str] | None = None,
) -> list[dict[str, Any]]:
    """遍历指定 session 与类别目录，生成训练样本清单。"""

    root_dir = Path(data_dir)
    sessions = session_names or discover_sessions(root_dir)
    label_mapping = label_mapping or build_label_mapping(
        data_dir=root_dir,
        session_names=sessions,
    )

    samples: list[dict[str, Any]] = []
    for session_name in sessions:
        session_dir = root_dir / session_name
        if not session_dir.exists():
            raise FileNotFoundError(f"Missing session directory: {session_dir}")
        for class_name, label in label_mapping.items():
            class_dir = session_dir / class_name
            if not class_dir.exists():
                raise FileNotFoundError(
                    f"Missing class directory {class_name} under session {session_name}."
                )
            for csv_path in sorted(class_dir.glob("*.csv")):
                samples.append(
                    {
                        "relative_path": str(csv_path.relative_to(root_dir)),
                        "session_name": session_name,
                        "class_name": class_name,
                        "label": label,
                    }
                )
    if not samples:
        raise RuntimeError(f"No CSV samples were found in {data_dir}.")
    return samples


def _resolve_test_size(total_count: int, val_ratio: float, min_size: int = 1) -> int:
    """根据比例和最小数量约束计算验证集大小。"""

    if total_count < 2:
        raise RuntimeError("At least two items are required to build train/validation splits.")
    if not 0.0 < val_ratio < 1.0:
        raise ValueError(f"Validation ratio must be between 0 and 1, got {val_ratio}.")

    suggested = max(min_size, int(round(total_count * val_ratio)))
    suggested = min(suggested, total_count - 1)
    if suggested < min_size:
        raise RuntimeError(
            f"Unable to satisfy the minimum validation size {min_size} with {total_count} items."
        )
    return suggested


def split_sessions(
    session_names: list[str],
    val_ratio: float,
    seed: int,
) -> tuple[list[str], list[str]]:
    """按 session 维度随机划分训练集与验证集。"""

    test_size = _resolve_test_size(len(session_names), val_ratio, min_size=1)
    train_sessions, val_sessions = train_test_split(
        list(session_names),
        test_size=test_size,
        random_state=seed,
        shuffle=True,
    )
    return sorted(train_sessions), sorted(val_sessions)


def stratified_split(
    samples: list[dict[str, Any]],
    val_ratio: float,
    seed: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """按类别分层切分样本，保证训练集和验证集都覆盖全部类别。"""

    labels = [sample["label"] for sample in samples]
    unique_label_count = len(set(labels))
    test_size = _resolve_test_size(
        len(samples),
        val_ratio,
        min_size=unique_label_count,
    )
    if len(samples) - test_size < unique_label_count:
        raise RuntimeError(
            "Not enough samples to keep every class in both train and validation splits."
        )

    indices = list(range(len(samples)))
    train_indices, val_indices = train_test_split(
        indices,
        test_size=test_size,
        random_state=seed,
        shuffle=True,
        stratify=labels,
    )
    train_samples = [samples[index] for index in train_indices]
    val_samples = [samples[index] for index in val_indices]
    return train_samples, val_samples


def build_same_session_split(
    data_dir: Path,
    label_mapping: dict[str, int],
    val_ratio: float,
    seed: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[str]]:
    """在每个 session 内部分层切分，再合并为 same-session 训练与验证集。"""

    session_names = discover_sessions(data_dir)
    train_samples: list[dict[str, Any]] = []
    val_samples: list[dict[str, Any]] = []

    for offset, session_name in enumerate(session_names):
        session_samples = discover_samples(
            data_dir=data_dir,
            label_mapping=label_mapping,
            session_names=[session_name],
        )
        session_train, session_val = stratified_split(
            samples=session_samples,
            val_ratio=val_ratio,
            seed=seed + offset,
        )
        train_samples.extend(session_train)
        val_samples.extend(session_val)

    return train_samples, val_samples, session_names, session_names


def build_cross_session_split(
    data_dir: Path,
    label_mapping: dict[str, int],
    val_ratio: float,
    seed: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str], list[str]]:
    """按 session 整体切分训练集和验证集，用于 cross-session 评估。"""

    session_names = discover_sessions(data_dir)
    train_sessions, val_sessions = split_sessions(session_names, val_ratio=val_ratio, seed=seed)
    train_samples = discover_samples(
        data_dir=data_dir,
        label_mapping=label_mapping,
        session_names=train_sessions,
    )
    val_samples = discover_samples(
        data_dir=data_dir,
        label_mapping=label_mapping,
        session_names=val_sessions,
    )
    return train_samples, val_samples, train_sessions, val_sessions


def build_leave_one_session_out_splits(
    data_dir: Path,
    label_mapping: dict[str, int],
) -> list[dict[str, Any]]:
    """构造每次留出一个 session 的交叉验证划分。"""

    session_names = discover_sessions(data_dir)
    if len(session_names) < 2:
        raise RuntimeError(
            "At least two sessions are required for leave-one-session-out evaluation."
        )

    folds: list[dict[str, Any]] = []
    for fold_index, val_session in enumerate(session_names, start=1):
        train_sessions = sorted(
            session_name for session_name in session_names if session_name != val_session
        )
        val_sessions = [val_session]
        train_samples = discover_samples(
            data_dir=data_dir,
            label_mapping=label_mapping,
            session_names=train_sessions,
        )
        val_samples = discover_samples(
            data_dir=data_dir,
            label_mapping=label_mapping,
            session_names=val_sessions,
        )
        folds.append(
            {
                "fold_index": fold_index,
                "train_samples": train_samples,
                "val_samples": val_samples,
                "train_sessions": train_sessions,
                "val_sessions": val_sessions,
            }
        )
    return folds


def build_group_kfold_splits(
    data_dir: Path,
    label_mapping: dict[str, int],
    num_folds: int,
    seed: int,
) -> list[dict[str, Any]]:
    """以 session 为组构造 group k-fold 划分。"""

    session_names = discover_sessions(data_dir)
    if len(session_names) < 2:
        raise RuntimeError("At least two sessions are required for group k-fold evaluation.")
    if num_folds < 2:
        raise RuntimeError("Group k-fold evaluation requires at least two folds.")
    if num_folds > len(session_names):
        raise RuntimeError(
            f"Group k-fold requested {num_folds} folds, but only {len(session_names)} sessions "
            "are available."
        )

    shuffled_sessions = np.asarray(session_names, dtype=object)
    rng = np.random.default_rng(seed)
    rng.shuffle(shuffled_sessions)
    session_folds = [
        sorted(chunk.tolist())
        for chunk in np.array_split(shuffled_sessions, num_folds)
        if len(chunk) > 0
    ]

    folds: list[dict[str, Any]] = []
    for fold_index, val_sessions in enumerate(session_folds, start=1):
        val_session_set = set(val_sessions)
        train_sessions = sorted(
            session_name
            for session_name in session_names
            if session_name not in val_session_set
        )
        train_samples = discover_samples(
            data_dir=data_dir,
            label_mapping=label_mapping,
            session_names=train_sessions,
        )
        val_samples = discover_samples(
            data_dir=data_dir,
            label_mapping=label_mapping,
            session_names=val_sessions,
        )
        folds.append(
            {
                "fold_index": fold_index,
                "train_samples": train_samples,
                "val_samples": val_samples,
                "train_sessions": train_sessions,
                "val_sessions": val_sessions,
            }
        )
    return folds


def fit_normalizer(
    data_dir: Path,
    samples: list[dict[str, Any]],
    feature_dim: int = DEFAULT_FEATURE_DIM,
    sequence_length: int = DEFAULT_SEQUENCE_LENGTH,
) -> FeatureNormalizer:
    """仅用训练样本统计逐特征均值与标准差。"""

    sum_vector = np.zeros(feature_dim, dtype=np.float64)
    sum_square_vector = np.zeros(feature_dim, dtype=np.float64)
    total_rows = 0

    for sample in samples:
        array = load_sample_array(
            Path(data_dir) / sample["relative_path"],
            sequence_length=sequence_length,
            feature_dim=feature_dim,
        )
        flattened = array.reshape(-1, feature_dim)
        sum_vector += flattened.sum(axis=0)
        sum_square_vector += np.square(flattened).sum(axis=0)
        total_rows += flattened.shape[0]

    mean = sum_vector / total_rows
    variance = np.maximum(sum_square_vector / total_rows - np.square(mean), 1e-12)
    std = np.sqrt(variance)
    std[std < 1e-6] = 1.0
    return FeatureNormalizer(mean=mean.astype(np.float32), std=std.astype(np.float32))


def summarize_samples(samples: list[dict[str, Any]]) -> dict[str, Any]:
    """汇总样本总数、类别分布与 session 分布。"""

    by_class: dict[str, int] = defaultdict(int)
    by_session: dict[str, int] = defaultdict(int)
    for sample in samples:
        by_class[sample["class_name"]] += 1
        by_session[sample["session_name"]] += 1
    return {
        "total": len(samples),
        "by_class": dict(sorted(by_class.items())),
        "by_session": dict(sorted(by_session.items())),
    }


def build_split_manifest(
    dataset_root: Path,
    train_samples: list[dict[str, Any]],
    val_samples: list[dict[str, Any]],
    split_mode: str,
    train_sessions: list[str],
    val_sessions: list[str],
) -> dict[str, Any]:
    """生成可落盘的切分清单，便于复现实验与批量评估。"""

    return {
        "dataset_root": str(Path(dataset_root)),
        "split_mode": split_mode,
        "train_sessions": train_sessions,
        "val_sessions": val_sessions,
        "train_summary": summarize_samples(train_samples),
        "val_summary": summarize_samples(val_samples),
        "train": train_samples,
        "val": val_samples,
    }


class CSIDataset(Dataset[tuple[torch.Tensor, int]]):
    """预加载 CSI 样本，并输出 `[1, T, F]` 张量与标签。"""

    def __init__(
        self,
        data_dir: Path,
        samples: list[dict[str, Any]],
        normalizer: FeatureNormalizer | None = None,
        sequence_length: int = DEFAULT_SEQUENCE_LENGTH,
        feature_dim: int = DEFAULT_FEATURE_DIM,
    ) -> None:
        self.data_dir = Path(data_dir)
        self.samples = samples
        self.normalizer = normalizer
        self.sequence_length = sequence_length
        self.feature_dim = feature_dim
        self._items: list[tuple[torch.Tensor, int]] = []
        self._preload()

    def _preload(self) -> None:
        for sample in self.samples:
            array = load_sample_array(
                self.data_dir / sample["relative_path"],
                sequence_length=self.sequence_length,
                feature_dim=self.feature_dim,
            )
            if self.normalizer is not None:
                array = self.normalizer.transform(array)
            tensor = torch.from_numpy(array.astype(np.float32)).unsqueeze(0)
            label = int(sample["label"])
            self._items.append((tensor, label))

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, int]:
        return self._items[index]
