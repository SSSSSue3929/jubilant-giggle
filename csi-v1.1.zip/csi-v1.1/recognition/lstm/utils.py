"""训练、评估与结果落盘时复用的通用工具函数。"""

from __future__ import annotations

import csv
import json
import os
import random
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import torch
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    precision_recall_fscore_support,
)

PROJECT_ROOT = Path(__file__).resolve().parents[2]
# 为 matplotlib 指定 recognition 级别的共享缓存目录，避免写入用户主目录。
MPL_CONFIG_DIR = PROJECT_ROOT / "recognition" / ".mplconfig"
MPL_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(MPL_CONFIG_DIR))

for lock_path in MPL_CONFIG_DIR.glob("*.matplotlib-lock"):
    try:
        lock_path.unlink()
    except OSError:
        pass

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def ensure_dir(path: Path) -> Path:
    """确保目录存在，并返回该目录路径。"""

    path.mkdir(parents=True, exist_ok=True)
    return path


def timestamp_for_name() -> str:
    """生成适合文件名使用的时间戳。"""

    return datetime.now().strftime("%Y%m%d_%H%M%S")


def timestamp_for_log() -> str:
    """生成适合日志输出的时间戳。"""

    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def save_json(path: Path, payload: Any) -> None:
    """使用 UTF-8 编码保存 JSON 文件。"""

    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)


def load_json(path: Path) -> Any:
    """读取 JSON 文件并返回解析结果。"""

    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def set_seed(seed: int) -> None:
    """统一设置 Python、NumPy 与 PyTorch 的随机种子。"""

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def select_device(device_name: str) -> torch.device:
    """根据用户配置选择 CPU 或 CUDA 设备。"""

    requested = device_name.lower()
    if requested not in {"auto", "cpu", "cuda"}:
        raise ValueError(f"Unsupported device option: {device_name}")

    if requested == "cpu":
        return torch.device("cpu")

    if requested == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA was requested but is not available.")
        return torch.device("cuda")

    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def describe_device(device: torch.device) -> str:
    """返回当前训练或推理设备的人类可读描述。"""

    if device.type != "cuda":
        return "Using CPU for training/inference."
    name = torch.cuda.get_device_name(device)
    capability = torch.cuda.get_device_capability(device)
    return (
        f"Using CUDA device {name} "
        f"(compute capability {capability[0]}.{capability[1]})."
    )


def compute_classification_metrics(
    y_true: list[int],
    y_pred: list[int],
    label_ids: list[int],
) -> dict[str, Any]:
    """计算分类任务常用指标与混淆矩阵。"""

    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true,
        y_pred,
        labels=label_ids,
        average="macro",
        zero_division=0,
    )
    accuracy = accuracy_score(y_true, y_pred)
    matrix = confusion_matrix(y_true, y_pred, labels=label_ids)
    return {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "confusion_matrix": matrix.tolist(),
    }


def save_confusion_matrix_csv(
    path: Path, matrix: list[list[int]], class_names: list[str]
) -> None:
    """将混淆矩阵保存为便于查看和复用的 CSV 文件。"""

    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["true/pred", *class_names])
        for class_name, row in zip(class_names, matrix):
            writer.writerow([class_name, *row])


def save_confusion_matrix_plot(
    path: Path,
    matrix: list[list[int]],
    class_names: list[str],
    normalize: bool = True,
    title: str = "Confusion Matrix",
) -> None:
    """绘制并保存混淆矩阵热力图。"""

    ensure_dir(path.parent)
    matrix_array = np.asarray(matrix, dtype=np.float64)
    if normalize:
        row_sums = matrix_array.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0.0] = 1.0
        display_array = matrix_array / row_sums
        value_format = ".2f"
    else:
        display_array = matrix_array
        value_format = ".0f"

    figure, axis = plt.subplots(figsize=(8, 6))
    image = axis.imshow(display_array, interpolation="nearest", cmap="Blues")
    figure.colorbar(image, ax=axis)
    axis.set(
        xticks=np.arange(len(class_names)),
        yticks=np.arange(len(class_names)),
        xticklabels=class_names,
        yticklabels=class_names,
        ylabel="True Label",
        xlabel="Predicted Label",
        title=title,
    )
    plt.setp(axis.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")

    threshold = display_array.max() / 2.0 if display_array.size else 0.0
    for row_index in range(display_array.shape[0]):
        for col_index in range(display_array.shape[1]):
            value = format(display_array[row_index, col_index], value_format)
            axis.text(
                col_index,
                row_index,
                value,
                ha="center",
                va="center",
                color="white" if display_array[row_index, col_index] > threshold else "black",
            )

    figure.tight_layout()
    figure.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(figure)


def save_history_csv(path: Path, history: list[dict[str, Any]]) -> None:
    """保存每个 epoch 的训练历史记录。"""

    ensure_dir(path.parent)
    if not history:
        return
    fieldnames = list(history[0].keys())
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(history)


def save_metric_curve_plot(
    path: Path,
    history: list[dict[str, Any]],
    *,
    train_key: str,
    val_key: str,
    ylabel: str,
    title: str,
    zero_to_one: bool = False,
    epoch_tick_step: int = 5,
) -> None:
    """保存单项训练集与验证集指标对比曲线图。"""

    ensure_dir(path.parent)
    if not history:
        return

    epochs = [int(record["epoch"]) for record in history]
    train_values = [float(record[train_key]) for record in history]
    val_values = [float(record[val_key]) for record in history]
    tick_step = max(int(epoch_tick_step), 1)
    tick_values = list(range(epochs[0], epochs[-1] + 1, tick_step))
    if epochs[-1] not in tick_values:
        remainder = epochs[-1] % tick_step
        if (remainder >= 1 and remainder <= 3) and len(tick_values) >= 1:
            tick_values.pop()
        tick_values.append(epochs[-1])

    figure, axis = plt.subplots(figsize=(8, 5))
    axis.plot(epochs, train_values, label="Train", linewidth=2.0)
    axis.plot(epochs, val_values, label="Validation", linewidth=2.0)
    axis.set(
        xlabel="Epoch",
        ylabel=ylabel,
        title=title,
    )
    axis.grid(True, linestyle="--", linewidth=0.6, alpha=0.6)
    axis.legend()
    axis.set_xticks(tick_values)
    if zero_to_one:
        axis.set_ylim(0.0, 1.05)

    figure.tight_layout()
    figure.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(figure)


def save_training_history_plots(
    output_dir: Path,
    history: list[dict[str, Any]],
    epoch_tick_step: int = 5,
) -> dict[str, str]:
    """统一生成 accuracy、f1 与 loss 的训练/验证对比曲线图。"""

    ensure_dir(output_dir)
    plot_paths = {
        "accuracy_curve": output_dir / "accuracy_curve.png",
        "f1_curve": output_dir / "f1_curve.png",
        "loss_curve": output_dir / "loss_curve.png",
    }
    save_metric_curve_plot(
        plot_paths["accuracy_curve"],
        history,
        train_key="train_accuracy",
        val_key="val_accuracy",
        ylabel="Accuracy",
        title="Train vs Validation Accuracy",
        zero_to_one=True,
        epoch_tick_step=epoch_tick_step,
    )
    save_metric_curve_plot(
        plot_paths["f1_curve"],
        history,
        train_key="train_f1",
        val_key="val_f1",
        ylabel="Macro F1",
        title="Train vs Validation Macro F1",
        zero_to_one=True,
        epoch_tick_step=epoch_tick_step,
    )
    save_metric_curve_plot(
        plot_paths["loss_curve"],
        history,
        train_key="train_loss",
        val_key="val_loss",
        ylabel="Loss",
        title="Train vs Validation Loss",
        zero_to_one=False,
        epoch_tick_step=epoch_tick_step,
    )
    return {name: str(path) for name, path in plot_paths.items()}


def format_probability_table(
    probabilities: list[float], class_names: list[str], top_k: int | None = None
) -> list[dict[str, Any]]:
    """按概率从高到低整理类别结果，便于终端展示。"""

    ranked = sorted(
        (
            {"class_name": class_name, "probability": float(probability)}
            for class_name, probability in zip(class_names, probabilities)
        ),
        key=lambda item: item["probability"],
        reverse=True,
    )
    if top_k is None:
        return ranked
    return ranked[:top_k]
