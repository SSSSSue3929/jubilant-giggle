# recognition/LSTM

`recognition/LSTM` 保存纯 LSTM 模型项目代码，训练与验证流程复用统一数据处理链路。

## 主要用途

- 训练纯 LSTM 手势识别模型。
- 输出 `best_model.pt`、评估报告和混淆矩阵。
- 作为其他模型项目复用的数据处理与评估基线。

## 推荐用法

优先使用统一入口：

```powershell
conda run -n esp-csi python .\recognition\train.py --model lstm
conda run -n esp-csi python .\recognition\predict.py --model lstm --input .\data
```

如需直接调用本项目脚本，也可以执行：

```powershell
conda run -n esp-csi python .\recognition\LSTM\train.py
conda run -n esp-csi python .\recognition\LSTM\predict.py --input .\data
```

## 数据约定

- 默认数据集根目录为 `data/`。
- 样本读取后先按 `[130, 104]` 解析。
- 再解码为 `26` 维真实子载波幅度，并执行低通滤波、前静止段 baseline 校准和标准化。
- 模型实际输入张量形状为 `[batch, 1, 130, 26]`。

## 目录结构

```text
recognition/LSTM/                   # LSTM 模型项目
├── checkpoints/                    # 训练生成的 checkpoint
├── outputs/                        # 评估报告与训练结果
├── dataset.py                      # 数据发现与切分逻辑
├── model.py                        # LSTM 模型定义
├── predict.py                      # 模型验证与推理脚本
├── train.py                        # 模型训练脚本
└── utils.py                        # 通用工具函数
```
