"""LSTM 单样本推理与批量离线评估入口。"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Any

import numpy as np
import torch
from tqdm import tqdm

from dataset import (
    DEFAULT_DATA_DIR,
    DEFAULT_SEQUENCE_LENGTH,
    FeatureNormalizer,
    build_label_mapping,
    discover_class_names,
    load_sample_array,
)
from csi_preprocessing import (
    DEFAULT_FRONT_BASELINE_FRAMES,
    MODEL_INPUT_FEATURE_DIM,
    RAW_CSI_FEATURE_DIM,
    PerSampleBaselinePreprocessor,
)
from model import CSILSTMClassifier
from utils import (
    compute_classification_metrics,
    ensure_dir,
    format_probability_table,
    load_json,
    save_confusion_matrix_csv,
    save_confusion_matrix_plot,
    save_json,
    select_device,
    timestamp_for_log,
)


def parse_args() -> argparse.Namespace:
    """解析命令行推理参数。"""

    parser = argparse.ArgumentParser(description="Run inference with the CSI LSTM model.")
    parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="Path to a single CSV file or a directory of CSV files.",
    )
    parser.add_argument(
        "--checkpoint",
        "--model-path",
        "--weight-path",
        dest="checkpoint",
        type=Path,
        default=Path(__file__).resolve().parent / "checkpoints" / "best_model.pt",
        help="Path to the trained checkpoint.",
    )
    parser.add_argument(
        "--label-mapping",
        type=Path,
        default=None,
        help="Optional label mapping JSON path. Falls back to checkpoint metadata.",
    )
    parser.add_argument(
        "--normalizer",
        type=Path,
        default=None,
        help="Optional normalizer JSON path. Falls back to checkpoint metadata.",
    )
    parser.add_argument(
        "--preprocessing",
        type=Path,
        default=None,
        help="Optional preprocessing JSON path. Falls back to checkpoint metadata.",
    )
    parser.add_argument(
        "--device",
        choices=["auto", "cpu", "cuda"],
        default="auto",
        help="Inference device.",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=None,
        help="Optional split_manifest.json to evaluate only train/val subsets.",
    )
    parser.add_argument(
        "--subset",
        choices=["all", "train", "val"],
        default="all",
        help="Subset to use when --manifest is provided.",
    )
    parser.add_argument(
        "--report-dir",
        type=Path,
        default=None,
        help="Optional directory used to store batch inference reports.",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=3,
        help="Number of class probabilities shown for single-file inference.",
    )
    return parser.parse_args()


def load_runtime_assets(
    checkpoint_path: Path,
    label_mapping_path: Path | None,
    normalizer_path: Path | None,
    preprocessing_path: Path | None,
    device: torch.device,
) -> tuple[dict[str, Any], dict[str, int], FeatureNormalizer, dict[str, Any] | None]:
    """加载 checkpoint、标签映射、标准化参数与预处理配置。"""

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device,
        weights_only=False,
    )

    if label_mapping_path is not None:
        label_mapping = load_json(label_mapping_path)
    else:
        label_mapping = checkpoint.get("label_mapping") or build_label_mapping(
            data_dir=DEFAULT_DATA_DIR
        )

    if normalizer_path is not None:
        normalizer_payload = load_json(normalizer_path)
    else:
        normalizer_payload = checkpoint.get("normalizer")
        if normalizer_payload is None:
            raise RuntimeError("Normalizer metadata is missing from the checkpoint.")

    if preprocessing_path is not None:
        preprocessing_payload = load_json(preprocessing_path)
    else:
        preprocessing_payload = checkpoint.get("preprocessing")

    normalizer = FeatureNormalizer.from_dict(normalizer_payload)
    return checkpoint, label_mapping, normalizer, preprocessing_payload


def build_model_from_checkpoint(
    checkpoint: dict[str, Any],
    device: torch.device,
) -> CSILSTMClassifier:
    """根据 checkpoint 元数据重建模型结构并加载权重。"""

    checkpoint_class_names = checkpoint.get("class_names") or discover_class_names(DEFAULT_DATA_DIR)
    model_kwargs_payload = checkpoint.get("model_kwargs")
    if isinstance(model_kwargs_payload, dict) and model_kwargs_payload:
        model_kwargs = dict(model_kwargs_payload)
        model_kwargs.setdefault(
            "input_size",
            int(checkpoint.get("input_size", MODEL_INPUT_FEATURE_DIM)),
        )
        model_kwargs.setdefault(
            "num_classes",
            int(checkpoint.get("num_classes", len(checkpoint_class_names))),
        )
    else:
        model_kwargs = {
            "input_size": int(checkpoint.get("input_size", MODEL_INPUT_FEATURE_DIM)),
            "hidden_size": int(checkpoint.get("hidden_size", 128)),
            "num_layers": int(checkpoint.get("num_layers", 2)),
            "num_classes": int(checkpoint.get("num_classes", len(checkpoint_class_names))),
            "dropout": float(checkpoint.get("dropout", 0.0)),
        }

    model = CSILSTMClassifier(**model_kwargs).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()
    return model


def class_names_from_mapping(label_mapping: dict[str, int]) -> list[str]:
    """按标签编号顺序还原类别名称列表。"""

    return [
        class_name
        for class_name, _label in sorted(label_mapping.items(), key=lambda item: item[1])
    ]


def resolve_runtime_preprocessor(
    checkpoint: dict[str, Any],
    preprocessing_payload: dict[str, Any] | None,
    normalizer: FeatureNormalizer,
) -> tuple[PerSampleBaselinePreprocessor, int, int]:
    """恢复与训练阶段一致的单样本预处理配置。"""

    raw_input_shape = checkpoint.get("raw_input_shape") or [
        DEFAULT_SEQUENCE_LENGTH,
        RAW_CSI_FEATURE_DIM,
    ]
    model_input_shape = checkpoint.get("model_input_shape") or [
        int(raw_input_shape[0]),
        len(normalizer.mean),
    ]

    sequence_length = int(raw_input_shape[0])
    raw_feature_dim = int(raw_input_shape[1])
    decoded_feature_dim = int(model_input_shape[1])

    baseline_frames = DEFAULT_FRONT_BASELINE_FRAMES
    if isinstance(preprocessing_payload, dict):
        raw_feature_dim = int(preprocessing_payload.get("raw_feature_dim", raw_feature_dim))
        decoded_feature_dim = int(preprocessing_payload.get("feature_dim", decoded_feature_dim))
        baseline_config = preprocessing_payload.get("sample_baseline", {})
        if isinstance(baseline_config, dict):
            baseline_frames = int(baseline_config.get("frames", baseline_frames))

    if decoded_feature_dim != len(normalizer.mean):
        raise RuntimeError(
            "Checkpoint preprocessing metadata and normalizer dimensions are inconsistent: "
            f"decoded feature dim={decoded_feature_dim}, normalizer dim={len(normalizer.mean)}."
        )

    return (
        PerSampleBaselinePreprocessor(baseline_frames=baseline_frames),
        sequence_length,
        raw_feature_dim,
    )


def preprocess_inference_sample(
    file_path: Path,
    preprocessor: PerSampleBaselinePreprocessor,
    normalizer: FeatureNormalizer,
    *,
    sequence_length: int,
    raw_feature_dim: int,
) -> np.ndarray:
    """读取并按训练链路预处理单个离线样本。"""

    raw_sample = load_sample_array(
        file_path,
        sequence_length=sequence_length,
        feature_dim=raw_feature_dim,
        verbose=True,
    )
    processed_sample = preprocessor.preprocess(raw_sample)
    if processed_sample.shape[-1] != len(normalizer.mean):
        raise RuntimeError(
            f"Preprocessed feature dim {processed_sample.shape[-1]} does not match "
            f"normalizer dim {len(normalizer.mean)} for {file_path}."
        )
    return normalizer.transform(processed_sample)


def predict_single(
    model: CSILSTMClassifier,
    file_path: Path,
    preprocessor: PerSampleBaselinePreprocessor,
    normalizer: FeatureNormalizer,
    class_names: list[str],
    device: torch.device,
    *,
    sequence_length: int,
    raw_feature_dim: int,
) -> dict[str, Any]:
    """对单个 CSV 样本执行推理，并返回概率与预测类别。"""

    sample = preprocess_inference_sample(
        file_path=file_path,
        preprocessor=preprocessor,
        normalizer=normalizer,
        sequence_length=sequence_length,
        raw_feature_dim=raw_feature_dim,
    )
    tensor = torch.from_numpy(sample.astype(np.float32)).unsqueeze(0).unsqueeze(0).to(device)
    with torch.no_grad():
        logits = model(tensor)
        probabilities = torch.softmax(logits, dim=1).squeeze(0).cpu().tolist()
    predicted_index = int(np.argmax(probabilities))
    return {
        "file_path": str(file_path),
        "predicted_index": predicted_index,
        "predicted_class": class_names[predicted_index],
        "probabilities": probabilities,
    }


def resolve_batch_files(
    input_path: Path,
    manifest_path: Path | None,
    subset: str,
) -> tuple[list[Path], list[Path]]:
    """解析批量推理时需要处理的 CSV 文件列表，并过滤辅助文件。"""

    if manifest_path is None or subset == "all":
        candidate_files = sorted(input_path.rglob("*.csv"))
    else:
        manifest = load_json(manifest_path)
        records = manifest["train"] if subset == "train" else manifest["val"]
        candidate_files = [input_path / record["relative_path"] for record in records]

    files: list[Path] = []
    skipped_files: list[Path] = []
    for file_path in candidate_files:
        if file_path.name.lower() == "remark.csv":
            skipped_files.append(file_path)
            continue
        files.append(file_path)
    return files, skipped_files


def infer_true_label(file_path: Path, label_mapping: dict[str, int]) -> int | None:
    """根据父目录名称推断样本真实标签。"""

    parent_name = file_path.parent.name
    return label_mapping.get(parent_name)


def batch_predict(
    model: CSILSTMClassifier,
    files: list[Path],
    preprocessor: PerSampleBaselinePreprocessor,
    normalizer: FeatureNormalizer,
    label_mapping: dict[str, int],
    class_names: list[str],
    device: torch.device,
    *,
    sequence_length: int,
    raw_feature_dim: int,
) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    """对一批样本执行推理，并在可用时统计整体指标。"""

    predictions: list[dict[str, Any]] = []
    y_true: list[int] = []
    y_pred: list[int] = []

    for file_path in tqdm(files, desc="Batch inference"):
        result = predict_single(
            model=model,
            file_path=file_path,
            preprocessor=preprocessor,
            normalizer=normalizer,
            class_names=class_names,
            device=device,
            sequence_length=sequence_length,
            raw_feature_dim=raw_feature_dim,
        )
        true_label = infer_true_label(file_path, label_mapping)
        result["true_label"] = true_label
        result["true_class"] = class_names[true_label] if true_label is not None else None
        predictions.append(result)
        if true_label is not None:
            y_true.append(true_label)
            y_pred.append(result["predicted_index"])

    metrics = None
    if y_true:
        metrics = compute_classification_metrics(
            y_true=y_true,
            y_pred=y_pred,
            label_ids=list(range(len(class_names))),
        )
        metrics["evaluated_file_count"] = len(y_true)
        metrics["predicted_file_count"] = len(predictions)
    return predictions, metrics


def save_batch_reports(
    report_dir: Path,
    predictions: list[dict[str, Any]],
    metrics: dict[str, Any] | None,
    class_names: list[str],
) -> None:
    """保存批量推理结果、指标与混淆矩阵。"""

    ensure_dir(report_dir)
    rows = []
    for item in predictions:
        row = {
            "file_path": item["file_path"],
            "predicted_class": item["predicted_class"],
            "true_class": item["true_class"],
        }
        for class_name, probability in zip(class_names, item["probabilities"]):
            row[f"prob_{class_name}"] = round(float(probability), 6)
        rows.append(row)

    prediction_csv = report_dir / "predictions.csv"
    with prediction_csv.open("w", encoding="utf-8", newline="") as handle:
        fieldnames = (
            list(rows[0].keys()) if rows else ["file_path", "predicted_class", "true_class"]
        )
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    if metrics is not None:
        save_json(report_dir / "metrics.json", metrics)
        save_confusion_matrix_csv(
            report_dir / "confusion_matrix.csv",
            metrics["confusion_matrix"],
            class_names,
        )
        save_confusion_matrix_plot(
            report_dir / "confusion_matrix.png",
            metrics["confusion_matrix"],
            class_names,
            normalize=True,
            title="Inference Confusion Matrix",
        )


def main() -> None:
    """命令行推理主入口。"""

    args = parse_args()
    device = select_device(args.device)
    checkpoint, label_mapping, normalizer, preprocessing_payload = load_runtime_assets(
        checkpoint_path=args.checkpoint,
        label_mapping_path=args.label_mapping,
        normalizer_path=args.normalizer,
        preprocessing_path=args.preprocessing,
        device=device,
    )
    class_names = checkpoint.get("class_names") or class_names_from_mapping(label_mapping)
    model = build_model_from_checkpoint(checkpoint, device)
    preprocessor, sequence_length, raw_feature_dim = resolve_runtime_preprocessor(
        checkpoint=checkpoint,
        preprocessing_payload=preprocessing_payload,
        normalizer=normalizer,
    )

    if args.input.is_file():
        result = predict_single(
            model=model,
            file_path=args.input,
            preprocessor=preprocessor,
            normalizer=normalizer,
            class_names=class_names,
            device=device,
            sequence_length=sequence_length,
            raw_feature_dim=raw_feature_dim,
        )
        ranked = format_probability_table(
            result["probabilities"], class_names=class_names, top_k=args.top_k
        )
        print(f"[{timestamp_for_log()}] File: {result['file_path']}")
        print(f"[{timestamp_for_log()}] Predicted class: {result['predicted_class']}")
        for item in ranked:
            print(f"  {item['class_name']}: {item['probability']:.6f}")
        return

    if not args.input.is_dir():
        raise FileNotFoundError(f"Input path does not exist: {args.input}")

    files, skipped_files = resolve_batch_files(args.input, args.manifest, args.subset)
    if not files:
        raise RuntimeError(f"No valid CSV sample files found under {args.input}.")

    predictions, metrics = batch_predict(
        model=model,
        files=files,
        preprocessor=preprocessor,
        normalizer=normalizer,
        label_mapping=label_mapping,
        class_names=class_names,
        device=device,
        sequence_length=sequence_length,
        raw_feature_dim=raw_feature_dim,
    )

    print(f"[{timestamp_for_log()}] Processed {len(predictions)} files.")
    if skipped_files:
        print(
            f"[{timestamp_for_log()}] Ignored {len(skipped_files)} auxiliary CSV files, "
            f"for example: {skipped_files[0]}"
        )
    if metrics is not None:
        print(
            f"[{timestamp_for_log()}] accuracy={metrics['accuracy']:.4f}, "
            f"precision={metrics['precision']:.4f}, "
            f"recall={metrics['recall']:.4f}, "
            f"f1={metrics['f1']:.4f}"
        )
    else:
        print(
            f"[{timestamp_for_log()}] No ground-truth labels were inferred from the directory "
            "structure, so aggregate metrics were not computed."
        )

    if args.report_dir is not None:
        save_batch_reports(args.report_dir, predictions, metrics, class_names)
        print(f"[{timestamp_for_log()}] Reports saved to {args.report_dir}.")


if __name__ == "__main__":
    main()
