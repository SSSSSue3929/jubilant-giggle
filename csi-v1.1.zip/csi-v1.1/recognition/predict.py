"""统一验证与推理入口，根据模型类型分发到对应项目脚本。"""

from __future__ import annotations

import argparse

from train import dispatch_model_script
from model_registry import get_available_model_types


def parse_args() -> tuple[argparse.Namespace, list[str]]:
    """解析统一入口自己的参数，其余参数继续交给具体模型脚本。"""
    parser = argparse.ArgumentParser(
        description="Run inference for one of the recognition models with a unified command entry."
    )
    parser.add_argument(
        "--model",
        type=str,
        default="csi-deepnet",
        help=f"Model type. Available: {', '.join(get_available_model_types())}.",
    )
    parser.add_argument(
        "--list-models",
        action="store_true",
        help="Print all available model types and exit.",
    )
    return parser.parse_known_args()


def main() -> None:
    """统一推理入口主函数。"""
    args, forwarded_args = parse_args()
    if args.list_models:
        print("\n".join(get_available_model_types()))
        return
    dispatch_model_script(
        model_type=args.model,
        script_name="predict.py",
        forwarded_args=forwarded_args,
    )


if __name__ == "__main__":
    main()
