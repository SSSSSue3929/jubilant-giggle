"""统一维护 recognition 目录下各模型项目的路径与类型映射。"""

from __future__ import annotations

from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from types import ModuleType


RECOGNITION_ROOT = Path(__file__).resolve().parent
# 目录名与模型类型分开维护，便于同时兼容命令行别名和磁盘目录名。
MODEL_DIRECTORY_NAMES: dict[str, str] = {
    "lstm": "LSTM",
    "cnn-lstm": "CNN-LSTM",
    "csi-deepnet": "CSI-DeepNet",
}
MODEL_ALIASES: dict[str, str] = {
    "lstm": "lstm",
    "cnn-lstm": "cnn-lstm",
    "cnn_lstm": "cnn-lstm",
    "cnnlstm": "cnn-lstm",
    "csi-deepnet": "csi-deepnet",
    "csi_deepnet": "csi-deepnet",
    "csideepnet": "csi-deepnet",
}
_MODEL_MODULE_CACHE: dict[str, ModuleType] = {}


def get_available_model_types() -> tuple[str, ...]:
    """返回当前 recognition 目录中支持的模型类型列表。"""
    return tuple(MODEL_DIRECTORY_NAMES.keys())


def normalize_model_type(model_type: object) -> str:
    """把用户输入或 checkpoint 元数据规范化为统一模型类型键名。"""
    normalized = str(model_type or "").strip().casefold().replace(" ", "").replace("_", "-")
    if normalized in MODEL_ALIASES:
        return MODEL_ALIASES[normalized]
    raise ValueError(
        f"Unsupported model type: {model_type!r}. Available models: {', '.join(get_available_model_types())}."
    )


def get_model_project_dir(model_type: object) -> Path:
    """根据模型类型返回对应项目目录。"""
    normalized_model_type = normalize_model_type(model_type)
    return RECOGNITION_ROOT / MODEL_DIRECTORY_NAMES[normalized_model_type]


def get_model_entry_script(model_type: object, script_name: str) -> Path:
    """返回指定模型项目下的 train/predict 等入口脚本路径。"""
    script_path = get_model_project_dir(model_type) / script_name
    if not script_path.exists():
        raise FileNotFoundError(f"Missing script for model {model_type!r}: {script_path}")
    return script_path


def load_model_module(model_type: object) -> ModuleType:
    """按模型类型动态加载对应目录下的 model.py 模块。"""
    normalized_model_type = normalize_model_type(model_type)
    cached_module = _MODEL_MODULE_CACHE.get(normalized_model_type)
    if cached_module is not None:
        return cached_module

    model_path = get_model_project_dir(normalized_model_type) / "model.py"
    module_name = f"recognition_model_{normalized_model_type.replace('-', '_')}"
    spec = spec_from_file_location(module_name, model_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Unable to load model module from {model_path}.")

    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    _MODEL_MODULE_CACHE[normalized_model_type] = module
    return module


def get_model_class(model_type: object):
    """返回指定模型项目导出的主模型类。"""
    module = load_model_module(model_type)
    model_class = getattr(module, "CSILSTMClassifier", None)
    if model_class is None:
        raise AttributeError(
            f"Model module {module.__file__} does not export CSILSTMClassifier."
        )
    return model_class
