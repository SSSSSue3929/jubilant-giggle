"""统一训练入口，根据模型类型分发到对应项目脚本。"""

from __future__ import annotations

import argparse
from pathlib import Path
import runpy
import sys

from model_registry import get_available_model_types, get_model_entry_script, normalize_model_type


def parse_args() -> tuple[argparse.Namespace, list[str]]:
    """解析统一入口自己的参数，其余参数原样透传给具体模型脚本。"""
    parser = argparse.ArgumentParser(
        description="Train one of the recognition models with a unified command entry."
    )
    parser.add_argument(
        "--model",
        type=str,
        default="csi-deepnet",
        help=f"Model type. Available: {', '.join(get_available_model_types())}.",
    )
    parser.add_argument(
        "--list-models",
        action="store_true",
        help="Print all available model types and exit.",
    )
    return parser.parse_known_args()


def dispatch_model_script(*, model_type: str, script_name: str, forwarded_args: list[str]) -> None:
    """切换到目标模型脚本，并把剩余参数全部透传过去。"""
    normalized_model_type = normalize_model_type(model_type)
    script_path = get_model_entry_script(normalized_model_type, script_name)
    original_argv = list(sys.argv)
    original_sys_path = list(sys.path)
    try:
        sys.path.insert(0, str(script_path.parent))
        # 让被调脚本像直接从命令行启动一样读取自己的参数与默认目录。
        sys.argv = [str(script_path), *forwarded_args]
        runpy.run_path(str(script_path), run_name="__main__")
    finally:
        sys.argv = original_argv
        sys.path = original_sys_path


def main() -> None:
    """统一训练入口主函数。"""
    args, forwarded_args = parse_args()
    if args.list_models:
        print("\n".join(get_available_model_types()))
        return
    dispatch_model_script(
        model_type=args.model,
        script_name="train.py",
        forwarded_args=forwarded_args,
    )


if __name__ == "__main__":
    main()
