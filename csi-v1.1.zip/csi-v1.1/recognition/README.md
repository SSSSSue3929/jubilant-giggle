# recognition

`recognition` 目录存放训练、验证和离线推理相关代码，并按模型类型拆分项目目录。同时提供统一入口 `train.py` 与 `predict.py`，便于在不同模型间切换。

## 主要目录

- `LSTM/`：纯 LSTM 模型项目
- `CNN-LSTM/`：1D-CNN + LSTM 模型项目
- `CSI-DeepNet/`：参考论文实现的轻量卷积模型项目
- `train.py`：统一训练入口
- `predict.py`：统一离线验证与推理入口
- `predict.cmd`：Windows 命令行包装入口，避免 `.py` 文件被系统关联到编辑器时无法直接执行

## 用法

统一训练入口：

```powershell
conda run -n esp-csi python .\recognition\train.py --model lstm
conda run -n esp-csi python .\recognition\train.py --model cnn-lstm
conda run -n esp-csi python .\recognition\train.py --model csi-deepnet
```

首次训练任意模型时，会在 `recognition/fixed_split_config.json` 自动生成并保存共享的数据集划分配置。当前固定保存并复用的只包含 `same-session` 与 `cross-session` 两种划分；后续训练所有模型都会复用同一份划分，确保训练集与验证集保持一致。如需在数据集更新后重新生成划分，可显式追加：

```powershell
conda run -n esp-csi python .\recognition\train.py --model csi-deepnet --regenerate-split-config
```

每次训练还会在对应运行目录同步生成：

- `history.csv`
- `accuracy_curve.png`
- `f1_curve.png`
- `loss_curve.png`

统一离线验证/推理入口：

```powershell
conda run -n esp-csi python .\recognition\predict.py --model lstm --input .\data
conda run -n esp-csi python .\recognition\predict.py --model cnn-lstm --input .\data
conda run -n esp-csi python .\recognition\predict.py --model csi-deepnet --input .\data
conda run -n esp-csi python .\recognition\predict.py --model csi-deepnet --input .\test\data --checkpoint .\test\model\best_model.pt --report-dir .\test\output
```

如果你已经激活 `esp-csi` 环境，也可以直接使用当前环境的 `python`：

```powershell
python .\recognition\predict.py --model csi-deepnet --input .\recognition\test\data --checkpoint .\recognition\test\model\best_model.pt --report-dir .\recognition\test\output
```

Windows 下不要依赖 `.\predict.py` 直接执行。某些机器会把 `.py` 文件关联到 VS Code 等编辑器，表现为“命令无报错但没有任何输出”。这种情况下请改用：

```powershell
.\recognition\predict.cmd --model csi-deepnet --input .\recognition\test\data --checkpoint .\recognition\test\model\best_model.pt --report-dir .\recognition\test\output
```

如果当前目录已经是 `recognition`，则可写为：

```powershell
.\predict.cmd --model csi-deepnet --input .\test\data --checkpoint .\test\model\best_model.pt --report-dir .\test\output
```

离线推理会自动复用 checkpoint 中保存的预处理配置与标准化参数，先对原始 `104` 维 CSI 字节执行与训练阶段一致的解码、滤波和前静止段基线扣除，再完成标准化与模型推理。批量离线评估时会自动跳过 `remark.csv` 之类的辅助文件。

训练得到的 checkpoint 会保存 `model_type`、`model_kwargs`、标准化参数和预处理配置，可直接供 PC 端上位机实时识别加载。

## 目录结构

```text
recognition/
├── CSI-DeepNet/      # CSI-DeepNet 模型项目
├── CNN-LSTM/         # CNN-LSTM 模型项目
├── LSTM/             # LSTM 模型项目
├── predict.cmd       # Windows 命令行包装入口
├── predict.py        # 统一离线验证与推理入口
├── train.py          # 统一训练入口
└── model_registry.py # 模型注册与路径分发
```
