@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_PATH=%SCRIPT_DIR%predict.py"

if /I "%CONDA_DEFAULT_ENV%"=="esp-csi" if defined CONDA_PREFIX if exist "%CONDA_PREFIX%\python.exe" (
    "%CONDA_PREFIX%\python.exe" "%SCRIPT_PATH%" %*
    exit /b %ERRORLEVEL%
)

if exist "%USERPROFILE%\.conda\envs\esp-csi\python.exe" (
    "%USERPROFILE%\.conda\envs\esp-csi\python.exe" "%SCRIPT_PATH%" %*
    exit /b %ERRORLEVEL%
)

where conda >nul 2>nul
if not errorlevel 1 (
    conda run -n esp-csi python "%SCRIPT_PATH%" %*
    exit /b %ERRORLEVEL%
)

where python >nul 2>nul
if not errorlevel 1 (
    python "%SCRIPT_PATH%" %*
    exit /b %ERRORLEVEL%
)

echo [predict.cmd] No Python interpreter was found. Activate the esp-csi environment first. 1>&2
exit /b 1
