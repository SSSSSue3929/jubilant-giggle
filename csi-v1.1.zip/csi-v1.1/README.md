# Gestrure Recognition Based on ESP32C5 WiFi-CSI

本项目围绕“采集、预处理、识别、实时交互”四条链路组织 ESP32-C5 Wi-Fi CSI 手势识别代码。

## 目录

- [项目结构](#项目结构)
- [开发环境](#开发环境)
- [安装相关库](#安装相关库)
- [数据集文件结构](#数据集文件结构)
- [AI 开发约定](#ai-开发约定)

## 项目结构

根目录结构只展示目录级信息。

```text
csi/
├── collect/                        # 采集相关代码，分为 MCU 固件和 PC 端上位机
│   ├── MCU/                        # ESP32-C5 发送端与接收端固件工程
│   └── PC/                         # PC 端上位机、实时识别与采集管理工具
├── preprocessing/                  # 数据增强与样本展示工具。
│   ├── enhancement/                # 样本增强工具
│   └── show/                       # 样本波形展示工具
├── data/                           # 训练与评估数据集根目录，默认不上传样本本体。
├── recognition/                    # 统一训练、验证与模型项目目录。
│   ├── CSI-DeepNet/                # CSI-DeepNet 模型项目
│   ├── CNN-LSTM/                   # CNN-LSTM 模型项目
│   └── LSTM/                       # LSTM 模型项目
└── log/                            # AI 对话记录与环境变更日志。
    ├── log_ai/                     # AI 对话日志
    └── log_env/                    # 环境变更日志

```

## 开发环境

- Python：3.10
- conda 环境名：`esp-csi`(Miniconda3-py310_25.11.1-1)
- MCU 开发环境：ESP-IDF `v6.0.0`(VS Code ESP-IDF 插件 : `v1.10.2`)

## 安装相关库

项目根目录提供了 `requirements.txt`，用于在 `esp-csi` 环境中安装主要 Python 依赖。

首次创建环境可执行：

```powershell
conda create -n esp-csi python=3.10 -y
conda init
conda activate esp-csi
pip install --upgrade pip
pip install -r requirements.txt
```

## 数据集文件结构

```text
ESP32-CSI-GR100/
├── Left/
│   ├── session1
│   │   ├── sample1.csv
│   │   ├── sample1.csv
│   │   ├── ...
│   │   └── sample30.csv
│   ├── session2
│   │   └── ...
│   ├── ...
│   └── session20
│       └── ...
├── Right/
│   └── ...
├── Up/
│   └── ...
├── Down/
│   └── ...
├── Clap/
│   └── ...
├── Invalid/
│   └── ...
└── remark.csv

```

## AI 开发约定

### 编程语言与开发环境要求

- 项目编程语言为 Python。
- 代码修改后需要同步补充简洁中文注释，重点说明关键语句段、关键变量和关键导入用途。
- 项目虚拟环境统一使用 conda，环境名称固定为 `esp-csi`。
- 开发、调试、运行、安装依赖、卸载依赖、升级依赖、降级依赖以及所有库版本调整时，均必须自动切换并严格限定在 `esp-csi` 虚拟环境内进行。
- 绝不允许在其他 Python 环境、系统环境或临时环境中构建本项目，避免环境漂移影响后续复现。
- 凡是 `esp-csi` 虚拟环境中新增库、删除库或变更库版本，均必须同步记录到 `./log/log_env` 文件夹下，并按日期创建对应的 Markdown 日志文件，命名建议为 `YYYY-MM-DD.md`。
- 环境日志应至少记录变更日期、执行原因、增删改的库名称、对应版本以及必要的复现说明，以便后续环境重建与问题追溯。
- 按日期保存的环境日志需要补充“当日主要完成内容总结”，概括当天环境变更与相关处理结果。
- 后续环境日志统一使用中文说明；命令、路径、库名、版本号等技术标识可保留英文或代码格式。
- `README.md` 中的目录索引需要随着章节结构变化自动更新。
- `README.md` 中展示的相关库及版本需要随着 `esp-csi` 虚拟环境中的依赖变化自动更新，并与 `./log/log_env` 中的记录保持一致。
- 后续涉及 PyQt 界面结构调整时，必须先修改 `collect/PC/ui/resources/esp_csi_tool_gui.ui`，再重新生成 `collect/PC/ui/generated/Ui_esp_csi_tool_gui.py`，禁止只改生成文件导致两者失同步。

### 代码提交与 Git 授权要求

- 每次代码编写、修改、重构、修复、文档更新或日志更新完成后，均需要执行 Git 提交，并同步推送到 Gitee 远端 `csi` 仓库。
- 当前仓库明确授予 AI 完整 Git 操作授权，用于处理本仓库开发维护所需的常规 Git 操作。
- 上述授权包括但不限于 `git add`、`git commit`、`git push`、`git pull`、`git fetch`、`git remote`、`git status`、`git log` 等与本仓库协作直接相关的操作。
- 后续在本仓库内进行本地提交与推送到远程 `csi` 仓库时，无需再次单独征求用户确认。
- 提交说明可由 AI 根据本次改动内容自主编写，要求准确、简洁、可追踪。
- 远端仓库默认指向 Gitee `csi` 仓库；若未特别说明，默认推送目标为 `origin/master`。
- 提交内容应与本次改动保持一致，确保版本历史可追踪、可回滚、可审计。
- `reference/` 文件夹及其内容仅作为本地参考资料保留；除非用户特别说明，后续默认不上传到远程 `csi` 仓库。

### AI 对话记录要求

- 每次对话记录均需要保存在 `./log/log_ai` 文件夹下，并按日期创建对应的 Markdown 日志文件，命名建议为 `YYYY-MM-DD.md`。
- 对话日志应至少包含本次需求、执行内容、关键结论以及必要的后续说明，方便项目协作与过程复盘。
- 按日期保存的 AI 对话日志需要补充“当日主要完成内容总结”，概括该日期内的主要完成事项与最终结果。
- 后续 AI 对话日志统一使用中文说明；文件路径、命令、指标名、模型名等必要技术内容可保留英文或代码格式。
