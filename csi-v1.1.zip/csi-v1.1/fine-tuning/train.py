"""微调训练项目入口，基于旧模型与少量新 session 执行方案 A 微调。"""

from __future__ import annotations

import argparse
import copy
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn
from torch.optim.lr_scheduler import ReduceLROnPlateau
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

FINE_TUNING_ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = FINE_TUNING_ROOT.parent
RECOGNITION_ROOT = PROJECT_ROOT / "recognition"
RECOGNITION_LSTM_ROOT = RECOGNITION_ROOT / "LSTM"

for candidate_path in [
    str(RECOGNITION_LSTM_ROOT),
    str(RECOGNITION_ROOT),
    str(PROJECT_ROOT),
]:
    if candidate_path not in sys.path:
        sys.path.insert(0, candidate_path)

from class_config import CLASSIFICATION_COUNT
from csi_preprocessing import (
    DEFAULT_FRONT_BASELINE_FRAMES,
    MODEL_INPUT_FEATURE_DIM,
    RAW_CSI_FEATURE_DIM,
    PerSampleBaselinePreprocessor,
)
from dataset import (
    FeatureNormalizer,
    build_cross_session_split,
    build_label_mapping,
    build_same_session_split,
    discover_class_names,
    discover_samples,
    discover_sessions,
    load_sample_array,
    summarize_samples,
)
from model_input_config import format_model_input_shape, get_model_sequence_length
from model_registry import get_available_model_types, get_model_class, normalize_model_type
from utils import (
    compute_classification_metrics,
    describe_device,
    ensure_dir,
    save_confusion_matrix_csv,
    save_confusion_matrix_plot,
    save_history_csv,
    save_json,
    save_training_history_plots,
    select_device,
    set_seed,
    timestamp_for_log,
    timestamp_for_name,
)

MODEL_SEQUENCE_LENGTH = get_model_sequence_length()
BEST_ARTIFACT_FILENAMES = [
    "best_model.pt",
    "label_mapping.json",
    "normalizer.json",
    "preprocessing.json",
    "best_confusion_matrix.csv",
    "best_confusion_matrix.png",
]


class EarlyStopping:
    """根据验证集 F1 提前停止微调，避免少量新数据下过拟合。"""

    def __init__(self, patience: int, min_delta: float = 0.0) -> None:
        self.patience = int(patience)
        self.min_delta = float(min_delta)
        self.best_score: float | None = None
        self.counter = 0

    def step(self, score: float) -> bool:
        if self.best_score is None or score > self.best_score + self.min_delta:
            self.best_score = score
            self.counter = 0
            return False
        self.counter += 1
        return self.counter >= self.patience


class FineTuningDataset(Dataset[tuple[torch.Tensor, int]]):
    """预加载微调样本，并输出 `[1, T, F]` 张量与标签。"""

    def __init__(
        self,
        samples: list[dict[str, Any]],
        preprocessor: PerSampleBaselinePreprocessor,
        normalizer: FeatureNormalizer | None,
    ) -> None:
        self.samples = samples
        self.preprocessor = preprocessor
        self.normalizer = normalizer
        self._items: list[tuple[torch.Tensor, int]] = []
        self._preload()

    def _preload(self) -> None:
        for sample in self.samples:
            raw_sample = load_sample_array(
                Path(sample["absolute_path"]),
                sequence_length=MODEL_SEQUENCE_LENGTH,
                feature_dim=RAW_CSI_FEATURE_DIM,
            )
            processed_sample = self.preprocessor.preprocess(raw_sample)
            if self.normalizer is not None:
                processed_sample = self.normalizer.transform(processed_sample)
            tensor = torch.from_numpy(processed_sample.astype(np.float32)).unsqueeze(0)
            self._items.append((tensor, int(sample["label"])))

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index: int) -> tuple[torch.Tensor, int]:
        return self._items[index]


def parse_args() -> argparse.Namespace:
    """解析微调训练参数。"""

    parser = argparse.ArgumentParser(
        description=(
            "Fine-tune an existing recognition model with mixed old/new sessions. "
            "The default strategy follows scheme A: small learning rate, short epochs, "
            "new sessions split for validation, and a capped old-data supplement."
        )
    )
    parser.add_argument(
        "--old-data-dir",
        type=Path,
        default=FINE_TUNING_ROOT / "data" / "old",
        help="旧数据集目录，目录结构与原始 data 根目录一致。",
    )
    parser.add_argument(
        "--new-data-dir",
        type=Path,
        default=FINE_TUNING_ROOT / "data" / "new",
        help="新采集 session 目录，目录结构与原始 data 根目录一致。",
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=FINE_TUNING_ROOT / "model" / "best_model.pt",
        help="旧模型权重路径，用作微调初始化。",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=FINE_TUNING_ROOT / "outputs",
        help="微调输出目录。",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="auto",
        choices=["auto", *get_available_model_types()],
        help="模型类型。默认 auto，会优先读取 checkpoint 中保存的 model_type。",
    )
    parser.add_argument(
        "--split-mode",
        type=str,
        default="cross-session",
        choices=["same-session", "cross-session"],
        help="仅对 new 数据执行的验证集划分方式。",
    )
    parser.add_argument("--epochs", type=int, default=50, help="微调最大 epoch 数。")
    parser.add_argument("--batch-size", type=int, default=16, help="批大小。")
    parser.add_argument(
        "--lr",
        type=float,
        default=1e-4,
        help="方案 A 默认使用更小学习率进行微调。",
    )
    parser.add_argument(
        "--weight-decay",
        type=float,
        default=1e-4,
        help="Adam 优化器权重衰减。",
    )
    parser.add_argument(
        "--dropout",
        type=float,
        default=-1.0,
        help="若大于等于 0，则覆盖 checkpoint 中的 dropout；默认沿用旧模型配置。",
    )
    parser.add_argument(
        "--old-to-new-ratio",
        type=float,
        default=2.0,
        help="训练集中旧样本相对新样本的最大数量比例，默认 2:1。",
    )
    parser.add_argument(
        "--baseline-frames",
        type=int,
        default=DEFAULT_FRONT_BASELINE_FRAMES,
        help="前静止段基线帧数，保持与原训练流程一致。",
    )
    parser.add_argument(
        "--val-ratio",
        type=float,
        default=0.2,
        help="仅用于 new 数据划分验证集的比例。",
    )
    parser.add_argument(
        "--scheduler-patience",
        type=int,
        default=2,
        help="验证集 F1 无提升后，学习率调度等待的 epoch 数。",
    )
    parser.add_argument(
        "--scheduler-factor",
        type=float,
        default=0.5,
        help="学习率衰减倍率。",
    )
    parser.add_argument(
        "--min-lr",
        type=float,
        default=1e-6,
        help="微调阶段的最小学习率。",
    )
    parser.add_argument(
        "--early-stop-patience",
        type=int,
        default=6,
        help="验证集 F1 连续无提升时提前停止的 patience。",
    )
    parser.add_argument(
        "--early-stop-min-delta",
        type=float,
        default=0.0,
        help="早停要求的最小提升幅度。",
    )
    parser.add_argument("--seed", type=int, default=42, help="随机种子。")
    parser.add_argument(
        "--device",
        choices=["auto", "cpu", "cuda"],
        default="auto",
        help="训练设备。",
    )
    parser.add_argument(
        "--num-workers",
        type=int,
        default=0,
        help="DataLoader worker 数量，Windows 下默认保持 0。",
    )
    parser.add_argument(
        "--run-name",
        type=str,
        default="",
        help="可选运行名，默认自动生成时间戳。",
    )
    return parser.parse_args()


def decorate_samples(
    samples: list[dict[str, Any]],
    *,
    source_name: str,
    source_root: Path,
) -> list[dict[str, Any]]:
    """为样本补充来源信息与绝对路径，便于混合旧新数据。"""

    decorated: list[dict[str, Any]] = []
    for sample in samples:
        source_relative_path = str(sample["relative_path"]).replace("\\", "/")
        decorated.append(
            {
                "relative_path": f"{source_name}/{source_relative_path}",
                "source_relative_path": source_relative_path,
                "absolute_path": str((source_root / source_relative_path).resolve()),
                "source_name": source_name,
                "source_root": str(source_root.resolve()),
                "session_name": str(sample["session_name"]),
                "class_name": str(sample["class_name"]),
                "label": int(sample["label"]),
            }
        )
    return decorated


def summarize_mixed_samples(samples: list[dict[str, Any]]) -> dict[str, Any]:
    """在原始样本统计基础上，额外给出 old/new 来源分布。"""

    summary = summarize_samples(samples)
    by_source: dict[str, int] = defaultdict(int)
    for sample in samples:
        by_source[str(sample["source_name"])] += 1
    summary["by_source"] = dict(sorted(by_source.items()))
    return summary


def balanced_take_old_samples(
    old_samples: list[dict[str, Any]],
    target_total: int,
    seed: int,
) -> list[dict[str, Any]]:
    """按类别轮转抽样旧数据，避免旧样本裁剪后类别失衡。"""

    if target_total <= 0 or not old_samples:
        return []
    if target_total >= len(old_samples):
        return [dict(sample) for sample in old_samples]

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for sample in old_samples:
        grouped[str(sample["class_name"])].append(dict(sample))

    rng = np.random.default_rng(seed)
    for class_samples in grouped.values():
        rng.shuffle(class_samples)

    selected: list[dict[str, Any]] = []
    class_names = sorted(grouped.keys())
    while len(selected) < target_total:
        progressed = False
        for class_name in class_names:
            class_samples = grouped[class_name]
            if not class_samples:
                continue
            selected.append(class_samples.pop())
            progressed = True
            if len(selected) >= target_total:
                break
        if not progressed:
            break
    return selected


def fit_preprocessed_normalizer_for_samples(
    samples: list[dict[str, Any]],
    preprocessor: PerSampleBaselinePreprocessor,
) -> FeatureNormalizer:
    """只用微调训练集拟合标准化参数，保持与原训练策略一致。"""

    sum_vector = np.zeros(MODEL_INPUT_FEATURE_DIM, dtype=np.float64)
    sum_square_vector = np.zeros(MODEL_INPUT_FEATURE_DIM, dtype=np.float64)
    total_rows = 0

    for sample in samples:
        raw_sample = load_sample_array(
            Path(sample["absolute_path"]),
            sequence_length=MODEL_SEQUENCE_LENGTH,
            feature_dim=RAW_CSI_FEATURE_DIM,
        )
        processed_sample = preprocessor.preprocess(raw_sample)
        flattened = processed_sample.reshape(-1, MODEL_INPUT_FEATURE_DIM)
        sum_vector += flattened.sum(axis=0)
        sum_square_vector += np.square(flattened).sum(axis=0)
        total_rows += flattened.shape[0]

    mean = sum_vector / total_rows
    variance = np.maximum(sum_square_vector / total_rows - np.square(mean), 1e-12)
    std = np.sqrt(variance)
    std[std < 1e-6] = 1.0
    return FeatureNormalizer(mean=mean.astype(np.float32), std=std.astype(np.float32))


def build_mixed_split_manifest(
    *,
    old_data_dir: Path,
    new_data_dir: Path,
    split_mode: str,
    old_all_sessions: list[str],
    new_train_sessions: list[str],
    new_val_sessions: list[str],
    train_samples: list[dict[str, Any]],
    val_samples: list[dict[str, Any]],
) -> dict[str, Any]:
    """保存微调数据划分信息，方便后续复现实验。"""

    return {
        "old_data_dir": str(old_data_dir.resolve()),
        "new_data_dir": str(new_data_dir.resolve()),
        "split_mode": split_mode,
        "old_sessions": old_all_sessions,
        "new_train_sessions": new_train_sessions,
        "new_val_sessions": new_val_sessions,
        "train_summary": summarize_mixed_samples(train_samples),
        "val_summary": summarize_mixed_samples(val_samples),
        "train": train_samples,
        "val": val_samples,
    }


def resolve_class_names(
    old_data_dir: Path,
    new_data_dir: Path,
    checkpoint: dict[str, Any],
) -> list[str]:
    """统一校验旧数据、新数据与旧模型的类别顺序。"""

    new_sessions = discover_sessions(new_data_dir)
    if not new_sessions:
        raise RuntimeError(f"No session directories were found under {new_data_dir}.")

    class_names = discover_class_names(new_data_dir, session_names=new_sessions)
    old_sessions = discover_sessions(old_data_dir)
    if old_sessions:
        old_class_names = discover_class_names(old_data_dir, session_names=old_sessions)
        if old_class_names != class_names:
            raise RuntimeError(
                "Old and new datasets expose different class orders: "
                f"{old_class_names} != {class_names}."
            )

    checkpoint_class_names = checkpoint.get("class_names")
    if checkpoint_class_names and list(checkpoint_class_names) != class_names:
        raise RuntimeError(
            "Checkpoint class order does not match the current fine-tuning dataset: "
            f"{list(checkpoint_class_names)} != {class_names}."
        )
    return class_names


def build_finetune_split(
    *,
    old_data_dir: Path,
    new_data_dir: Path,
    label_mapping: dict[str, int],
    split_mode: str,
    val_ratio: float,
    seed: int,
    old_to_new_ratio: float,
) -> dict[str, Any]:
    """构造方案 A 所需的 old/new 混合训练集与 new-only 验证集。"""

    if split_mode == "same-session":
        new_train_raw, new_val_raw, new_train_sessions, new_val_sessions = build_same_session_split(
            data_dir=new_data_dir,
            label_mapping=label_mapping,
            val_ratio=val_ratio,
            seed=seed,
        )
    elif split_mode == "cross-session":
        new_train_raw, new_val_raw, new_train_sessions, new_val_sessions = build_cross_session_split(
            data_dir=new_data_dir,
            label_mapping=label_mapping,
            val_ratio=val_ratio,
            seed=seed,
        )
    else:
        raise ValueError(f"Unsupported split mode: {split_mode}")

    old_sessions = discover_sessions(old_data_dir)
    old_raw_samples = (
        discover_samples(old_data_dir, label_mapping=label_mapping, session_names=old_sessions)
        if old_sessions
        else []
    )

    max_old_samples = int(round(max(old_to_new_ratio, 0.0) * len(new_train_raw)))
    selected_old_raw = balanced_take_old_samples(
        old_raw_samples,
        target_total=max_old_samples,
        seed=seed,
    )

    train_samples = decorate_samples(
        selected_old_raw,
        source_name="old",
        source_root=old_data_dir,
    ) + decorate_samples(
        new_train_raw,
        source_name="new",
        source_root=new_data_dir,
    )
    val_samples = decorate_samples(
        new_val_raw,
        source_name="new",
        source_root=new_data_dir,
    )

    if not train_samples:
        raise RuntimeError("Fine-tuning train set is empty.")
    if not val_samples:
        raise RuntimeError("Fine-tuning validation set is empty.")

    return {
        "train_samples": train_samples,
        "val_samples": val_samples,
        "old_sessions": old_sessions,
        "new_train_sessions": new_train_sessions,
        "new_val_sessions": new_val_sessions,
        "selected_old_raw_count": len(selected_old_raw),
        "new_train_raw_count": len(new_train_raw),
    }


def build_model_from_checkpoint(
    *,
    checkpoint: dict[str, Any],
    requested_model: str,
    num_classes: int,
    dropout_override: float,
    device: torch.device,
) -> tuple[nn.Module, str, dict[str, Any]]:
    """用旧模型权重初始化待微调模型。"""

    checkpoint_model_type = normalize_model_type(checkpoint.get("model_type", "lstm"))
    resolved_model_type = (
        checkpoint_model_type
        if requested_model == "auto"
        else normalize_model_type(requested_model)
    )
    if requested_model != "auto" and resolved_model_type != checkpoint_model_type:
        print(
            f"[{timestamp_for_log()}] Warning: checkpoint model_type is "
            f"{checkpoint_model_type}, but requested model is {resolved_model_type}. "
            "Will continue with the requested model type."
        )

    model_kwargs_payload = checkpoint.get("model_kwargs")
    if isinstance(model_kwargs_payload, dict) and model_kwargs_payload:
        model_kwargs = dict(model_kwargs_payload)
    else:
        model_kwargs = {
            "input_size": int(checkpoint.get("input_size", MODEL_INPUT_FEATURE_DIM)),
            "hidden_size": int(checkpoint.get("hidden_size", 128)),
            "num_layers": int(checkpoint.get("num_layers", 2)),
            "num_classes": int(checkpoint.get("num_classes", num_classes)),
            "dropout": float(checkpoint.get("dropout", 0.4)),
        }

    model_kwargs["input_size"] = MODEL_INPUT_FEATURE_DIM
    model_kwargs["num_classes"] = num_classes
    if dropout_override >= 0.0:
        model_kwargs["dropout"] = float(dropout_override)

    model_class = get_model_class(resolved_model_type)
    model = model_class(**model_kwargs).to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    return model, resolved_model_type, model_kwargs


def train_one_epoch(
    *,
    model: nn.Module,
    dataloader: DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    class_names: list[str],
    epoch_index: int,
    total_epochs: int,
) -> dict[str, Any]:
    """执行单个微调 epoch，并统计完整训练指标。"""

    model.train()
    total_loss = 0.0
    total_correct = 0
    total_items = 0
    y_true: list[int] = []
    y_pred: list[int] = []

    progress = tqdm(
        dataloader,
        desc=f"Fine-tune Epoch {epoch_index}/{total_epochs} [train]",
        leave=False,
    )
    for features, labels in progress:
        features = features.to(device)
        labels = labels.to(device)

        optimizer.zero_grad(set_to_none=True)
        logits = model(features)
        loss = criterion(logits, labels)
        loss.backward()
        optimizer.step()

        predictions = torch.argmax(logits, dim=1)
        batch_size = labels.size(0)
        total_loss += loss.item() * batch_size
        total_correct += (predictions == labels).sum().item()
        total_items += batch_size
        y_true.extend(labels.detach().cpu().tolist())
        y_pred.extend(predictions.detach().cpu().tolist())

        progress.set_postfix(
            loss=f"{total_loss / max(total_items, 1):.4f}",
            acc=f"{total_correct / max(total_items, 1):.4f}",
        )

    metrics = compute_classification_metrics(
        y_true=y_true,
        y_pred=y_pred,
        label_ids=list(range(len(class_names))),
    )
    metrics["loss"] = total_loss / max(total_items, 1)
    return metrics


def evaluate(
    *,
    model: nn.Module,
    dataloader: DataLoader,
    criterion: nn.Module,
    device: torch.device,
    class_names: list[str],
    epoch_index: int,
    total_epochs: int,
    stage_name: str,
) -> dict[str, Any]:
    """在验证集上评估当前模型。"""

    model.eval()
    total_loss = 0.0
    total_items = 0
    y_true: list[int] = []
    y_pred: list[int] = []

    progress = tqdm(
        dataloader,
        desc=f"{stage_name} {epoch_index}/{total_epochs} [val]",
        leave=False,
    )
    with torch.no_grad():
        for features, labels in progress:
            features = features.to(device)
            labels = labels.to(device)
            logits = model(features)
            loss = criterion(logits, labels)

            predictions = torch.argmax(logits, dim=1)
            batch_size = labels.size(0)
            total_loss += loss.item() * batch_size
            total_items += batch_size
            y_true.extend(labels.cpu().tolist())
            y_pred.extend(predictions.cpu().tolist())

            running_accuracy = sum(int(a == b) for a, b in zip(y_true, y_pred)) / max(
                len(y_true), 1
            )
            progress.set_postfix(
                loss=f"{total_loss / max(total_items, 1):.4f}",
                acc=f"{running_accuracy:.4f}",
            )

    metrics = compute_classification_metrics(
        y_true=y_true,
        y_pred=y_pred,
        label_ids=list(range(len(class_names))),
    )
    metrics["loss"] = total_loss / max(total_items, 1)
    return metrics


def save_best_artifacts(
    *,
    target_dir: Path,
    checkpoint_payload: dict[str, Any],
    label_mapping: dict[str, int],
    normalizer_payload: dict[str, Any],
    preprocessing_payload: dict[str, Any],
    confusion_matrix: list[list[int]],
    class_names: list[str],
) -> None:
    """保存当前最佳微调权重及其配套元数据。"""

    ensure_dir(target_dir)
    torch.save(checkpoint_payload, target_dir / "best_model.pt")
    save_json(target_dir / "label_mapping.json", label_mapping)
    save_json(target_dir / "normalizer.json", normalizer_payload)
    save_json(target_dir / "preprocessing.json", preprocessing_payload)
    save_confusion_matrix_csv(
        target_dir / "best_confusion_matrix.csv",
        confusion_matrix,
        class_names,
    )
    save_confusion_matrix_plot(
        target_dir / "best_confusion_matrix.png",
        confusion_matrix,
        class_names,
        normalize=True,
        title="Best Fine-tuning Validation Confusion Matrix",
    )


def build_checkpoint_payload(
    *,
    model_state_dict: dict[str, Any],
    model_type: str,
    model_kwargs: dict[str, Any],
    class_names: list[str],
    label_mapping: dict[str, int],
    normalizer_payload: dict[str, Any],
    preprocessing_payload: dict[str, Any],
    best_epoch: int,
    best_metrics: dict[str, Any],
    split_mode: str,
    args: argparse.Namespace,
    split_context: dict[str, Any],
) -> dict[str, Any]:
    """构造微调后的 checkpoint 元数据。"""

    return {
        "model_type": model_type,
        "model_kwargs": dict(model_kwargs),
        "model_state_dict": model_state_dict,
        "input_size": MODEL_INPUT_FEATURE_DIM,
        "input_channels": 1,
        "num_classes": len(class_names),
        "configured_class_count": CLASSIFICATION_COUNT,
        "dropout": float(model_kwargs.get("dropout", 0.0)),
        "class_names": class_names,
        "label_mapping": label_mapping,
        "normalizer": normalizer_payload,
        "preprocessing": preprocessing_payload,
        "best_epoch": best_epoch,
        "best_metrics": {
            key: value for key, value in best_metrics.items() if key != "confusion_matrix"
        },
        "sequence_length": MODEL_SEQUENCE_LENGTH,
        "raw_input_shape": [MODEL_SEQUENCE_LENGTH, RAW_CSI_FEATURE_DIM],
        "model_input_shape": [MODEL_SEQUENCE_LENGTH, MODEL_INPUT_FEATURE_DIM],
        "split_mode": split_mode,
        "fine_tuning": {
            "base_checkpoint": str(args.checkpoint.resolve()),
            "old_data_dir": str(args.old_data_dir.resolve()),
            "new_data_dir": str(args.new_data_dir.resolve()),
            "old_to_new_ratio": float(args.old_to_new_ratio),
            "old_sessions": list(split_context["old_sessions"]),
            "new_train_sessions": list(split_context["new_train_sessions"]),
            "new_val_sessions": list(split_context["new_val_sessions"]),
            "selected_old_raw_count": int(split_context["selected_old_raw_count"]),
            "new_train_raw_count": int(split_context["new_train_raw_count"]),
        },
    }


def main() -> None:
    """微调训练入口。"""

    args = parse_args()
    set_seed(args.seed)

    if not args.checkpoint.exists():
        raise FileNotFoundError(f"Missing base checkpoint: {args.checkpoint}")
    if not args.new_data_dir.exists():
        raise FileNotFoundError(f"Missing new dataset directory: {args.new_data_dir}")
    if not args.old_data_dir.exists():
        print(
            f"[{timestamp_for_log()}] Warning: old dataset directory does not exist yet: "
            f"{args.old_data_dir}. Fine-tuning will use only new data."
        )

    checkpoint = torch.load(
        args.checkpoint,
        map_location="cpu",
        weights_only=False,
    )
    class_names = resolve_class_names(args.old_data_dir, args.new_data_dir, checkpoint)
    label_mapping = build_label_mapping(class_names=class_names)
    split_context = build_finetune_split(
        old_data_dir=args.old_data_dir,
        new_data_dir=args.new_data_dir,
        label_mapping=label_mapping,
        split_mode=args.split_mode,
        val_ratio=args.val_ratio,
        seed=args.seed,
        old_to_new_ratio=args.old_to_new_ratio,
    )

    device = select_device(args.device)
    print(f"[{timestamp_for_log()}] {describe_device(device)}")
    print(
        f"[{timestamp_for_log()}] Raw model input shape: {format_model_input_shape()} | "
        f"decoded input shape: [{MODEL_SEQUENCE_LENGTH}, {MODEL_INPUT_FEATURE_DIM}]"
    )

    model, model_type, model_kwargs = build_model_from_checkpoint(
        checkpoint=checkpoint,
        requested_model=args.model,
        num_classes=len(class_names),
        dropout_override=args.dropout,
        device=device,
    )

    run_name = args.run_name or f"fine_tune_{args.split_mode.replace('-', '_')}_{timestamp_for_name()}"
    run_dir = ensure_dir(args.output_dir / run_name)

    split_manifest = build_mixed_split_manifest(
        old_data_dir=args.old_data_dir,
        new_data_dir=args.new_data_dir,
        split_mode=args.split_mode,
        old_all_sessions=split_context["old_sessions"],
        new_train_sessions=split_context["new_train_sessions"],
        new_val_sessions=split_context["new_val_sessions"],
        train_samples=split_context["train_samples"],
        val_samples=split_context["val_samples"],
    )
    save_json(run_dir / "split_manifest.json", split_manifest)

    preprocessor = PerSampleBaselinePreprocessor(args.baseline_frames)
    preprocessing_payload = preprocessor.to_dict()
    normalizer = fit_preprocessed_normalizer_for_samples(
        split_context["train_samples"],
        preprocessor,
    )
    normalizer_payload = normalizer.to_dict()
    save_json(run_dir / "label_mapping.json", label_mapping)
    save_json(run_dir / "normalizer.json", normalizer_payload)
    save_json(run_dir / "preprocessing.json", preprocessing_payload)

    train_dataset = FineTuningDataset(
        split_context["train_samples"],
        preprocessor=preprocessor,
        normalizer=normalizer,
    )
    val_dataset = FineTuningDataset(
        split_context["val_samples"],
        preprocessor=preprocessor,
        normalizer=normalizer,
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=device.type == "cuda",
    )

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )
    scheduler = ReduceLROnPlateau(
        optimizer,
        mode="max",
        factor=args.scheduler_factor,
        patience=args.scheduler_patience,
        min_lr=args.min_lr,
    )
    early_stopper = EarlyStopping(
        patience=args.early_stop_patience,
        min_delta=args.early_stop_min_delta,
    )

    print(
        f"[{timestamp_for_log()}] Model type: {model_type} | "
        f"checkpoint: {args.checkpoint}"
    )
    print(
        f"[{timestamp_for_log()}] Train summary: "
        f"{summarize_mixed_samples(split_context['train_samples'])}"
    )
    print(
        f"[{timestamp_for_log()}] Val summary: "
        f"{summarize_mixed_samples(split_context['val_samples'])}"
    )

    baseline_metrics = evaluate(
        model=model,
        dataloader=val_loader,
        criterion=criterion,
        device=device,
        class_names=class_names,
        epoch_index=0,
        total_epochs=args.epochs,
        stage_name="Baseline",
    )
    print(
        f"[{timestamp_for_log()}] Baseline val metrics before fine-tuning: "
        f"acc={baseline_metrics['accuracy']:.4f}, "
        f"precision={baseline_metrics['precision']:.4f}, "
        f"recall={baseline_metrics['recall']:.4f}, "
        f"f1={baseline_metrics['f1']:.4f}."
    )

    best_epoch = 0
    best_metrics = copy.deepcopy(baseline_metrics)
    best_state_dict = copy.deepcopy(model.state_dict())
    save_best_artifacts(
        target_dir=run_dir,
        checkpoint_payload=build_checkpoint_payload(
            model_state_dict=best_state_dict,
            model_type=model_type,
            model_kwargs=model_kwargs,
            class_names=class_names,
            label_mapping=label_mapping,
            normalizer_payload=normalizer_payload,
            preprocessing_payload=preprocessing_payload,
            best_epoch=best_epoch,
            best_metrics=best_metrics,
            split_mode=args.split_mode,
            args=args,
            split_context=split_context,
        ),
        label_mapping=label_mapping,
        normalizer_payload=normalizer_payload,
        preprocessing_payload=preprocessing_payload,
        confusion_matrix=best_metrics["confusion_matrix"],
        class_names=class_names,
    )

    history: list[dict[str, Any]] = []
    stopped_early = False
    final_epoch = 0
    for epoch_index in range(1, args.epochs + 1):
        final_epoch = epoch_index
        train_metrics = train_one_epoch(
            model=model,
            dataloader=train_loader,
            criterion=criterion,
            optimizer=optimizer,
            device=device,
            class_names=class_names,
            epoch_index=epoch_index,
            total_epochs=args.epochs,
        )
        val_metrics = evaluate(
            model=model,
            dataloader=val_loader,
            criterion=criterion,
            device=device,
            class_names=class_names,
            epoch_index=epoch_index,
            total_epochs=args.epochs,
            stage_name="Fine-tune",
        )

        history.append(
            {
                "epoch": epoch_index,
                "lr": round(float(optimizer.param_groups[0]["lr"]), 8),
                "train_loss": round(train_metrics["loss"], 6),
                "train_accuracy": round(train_metrics["accuracy"], 6),
                "train_precision": round(train_metrics["precision"], 6),
                "train_recall": round(train_metrics["recall"], 6),
                "train_f1": round(train_metrics["f1"], 6),
                "val_loss": round(val_metrics["loss"], 6),
                "val_accuracy": round(val_metrics["accuracy"], 6),
                "val_precision": round(val_metrics["precision"], 6),
                "val_recall": round(val_metrics["recall"], 6),
                "val_f1": round(val_metrics["f1"], 6),
            }
        )
        print(
            f"Fine-tune Epoch {epoch_index:02d}/{args.epochs} | "
            f"lr={optimizer.param_groups[0]['lr']:.6f} "
            f"train_loss={train_metrics['loss']:.4f} "
            f"train_acc={train_metrics['accuracy']:.4f} "
            f"train_f1={train_metrics['f1']:.4f} "
            f"val_loss={val_metrics['loss']:.4f} "
            f"val_acc={val_metrics['accuracy']:.4f} "
            f"val_precision={val_metrics['precision']:.4f} "
            f"val_recall={val_metrics['recall']:.4f} "
            f"val_f1={val_metrics['f1']:.4f}"
        )

        if val_metrics["f1"] > best_metrics["f1"]:
            best_epoch = epoch_index
            best_metrics = copy.deepcopy(val_metrics)
            best_state_dict = copy.deepcopy(model.state_dict())
            save_best_artifacts(
                target_dir=run_dir,
                checkpoint_payload=build_checkpoint_payload(
                    model_state_dict=best_state_dict,
                    model_type=model_type,
                    model_kwargs=model_kwargs,
                    class_names=class_names,
                    label_mapping=label_mapping,
                    normalizer_payload=normalizer_payload,
                    preprocessing_payload=preprocessing_payload,
                    best_epoch=best_epoch,
                    best_metrics=best_metrics,
                    split_mode=args.split_mode,
                    args=args,
                    split_context=split_context,
                ),
                label_mapping=label_mapping,
                normalizer_payload=normalizer_payload,
                preprocessing_payload=preprocessing_payload,
                confusion_matrix=best_metrics["confusion_matrix"],
                class_names=class_names,
            )

        scheduler.step(val_metrics["f1"])
        if early_stopper.step(val_metrics["f1"]):
            stopped_early = True
            print(
                f"[{timestamp_for_log()}] Early stopping triggered at epoch {epoch_index}. "
                f"Best epoch remains {best_epoch}."
            )
            break

    save_history_csv(run_dir / "history.csv", history)
    history_plot_paths = save_training_history_plots(run_dir, history)
    summary = {
        "run_name": run_name,
        "model_type": model_type,
        "base_checkpoint": str(args.checkpoint.resolve()),
        "device": str(device),
        "class_names": class_names,
        "configured_class_count": CLASSIFICATION_COUNT,
        "raw_input_shape": [MODEL_SEQUENCE_LENGTH, RAW_CSI_FEATURE_DIM],
        "model_input_shape": [MODEL_SEQUENCE_LENGTH, MODEL_INPUT_FEATURE_DIM],
        "old_data_dir": str(args.old_data_dir.resolve()),
        "new_data_dir": str(args.new_data_dir.resolve()),
        "split_mode": args.split_mode,
        "seed": args.seed,
        "epochs": args.epochs,
        "completed_epochs": final_epoch,
        "batch_size": args.batch_size,
        "learning_rate": args.lr,
        "weight_decay": args.weight_decay,
        "dropout": model_kwargs.get("dropout"),
        "old_to_new_ratio": args.old_to_new_ratio,
        "baseline_frames": args.baseline_frames,
        "scheduler_factor": args.scheduler_factor,
        "scheduler_patience": args.scheduler_patience,
        "min_lr": args.min_lr,
        "early_stop_patience": args.early_stop_patience,
        "early_stop_min_delta": args.early_stop_min_delta,
        "stopped_early": stopped_early,
        "best_epoch": best_epoch,
        "baseline_val_metrics": {
            key: value for key, value in baseline_metrics.items() if key != "confusion_matrix"
        },
        "best_metrics": {
            key: value for key, value in best_metrics.items() if key != "confusion_matrix"
        },
        "train_summary": summarize_mixed_samples(split_context["train_samples"]),
        "val_summary": summarize_mixed_samples(split_context["val_samples"]),
        "history_plot_paths": history_plot_paths,
        "preprocessing": preprocessing_payload,
    }
    save_json(run_dir / "summary.json", summary)

    print(f"[{timestamp_for_log()}] Fine-tuning completed. Best epoch: {best_epoch}.")
    print(
        f"[{timestamp_for_log()}] Best val metrics: "
        f"acc={best_metrics['accuracy']:.4f}, "
        f"precision={best_metrics['precision']:.4f}, "
        f"recall={best_metrics['recall']:.4f}, "
        f"f1={best_metrics['f1']:.4f}."
    )


if __name__ == "__main__":
    main()
