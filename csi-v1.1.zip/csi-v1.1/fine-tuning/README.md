# fine-tuning

`fine-tuning` 目录用于在已有旧模型基础上，结合少量新采集 session 执行方案 A 微调。

## 目录结构

```text
fine-tuning/
├── data/
│   ├── new/        # 新采集 session，目录结构与原始 data 根目录一致
│   └── old/        # 旧数据集，目录结构与原始 data 根目录一致
├── model/          # 旧模型权重，例如 best_model.pt
├── outputs/        # 微调输出目录，会保存 history、曲线图和最佳权重
├── train.cmd       # Windows 包装入口
└── train.py        # 微调训练主脚本
```

## 方案 A 默认策略

- 从旧模型 `best_model.pt` 初始化微调权重。
- 默认使用更小学习率 `1e-4`。
- 默认最多微调 `20` 个 epoch。
- 仅使用 `new` 数据划分验证集，`old` 数据只参与训练补充。
- 训练集中旧样本数量默认限制为新训练样本的 `2:1`，避免旧数据完全压制新场景适配。
- CSI 解码、滤波、前静止段基线扣除和标准化流程与 `recognition` 原训练链路保持一致。

## 数据放置说明

### 1. 新数据集

将新增的 5 个 session 放到 `fine-tuning/data/new/`，目录结构保持和原始训练数据一致，例如：

```text
fine-tuning/data/new/
├── session21/
│   ├── Left/
│   ├── Right/
│   ├── Up/
│   ├── Down/
│   ├── Clap/
│   └── Invalid/
├── session22/
└── ...
```

### 2. 旧数据集

将原有训练数据复制或链接到 `fine-tuning/data/old/`，目录结构同样保持一致。

### 3. 旧模型

将原始训练得到的旧模型权重放到：

```text
fine-tuning/model/best_model.pt
```

如果需要，也可以通过命令行显式指定其他 checkpoint 路径。

## 运行方式

推荐在仓库根目录执行：

```powershell
.\fine-tuning\train.cmd
```

如果已经激活 `esp-csi` 环境，也可以显式使用 Python：

```powershell
python .\fine-tuning\train.py
```

## 常用参数

- `--checkpoint`：旧模型权重路径
- `--split-mode same-session|cross-session`：只对 `new` 数据执行的验证划分方式
- `--lr`：微调学习率，默认 `1e-4`
- `--epochs`：微调 epoch 数，默认 `20`
- `--old-to-new-ratio`：旧样本相对新训练样本的最大数量比例，默认 `2.0`
- `--run-name`：自定义本次微调运行名

示例：

```powershell
.\fine-tuning\train.cmd --checkpoint .\fine-tuning\model\best_model.pt --split-mode cross-session --epochs 20 --lr 1e-4 --old-to-new-ratio 2.0
```

## 输出内容

每次微调会在 `fine-tuning/outputs/<run_name>/` 下保存：

- `best_model.pt`
- `label_mapping.json`
- `normalizer.json`
- `preprocessing.json`
- `split_manifest.json`
- `summary.json`
- `history.csv`
- `accuracy_curve.png`
- `f1_curve.png`
- `loss_curve.png`
- `best_confusion_matrix.csv`
- `best_confusion_matrix.png`

其中：

- `baseline_val_metrics` 会记录“旧模型在新验证集上的初始效果”
- `best_metrics` 会记录“微调后最佳效果”

这样可以直接比较微调前后的改进幅度。
