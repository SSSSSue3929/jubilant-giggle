"""基于 edge-tts 的中文语音播报驱动。

采集完成提示会先通过 Microsoft Edge 在线 TTS 合成为临时 MP3，
再使用 Windows 原生 MCI 播放器播放，整个流程放在后台线程中，
避免阻塞 Qt 主界面。
"""

from __future__ import annotations

import asyncio
import sys
import tempfile
from pathlib import Path
from threading import Thread

import edge_tts
from edge_playback.win32_playback import play_mp3_win32


# 统一维护播报音色和语速，后续若觉得发音不够清晰可直接调这里。
EDGE_TTS_VOICE = "zh-CN-XiaoxiaoNeural"
EDGE_TTS_RATE = "-15%"
EDGE_TTS_VOLUME = "+0%"
EDGE_TTS_PITCH = "+0Hz"


def speak_text_async(text: str) -> None:
    """后台播报提示语，避免阻塞界面线程。"""
    normalized_text = str(text).strip()
    if not normalized_text:
        return

    # 使用守护线程异步播报，界面关闭时无需等待语音线程结束。
    speech_thread = Thread(
        target=_speak_text_blocking,
        args=(normalized_text,),
        daemon=True,
        name="esp-csi-edge-tts",
    )
    speech_thread.start()


def _speak_text_blocking(text: str) -> None:
    """在后台线程中同步执行一次 edge-tts 合成与播放。"""
    if not sys.platform.startswith("win"):
        return

    try:
        # 每次播报各自创建事件循环，避免与 Qt 主线程事件循环互相干扰。
        asyncio.run(_speak_text_with_edge_tts(text))
    except Exception:
        # 语音提醒失败不影响主流程，这里直接静默降级。
        return


async def _speak_text_with_edge_tts(text: str) -> None:
    """使用 edge-tts 合成中文提示音，并播放生成的临时音频文件。"""
    # 先为本次播报准备一个独立的临时 MP3 文件，播放完成后再自动删除。
    temp_file = tempfile.NamedTemporaryFile(suffix=".mp3", delete=False)
    temp_path = Path(temp_file.name)
    temp_file.close()

    try:
        # 这里统一指定中文音色、语速和音量，确保播报结果稳定可控。
        communicate = edge_tts.Communicate(
            text=text,
            voice=EDGE_TTS_VOICE,
            rate=EDGE_TTS_RATE,
            volume=EDGE_TTS_VOLUME,
            pitch=EDGE_TTS_PITCH,
        )
        # edge-tts 会联网请求语音合成服务，并把结果保存成 MP3。
        await communicate.save(str(temp_path))

        # 只有在音频确实生成成功时才执行播放，避免空文件触发异常。
        if temp_path.exists() and temp_path.stat().st_size > 0:
            play_mp3_win32(str(temp_path))
    finally:
        try:
            # 无论播放成功与否，都回收临时文件，避免目录里堆积语音缓存。
            temp_path.unlink(missing_ok=True)
        except OSError:
            return
