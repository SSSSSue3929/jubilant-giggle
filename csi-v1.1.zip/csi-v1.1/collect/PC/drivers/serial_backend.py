"""驱动层串口子进程与原始数据落盘逻辑。"""

from __future__ import annotations

import csv
import queue
import re
import time
from datetime import datetime
from io import StringIO
from pathlib import Path
from threading import Thread

import serial

from core.constants import (
    COLLECT_DATA_ROOT,
    CSI_DATA_COLUMNS_NAMES,
    DEFAULT_CSI_OUTPUT_TYPE,
    RUNTIME_LOG_ROOT,
    SERIAL_BAUDRATE,
    SERIAL_TIMEOUT,
)
from core.utils import base64_decode_bin, ensure_dir


ANSI_ESCAPE_PATTERN = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
ESCAPED_ANSI_ESCAPE_PATTERN = re.compile(r"\\x1b(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])", re.I)


class RuntimeDataRecorder:
    """持久化运行期 CSI 数据与日志，避免界面层直接处理文件。"""

    def __init__(self) -> None:
        """为一次串口连接创建独立运行目录和写盘句柄。"""
        # 每次连接串口都创建独立运行目录，便于追踪单次会话数据。
        connect_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.runtime_dir = ensure_dir(RUNTIME_LOG_ROOT / connect_time)
        self.csi_csv_path = self.runtime_dir / "csi_data.csv"
        self.keyframe_csv_path = self.runtime_dir / "keyframe_marks.csv"
        self.log_txt_path = self.runtime_dir / "log_data.txt"
        # 运行期总表保存所有 CSI 行，便于复盘完整串口会话。
        self.csi_file = self.csi_csv_path.open("w", newline="", encoding="utf-8")
        self.csi_writer = csv.writer(self.csi_file)
        self.csi_writer.writerow(CSI_DATA_COLUMNS_NAMES)
        self.csi_file.flush()
        # 关键帧单独保存到和 csi_data.csv 同目录的独立 CSV 文件中。
        self.keyframe_file = self.keyframe_csv_path.open("w", newline="", encoding="utf-8")
        self.keyframe_writer = csv.writer(self.keyframe_file)
        self.keyframe_writer.writerow(["created_at", "packet_index", "remark"])
        self.keyframe_file.flush()
        # 纯文本日志单独保存，便于排查设备状态与异常信息。
        self.log_file = self.log_txt_path.open("w+", encoding="utf-8")

        # target_last / target_seq_last 用于判断是否需要切换采集目标文件。
        self.target_last = "unknown"
        self.target_seq_last = ""
        self.target_file = None
        self.target_writer = None
        self.collect_time_start = ""
        self.collect_target = ""
        self.collect_packet_num = 0
        self.collect_packet_limit = 0
        self.collect_start_packet_index = -1
        self.pending_collect_target = ""
        self.pending_collect_packet_limit = 0
        self.suppress_segment_collection = False
        self.csi_event_count = 0

    def record_csi_event(self, event: dict, collect_time_queue) -> None:
        """记录单帧 CSI，并按当前采集状态决定是否写入分类样本。"""
        # 先把事件追加到总表，确保所有 CSI 都有完整留痕。
        row = [event.get(column, "") for column in CSI_DATA_COLUMNS_NAMES]
        if isinstance(row[-1], list):
            row[-1] = str(row[-1])
        self.csi_writer.writerow(row)
        self.csi_file.flush()
        self.csi_event_count += 1
        current_packet_index = self.csi_event_count - 1

        target = str(event.get("target", "unknown"))
        target_seq = str(event.get("target_seq", ""))
        if self._is_count_collect_active():
            self._record_active_count_packet(event, target, current_packet_index, collect_time_queue)
            self.target_last = target
            self.target_seq_last = target_seq
            return

        if self._has_pending_count_collect():
            if self.target_last == "unknown" and target == self.pending_collect_target:
                packet_limit = self.pending_collect_packet_limit
                self.pending_collect_target = ""
                self.pending_collect_packet_limit = 0
                self._open_target_file(
                    target,
                    start_packet_index=current_packet_index,
                    packet_limit=packet_limit,
                )
                self._queue_collect_event(
                    collect_time_queue,
                    {
                        "type": "COLLECT_START",
                        "timestamp": self.collect_time_start,
                        "target": target,
                        "start_packet_index": self.collect_start_packet_index,
                    },
                )
                self._append_target_packet(event, current_packet_index, collect_time_queue)

            self.target_last = target
            self.target_seq_last = target_seq
            return

        if self.suppress_segment_collection:
            self.target_last = target
            self.target_seq_last = target_seq
            return

        if target == "unknown":
            if self.target_last != "unknown":
                self._finish_target_file(
                    collect_time_queue,
                    end_packet_index=current_packet_index - 1,
                )
            # unknown 仅更新最近状态，不创建样本分类文件。
            self.target_last = target
            self.target_seq_last = target_seq
            return

        if target != self.target_last or target_seq != self.target_seq_last:
            # 目标或序号变化时，说明进入新的采集片段，需要切换写盘文件。
            self._finish_target_file(
                collect_time_queue,
                end_packet_index=current_packet_index - 1,
            )
            self._open_target_file(
                target,
                start_packet_index=current_packet_index,
                packet_limit=0,
            )
            self._queue_collect_event(
                collect_time_queue,
                {
                    "type": "COLLECT_START",
                    "timestamp": self.collect_time_start,
                    "target": target,
                    "start_packet_index": self.collect_start_packet_index,
                },
            )

        if self.target_writer is not None and self.target_file is not None:
            self._append_target_packet(event, current_packet_index, collect_time_queue)

        self.target_last = target
        self.target_seq_last = target_seq

    def record_log_line(self, line: str) -> None:
        """把普通串口日志按行落盘到当前 runtime 目录。"""
        # 原始日志直接按行落盘，尽量保留设备输出原貌。
        safe_line = line.replace("\x00", "").strip()
        if not safe_line:
            return
        self.log_file.write(f"{safe_line}\n")
        self.log_file.flush()

    def record_keyframe_event(self, event: dict) -> None:
        """将 UI 点击产生的关键帧独立记录到 runtime 目录的 CSV 文件。"""
        packet_index = self._normalize_packet_index(event.get("packet_index", self.csi_event_count - 1))
        remark = str(event.get("remark", "手动标记") or "手动标记")
        self._write_keyframe_row(packet_index, remark)

    @staticmethod
    def _build_collect_boundary_remark(target: str, phase: str) -> str:
        """生成采集开始/结束关键帧备注文本。"""
        normalized_target = str(target).strip() or "unknown"
        phase_text = "开始" if phase == "start" else "结束"
        return f"采集 {normalized_target} {phase_text}"

    @classmethod
    def _is_collect_start_remark(cls, remark: str) -> bool:
        """判断关键帧备注是否表示采集开始。"""
        normalized_remark = str(remark).strip()
        return normalized_remark == "采集开始" or (
            normalized_remark.startswith("采集 ") and normalized_remark.endswith(" 开始")
        )

    @classmethod
    def _is_collect_end_remark(cls, remark: str) -> bool:
        """判断关键帧备注是否表示采集结束。"""
        normalized_remark = str(remark).strip()
        return normalized_remark == "采集结束" or (
            normalized_remark.startswith("采集 ") and normalized_remark.endswith(" 结束")
        )

    def delete_collect_keyframes(self, event: dict) -> int:
        """删除某个采集样本对应的开始/结束关键帧记录。"""
        keyframe_csv_path = str(event.get("keyframe_csv_path", "")).strip()
        if keyframe_csv_path and Path(keyframe_csv_path).resolve() != self.keyframe_csv_path.resolve():
            return 0

        start_packet_index = self._normalize_packet_index(event.get("start_packet_index"))
        end_packet_index = self._normalize_packet_index(event.get("end_packet_index"))
        if end_packet_index < start_packet_index:
            start_packet_index, end_packet_index = end_packet_index, start_packet_index

        fieldnames, rows = self._read_csv_dict_rows(self.keyframe_csv_path)
        if "packet_index" not in fieldnames or "remark" not in fieldnames:
            return 0

        deleted_rows = 0
        deleted_start = False
        deleted_end = False
        remaining_rows: list[dict[str, str]] = []
        for row in rows:
            packet_index = self._safe_int(row.get("packet_index", ""))
            remark = str(row.get("remark", "")).strip()
            if not deleted_start and packet_index == start_packet_index and self._is_collect_start_remark(remark):
                deleted_start = True
                deleted_rows += 1
                continue
            if not deleted_end and packet_index == end_packet_index and self._is_collect_end_remark(remark):
                deleted_end = True
                deleted_rows += 1
                continue
            remaining_rows.append(row)

        if deleted_rows <= 0:
            return 0

        self.keyframe_file.close()
        self.keyframe_file = self.keyframe_csv_path.open("w", newline="", encoding="utf-8")
        self.keyframe_writer = csv.writer(self.keyframe_file)
        self.keyframe_writer.writerow(fieldnames)
        for row in remaining_rows:
            self.keyframe_writer.writerow([row.get(fieldname, "") for fieldname in fieldnames])
        self.keyframe_file.flush()
        return deleted_rows

    def _open_target_file(self, target: str, start_packet_index: int, packet_limit: int = 0) -> None:
        """为新的采集片段创建样本 CSV，并写入开始关键帧。"""
        target_dir = ensure_dir(COLLECT_DATA_ROOT / target)
        # 文件名使用毫秒级时间戳，便于和 remark.csv 对齐。
        self.collect_time_start = datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3]
        self.collect_target = target
        self.collect_packet_num = 0
        self.collect_packet_limit = max(int(packet_limit), 0)
        self.collect_start_packet_index = self._normalize_packet_index(start_packet_index)
        file_path = target_dir / f"{self.collect_time_start}.csv"
        self.target_file = Path(file_path).open("w", newline="", encoding="utf-8")
        self.target_writer = csv.writer(self.target_file)
        self.target_writer.writerow(CSI_DATA_COLUMNS_NAMES)
        # 采集开始关键帧以真正写入目标采集文件的首个 CSI 包索引为准。
        self._write_keyframe_row(
            self.collect_start_packet_index,
            self._build_collect_boundary_remark(target, "start"),
        )

    def _finish_target_file(self, collect_time_queue, end_packet_index: int | None = None) -> None:
        """收口当前采集片段，并向主进程回传采集结果事件。"""
        if self.target_file is None or not self.collect_time_start:
            self._close_target_file()
            return

        start_packet_index = self.collect_start_packet_index
        if end_packet_index is None:
            if self.collect_packet_num > 0 and start_packet_index >= 0:
                end_packet_index = start_packet_index + self.collect_packet_num - 1
            else:
                end_packet_index = start_packet_index
        normalized_end_packet_index = self._normalize_packet_index(end_packet_index)

        if self.collect_packet_num > 0 and normalized_end_packet_index >= start_packet_index >= 0:
            # 采集结束关键帧对齐到最后一个真正写入目标采集文件的 CSI 包索引。
            self._write_keyframe_row(
                normalized_end_packet_index,
                self._build_collect_boundary_remark(self.collect_target or self.target_last, "end"),
            )

        self._queue_collect_event(
            collect_time_queue,
            {
                "type": "COLLECT_RESULT",
                "timestamp": self.collect_time_start,
                "target": self.collect_target or self.target_last,
                "num": self.collect_packet_num,
                "start_packet_index": start_packet_index,
                "end_packet_index": normalized_end_packet_index,
                "keyframe_csv_path": str(self.keyframe_csv_path),
            },
        )
        self._close_target_file()

    def _close_target_file(self) -> None:
        """关闭当前采集样本文件，并清空采集状态。"""
        if self.target_file is not None:
            self.target_file.close()
        self.target_file = None
        self.target_writer = None
        self.collect_time_start = ""
        self.collect_target = ""
        self.collect_packet_num = 0
        self.collect_packet_limit = 0
        self.collect_start_packet_index = -1

    def _append_target_packet(self, event: dict, current_packet_index: int, collect_time_queue) -> None:
        """把当前目标帧写入分类样本文件，并检查是否达到包数上限。"""
        if self.target_writer is None or self.target_file is None:
            return

        # 分类文件只保存当前采集目标内的数据，便于训练集整理。
        self.target_writer.writerow([str(event.get(column, "")) for column in CSI_DATA_COLUMNS_NAMES])
        self.target_file.flush()
        self.collect_packet_num += 1
        if self.collect_packet_limit > 0 and self.collect_packet_num >= self.collect_packet_limit:
            # count 模式以第 N 个目标包写盘完成的时刻为结束边界。
            self.suppress_segment_collection = True
            self._finish_target_file(
                collect_time_queue,
                end_packet_index=current_packet_index,
            )

    def _record_active_count_packet(
        self,
        event: dict,
        target: str,
        current_packet_index: int,
        collect_time_queue,
    ) -> None:
        """在按包数采集中，仅统计目标标签匹配的 CSI 帧。"""
        # count 模式启动后只统计选中 target 的包，target_seq 变化或中间出现 unknown 都不提前收口。
        if target != self.collect_target:
            return
        self._append_target_packet(event, current_packet_index, collect_time_queue)

    def _has_pending_count_collect(self) -> bool:
        """判断是否存在尚未被设备真正接收的按包数采集请求。"""
        return bool(self.pending_collect_target) and self.pending_collect_packet_limit > 0

    def _is_count_collect_active(self) -> bool:
        """判断当前是否正处于按包数采集写盘阶段。"""
        return self.target_file is not None and self.collect_packet_limit > 0

    def _normalize_packet_index(self, packet_index) -> int:
        """把任意来源的包序号规范到当前有效范围内。"""
        try:
            normalized_packet_index = int(packet_index)
        except (TypeError, ValueError):
            normalized_packet_index = self.csi_event_count - 1

        if self.csi_event_count > 0:
            return max(0, min(normalized_packet_index, self.csi_event_count - 1))
        return max(normalized_packet_index, 0)

    def _write_keyframe_row(self, packet_index: int, remark: str) -> None:
        """向关键帧 CSV 追加一条记录。"""
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        self.keyframe_writer.writerow([created_at, packet_index, remark])
        self.keyframe_file.flush()

    @staticmethod
    def _read_csv_dict_rows(csv_path: Path) -> tuple[list[str], list[dict[str, str]]]:
        """以 DictReader 形式安全读取 CSV，并过滤空文件情况。"""
        if not csv_path.exists():
            return [], []
        csv_text = csv_path.read_text(encoding="utf-8-sig", errors="ignore").replace("\x00", "")
        if not csv_text.strip():
            return [], []
        reader = csv.DictReader(StringIO(csv_text))
        return reader.fieldnames or [], list(reader)

    @staticmethod
    def _safe_int(value) -> int:
        """把任意值稳妥转换成整数，失败时回退为 0。"""
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0

    def update_collect_config(self, target: str, packet_limit: int) -> None:
        """记录下一次按包数采集的目标标签与包数，用于精确收口采集边界。"""
        normalized_target = str(target).strip()
        try:
            normalized_limit = int(packet_limit)
        except (TypeError, ValueError):
            normalized_limit = 0

        self.suppress_segment_collection = False
        if not normalized_target or normalized_limit <= 0:
            self.pending_collect_target = ""
            self.pending_collect_packet_limit = 0
            return

        self.pending_collect_target = normalized_target
        self.pending_collect_packet_limit = normalized_limit

    def abort_collect(self, collect_time_queue) -> None:
        """用户显式停止采集时，结束当前采集文件并清空 count 模式等待状态。"""
        self.pending_collect_target = ""
        self.pending_collect_packet_limit = 0
        self.suppress_segment_collection = False
        if self.target_file is None:
            return

        end_packet_index = self.collect_start_packet_index
        if self.collect_packet_num > 0:
            end_packet_index = self.collect_start_packet_index + self.collect_packet_num - 1
        self._finish_target_file(collect_time_queue, end_packet_index=end_packet_index)

    @staticmethod
    def _queue_collect_event(collect_time_queue, payload: dict) -> None:
        """在队列未满时，把采集状态事件回推给主进程。"""
        if collect_time_queue is None or collect_time_queue.full():
            return
        collect_time_queue.put(payload)

    def close(self) -> None:
        """关闭当前录制器持有的全部文件句柄。"""
        self._close_target_file()
        self.csi_file.close()
        self.keyframe_file.close()
        self.log_file.close()


class SerialReaderThread(Thread):
    """读取串口原始字节流，并投递给解析线程。"""

    def __init__(self, serial_obj, raw_line_queue, app_queue) -> None:
        """保存串口句柄和跨线程通信队列。"""
        super().__init__(daemon=True)
        self.serial_obj = serial_obj
        self.raw_line_queue = raw_line_queue
        self.app_queue = app_queue
        self.is_running = True

    def run(self) -> None:
        """持续读取串口原始字节流，并投递给解析线程。"""
        while self.is_running:
            try:
                # 读取一整行串口输出，维持与设备日志行粒度一致。
                raw_bytes = self.serial_obj.readline()
            except Exception as exc:
                self.app_queue.put(
                    {
                        "type": "FAIL_EVENT",
                        "data": f"Failed to read serial data: {exc}",
                    }
                )
                break

            if raw_bytes:
                # 把字节流交给解析线程，IO 与解析各自独立，减少阻塞。
                self.raw_line_queue.put(raw_bytes)


class SerialParserThread(Thread):
    """把串口原始文本解析成供 UI 使用的结构化事件。"""

    log_regex = re.compile(r".*([DIWE]) \((\d+)\) (.*)", re.I)

    def __init__(self, raw_line_queue, app_queue, collect_time_queue, recorder: RuntimeDataRecorder) -> None:
        """保存原始行队列、UI 事件队列以及运行期录制器。"""
        super().__init__(daemon=True)
        self.raw_line_queue = raw_line_queue
        self.app_queue = app_queue
        self.collect_time_queue = collect_time_queue
        self.recorder = recorder
        self.is_running = True

    def run(self) -> None:
        """持续解析串口输出，并将结果拆分为 CSI 事件和普通日志。"""
        while self.is_running:
            try:
                # 解析线程按行消费串口原始输出。
                raw_bytes = self.raw_line_queue.get(timeout=0.2)
            except queue.Empty:
                continue

            # 先把串口原始字节标准化成可读文本，避免 NUL 和 ANSI 控制序列直接落盘。
            message = self._normalize_raw_message(raw_bytes)
            if not message:
                continue

            # 优先尝试解析 CSI 行，成功后直接写盘并推送给 UI。
            event = self._parse_csi_line(message)
            if event is not None:
                self.recorder.record_csi_event(event, self.collect_time_queue)
                if not self.app_queue.full():
                    self.app_queue.put(event)
                continue

            # 非 CSI 行按普通日志处理，并在可能时提取出等级和时间戳。
            self.recorder.record_log_line(message)
            log_match = self.log_regex.match(message)
            if log_match and not self.app_queue.full():
                self.app_queue.put(
                    {
                        "type": "LOG_DATA",
                        "tag": log_match.group(1),
                        "timestamp": log_match.group(2),
                        "data": log_match.group(3),
                    }
                )

    @staticmethod
    def _normalize_raw_message(raw_bytes: bytes) -> str:
        """将串口原始字节转换为适合解析和落盘的纯文本日志。"""
        # 参考旧版工具，日志落盘前先做文本化和控制序列清洗，避免 txt 文件混入二进制字节。
        message = raw_bytes.decode("utf-8", errors="ignore")
        if not message:
            return ""

        # 去掉设备日志中的 ANSI 颜色控制序列及其转义表示。
        message = ANSI_ESCAPE_PATTERN.sub("", message)
        message = ESCAPED_ANSI_ESCAPE_PATTERN.sub("", message)
        # NUL 字节和其他不可打印控制字符会让 txt 文件看起来像二进制，这里统一剔除。
        message = message.replace("\x00", "")
        message = "".join(char for char in message if char in "\r\n\t" or ord(char) >= 32)
        return message.strip()

    def _parse_csi_line(self, message: str) -> dict | None:
        """把一行包含 CSI_DATA 的文本解析为结构化 CSI 事件。"""
        # 只有包含 CSI_DATA 前缀的行才可能是有效 CSI 记录。
        index = message.find("CSI_DATA")
        if index < 0:
            return None

        line = message[index:]
        first_line_end = line.find("\n")
        if first_line_end >= 0:
            line = line[:first_line_end]
        line = line.rstrip("\r")

        reader = csv.reader(StringIO(line))
        try:
            data = next(reader)
        except StopIteration:
            return None

        # 列数不匹配说明该行不是完整的 CSI CSV。
        if len(data) != len(CSI_DATA_COLUMNS_NAMES):
            return None

        event = dict(zip(CSI_DATA_COLUMNS_NAMES, data))
        decoded_data = base64_decode_bin(event["data"])
        if not decoded_data:
            # base64 解码失败时直接丢弃本帧。
            return None

        try:
            expected_len = int(event["len"])
        except ValueError:
            return None
        # 解码后的数组长度必须与设备声明长度一致。
        if len(decoded_data) != expected_len:
            return None

        event["data"] = decoded_data
        # 补齐界面与处理链路需要的规范化字段。
        event["timestamp"] = self._normalize_timestamp(event["timestamp"])
        event["rssi"] = self._safe_int(event.get("rssi", 0))
        event["len"] = expected_len
        return event

    @staticmethod
    def _normalize_timestamp(value: str) -> str:
        """尽量保留设备时间戳；格式异常时退回当前本地时间。"""
        try:
            datetime.strptime(value, "%Y-%m-%d %H:%M:%S.%f")
            return value
        except ValueError:
            return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

    @staticmethod
    def _safe_int(value) -> int:
        """把任意值稳妥转换成整数，失败时回退为 0。"""
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0


def _write_serial_line(serial_obj, command: str) -> None:
    """向设备发送一条完整的 CRLF 结尾串口命令。"""
    # 设备串口命令统一以 CRLF 结尾，保持与手动串口工具一致。
    serial_obj.write(f"{command}\r\n".encode("utf-8"))


def run_serial_process(queue_read, queue_write, port: str, collect_time_queue, csi_output_type: str) -> None:
    """串口 IO 子进程入口。

    该子进程独占串口资源，并把串口读取、文本解析、运行期写盘和
    主进程命令处理整合到同一个隔离环境中，避免阻塞 Qt 主线程。
    """
    serial_obj = None
    reader_thread = None
    parser_thread = None
    recorder = None
    raw_line_queue = queue.Queue(maxsize=256)

    try:
        # 子进程独占串口连接，避免 Qt 主线程直接接触阻塞式 IO。
        serial_obj = serial.Serial(
            port=port,
            baudrate=SERIAL_BAUDRATE,
            bytesize=8,
            parity="N",
            stopbits=1,
            timeout=SERIAL_TIMEOUT,
        )
        serial_obj.flushInput()

        # 运行期录制器和两个线程分别负责写盘、读取、解析。
        recorder = RuntimeDataRecorder()
        reader_thread = SerialReaderThread(serial_obj, raw_line_queue, queue_read)
        parser_thread = SerialParserThread(raw_line_queue, queue_read, collect_time_queue, recorder)
        reader_thread.start()
        parser_thread.start()

        # 连接后先执行与现有工具一致的初始化指令序列。
        _write_serial_line(serial_obj, "restart")
        time.sleep(0.05)
        _write_serial_line(serial_obj, "ping --abort")
        _write_serial_line(serial_obj, "wifi_config --disconnect")
        time.sleep(3)
        _write_serial_line(
            serial_obj,
            f"radar --csi_output_type {csi_output_type or DEFAULT_CSI_OUTPUT_TYPE} --csi_output_format base64",
        )

        while True:
            try:
                # 主进程通过命令队列把用户操作转换为设备命令。
                command = queue_write.get(timeout=0.1)
            except queue.Empty:
                # 任一后台线程意外退出时，结束整个串口子进程。
                if not reader_thread.is_alive() or not parser_thread.is_alive():
                    break
                continue

            if isinstance(command, dict):
                if command.get("type") == "KEYFRAME_EVENT" and recorder is not None:
                    recorder.record_keyframe_event(command)
                elif command.get("type") == "COLLECT_CONFIG" and recorder is not None:
                    recorder.update_collect_config(
                        str(command.get("target", "")),
                        int(command.get("packet_limit", 0) or 0),
                    )
                elif command.get("type") == "COLLECT_ABORT" and recorder is not None:
                    recorder.abort_collect(collect_time_queue)
                elif command.get("type") == "DELETE_COLLECT_KEYFRAMES" and recorder is not None:
                    recorder.delete_collect_keyframes(command)
                continue

            if command == "exit":
                break

            _write_serial_line(serial_obj, command)

    except Exception as exc:
        queue_read.put({"type": "FAIL_EVENT", "data": f"Failed to open serial port: {exc}"})
    finally:
        # 无论正常退出还是异常退出，都尽量回收线程、串口和文件句柄。
        if reader_thread is not None:
            reader_thread.is_running = False
            reader_thread.join(timeout=1)
        if parser_thread is not None:
            parser_thread.is_running = False
            parser_thread.join(timeout=1)
        if serial_obj is not None and serial_obj.is_open:
            serial_obj.close()
        if recorder is not None:
            recorder.close()
