"""重构版 ESP-CSI 上位机主窗口编排逻辑。"""

from __future__ import annotations

import ast
import csv
import json
from io import StringIO
import queue
import sys
from datetime import datetime
from multiprocessing import Process, Queue
from pathlib import Path

import numpy as np
import pyqtgraph as pg
import serial.tools.list_ports
from PyQt5.QtCore import QPointF, QRectF, QSignalBlocker, Qt, QTimer
from PyQt5.QtGui import QColor, QPainter, QPen, QPixmap, QPolygonF, QTextCursor
from PyQt5.QtWidgets import (
    QApplication,
    QMainWindow,
    QMessageBox,
)

from core.constants import (
    COLLECT_DATA_ROOT,
    COLLECT_REMARK_FILE,
    CSI_BUFFER_SIZE,
    DEFAULT_CSI_OUTPUT_TYPE,
    DEFAULT_UNIT,
    DEFAULT_VALID_SUBCARRIERS,
    RUNTIME_LOG_ROOT,
)
from core.csi_processing import CsiBufferProcessor
from core.utils import append_csv_row
from drivers.serial_backend import run_serial_process
from drivers.speech import speak_text_async
from ui.generated.Ui_esp_csi_tool_gui import Ui_MainWindow
from ui.inference_worker_v2 import (
    DEFAULT_DECISION_WINDOW_SIZE,
    DEFAULT_FREEZE_FRAMES,
    DEFAULT_PROBABILITY_THRESHOLD,
    DEFAULT_RECOGNITION_COUNT_THRESHOLD,
    LstmInferenceWorker,
)
from ui.plot_controller import SubcarrierPlotController
from ui.ui_worker import UiEventBridge

DEFAULT_COLLECT_OPTIONS: dict[str, list[str]] = {
    "Crosswise": [
        "左手 手掌张开 掌心朝右 向左挥动",
        "左手 手掌张开 掌心朝右 向右挥动",
        "右手 手掌张开 掌心朝左 向左挥动",
        "右手 手掌张开 掌心朝左 向右挥动",
    ],
    "Lengthways": [
        "左手 手掌张开 掌心朝下 向上挥动",
        "左手 手掌张开 掌心朝下 向下挥动",
        "右手 手掌张开 掌心朝下 向上挥动",
        "右手 手掌张开 掌心朝下 向下挥动",
    ],
    "Grasp": [
        "左手 掌心朝前 张-合-张",
        "左手 掌心朝自己 张-合-张",
        "右手 掌心朝前 张-合-张",
        "右手 掌心朝自己 张-合-张",
    ],
    "Invalid": [
        "手自然放下 保持静止 身后无人",
        "左手 手掌张开 掌心朝右 保持静止 身后无人",
        "左手 手掌张开 掌心朝下 保持静止 身后无人",
        "左手 手掌张开 掌心朝前 保持静止 身后无人",
        "右手 手掌张开 掌心朝左 保持静止 身后无人",
        "右手 手掌张开 掌心朝下 保持静止 身后无人",
        "右手 手掌张开 掌心朝前 保持静止 身后无人",
        "从坐到站 身后无人",
        "从站到坐 身后无人",
        "左手从自然放下到抬起 身后无人",
        "左手 手掌张开 掌心朝下 向前伸出 身后无人",
        "左手 掌心朝前 张-合 身后无人",
        "右手从自然放下到抬起 身后无人",
        "右手 手掌张开 掌心朝下 向前伸出 身后无人",
        "右手 掌心朝前 张-合 身后无人",
    ],
}

AUTO_RECOGNITION_SPEECH_MAP: dict[str, str] = {
    "Up": "向上",
    "Down": "向下",
    "Left": "向左",
    "Right": "向右",
    "Push": "前推",
    "Pull": "后缩",
    "Clap": "拍手",
}
AUTO_RECOGNITION_INVALID_CLASS_ALIASES = {"invalid", "invaild"}
# 识别图示统一使用红色高对比度图形，便于在全屏界面中快速确认结果。
AUTO_RECOGNITION_ICON_COLOR = QColor(220, 32, 32)
LIVE_PLOT_INITIAL_Y_RANGE = np.array([0.0, 500.0], dtype=np.float64)
# 只需要改这里即可切换实时识别使用的 checkpoint，模型结构由 checkpoint 自动识别。
# 上位机代码已经迁移到 collect/PC，默认模型路径也随之切换。
COLLECT_PC_TOOL_RELATIVE_PATH = Path("collect") / "PC"
INFERENCE_MODEL_RELATIVE_PATH = COLLECT_PC_TOOL_RELATIVE_PATH / "model" / "best_model.pt"


class DataGraphicalWindow(QMainWindow, Ui_MainWindow):
    """ESP-CSI 主窗口编排层。

    该类不直接承担底层串口 IO，而是负责把界面控件、后台线程、
    数据处理器、采集文件和自动识别模块组织成一个完整工作流。
    """

    def __init__(self) -> None:
        """初始化界面状态、后台资源和各功能页控制器。"""
        super().__init__()
        self.setupUi(self)
        # 缓存当前最终识别类别，避免窗口初次缩放时还未初始化就触发重绘。
        self.auto_recognition_visual_class_name = ""
        # 记录仓库根目录，便于定位 runtime 默认导入路径。
        # 当前文件位于 collect/PC/ui，下钻三级即可回到仓库根目录。
        self.repo_root = Path(__file__).resolve().parents[3]
        # 统一缓存 PC 端上位机目录，后续配置、模型和采集输出都从这里派生。
        self.collect_pc_tool_root = self.repo_root / COLLECT_PC_TOOL_RELATIVE_PATH
        self.setWindowTitle("ESP-CSI Tool")

        # 串口连接与采集状态。
        self.serial_is_connected = False
        self.selected_port = ""
        self.collect_active = False
        self.collect_mode = ""
        self.collect_packet_limit = 0
        self.collect_packet_count = 0
        self.collect_session_target = ""
        self.collect_session_timestamp = ""
        self.pending_collect_remarks: list[dict[str, str]] = []
        self.collect_options_config_path = self.collect_pc_tool_root / "config" / "collect_options.json"
        self.collect_target_movement_map: dict[str, list[str]] = {}
        self.collect_target_order: list[str] = []

        # 实时图状态。
        self.valid_subcarriers = list(DEFAULT_VALID_SUBCARRIERS)
        self.latest_csi_waveform = np.zeros((CSI_BUFFER_SIZE, len(self.valid_subcarriers)), dtype=np.float64)
        self.pending_packet_count = 0
        self.total_csi_packets_received = 0
        self.pending_collect_keyframes: list[dict[str, object]] = []

        # 采集显示区状态。
        self.collect_display_path: Path | None = None
        self.collect_display_events: list[dict] = []
        self.collect_display_skipped_rows = 0
        self.collect_display_result: dict[str, object] | None = None
        self.collect_display_keyframe_csv_path: Path | None = None
        self.collect_display_history: list[dict[str, object]] = []
        self.collect_display_current_index = -1

        # 串口子进程资源。
        self.serial_queue_read = None
        self.serial_queue_write = None
        self.collect_time_queue = None
        self.serial_handle_process: Process | None = None

        # 数据处理与绘图控制器。
        self.processor = CsiBufferProcessor(valid_subcarriers=self.valid_subcarriers, display_unit=DEFAULT_UNIT)
        self.ui_data_thread = None
        self.plot_controller = SubcarrierPlotController(self.graphicsView_subcarrier)
        self.plot_controller.reset_subcarriers(self.valid_subcarriers, self.latest_csi_waveform)
        self._apply_live_plot_initial_y_range()
        self.collect_plot_controller = SubcarrierPlotController(
            self.graphicsView_collect_subcarrier,
            show_legend=False,
        )
        self.inference_model_path = self.repo_root / INFERENCE_MODEL_RELATIVE_PATH
        self.inference_worker: LstmInferenceWorker | None = None
        self.auto_recognition_available = self.inference_model_path.exists()
        self.auto_recognition_window_count = DEFAULT_DECISION_WINDOW_SIZE
        self.auto_recognition_probability_threshold = DEFAULT_PROBABILITY_THRESHOLD
        self.auto_recognition_count_threshold = DEFAULT_RECOGNITION_COUNT_THRESHOLD
        self.auto_recognition_freeze_frames = DEFAULT_FREEZE_FRAMES

        # 自动停止采集定时器。
        self.collect_stop_timer = QTimer(self)
        self.collect_stop_timer.setSingleShot(True)
        self.collect_stop_timer.timeout.connect(self.collect_stop_1)

        # 实时图刷新节奏。
        self.timer_curve_subcarrier = QTimer(self)
        self.timer_curve_subcarrier.setInterval(100)
        self.timer_curve_subcarrier.timeout.connect(self.show_curve_subcarrier)
        self.timer_curve_subcarrier.start()

        self._bind_signals()
        self._initialize_collect_options()
        self._apply_initial_view_state()
        self._initialize_inference_worker()
        self.showMaximized()

    def _initialize_collect_options(self) -> None:
        """加载采集页 target/movement 配置，并填充对应下拉框。"""
        self.collect_options_config_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.collect_options_config_path.exists():
            self.collect_options_config_path.write_text(
                json.dumps(DEFAULT_COLLECT_OPTIONS, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

        self.collect_target_movement_map = self._load_collect_options_config()
        self.collect_target_order = list(self.collect_target_movement_map.keys())

        with QSignalBlocker(self.comboBox_target_1):
            self.comboBox_target_1.clear()
            self.comboBox_target_1.addItems(self.collect_target_order)

        initial_target = self.collect_target_order[0] if self.collect_target_order else ""
        self._refresh_collect_movement_options(initial_target)

    def _load_collect_options_config(self) -> dict[str, list[str]]:
        """从 JSON 文件读取采集配置，失败时回退到内置默认值。"""
        try:
            raw_options = json.loads(self.collect_options_config_path.read_text(encoding="utf-8"))
            normalized_options = self._normalize_collect_options(raw_options)
            if normalized_options:
                return normalized_options
            raise ValueError("collect options config is empty")
        except Exception as exc:
            fallback_options = self._normalize_collect_options(DEFAULT_COLLECT_OPTIONS)
            self.show_textBrowser_log(
                (
                    "<font color='yellow'>W (collect-config) "
                    f"采集配置加载失败，已回退到默认配置：{exc}</font>"
                )
            )
            return fallback_options

    @staticmethod
    def _normalize_collect_options(raw_options: object) -> dict[str, list[str]]:
        """把不同结构的原始配置统一整理成 target -> movement 列表。"""
        normalized_options: dict[str, list[str]] = {}
        if not isinstance(raw_options, dict):
            return normalized_options

        for raw_target, raw_movements in raw_options.items():
            target = str(raw_target).strip()
            if not target:
                continue

            if isinstance(raw_movements, dict):
                movement_candidates = list(raw_movements.keys())
            elif isinstance(raw_movements, (list, tuple, set)):
                movement_candidates = list(raw_movements)
            elif raw_movements is None:
                movement_candidates = []
            else:
                movement_candidates = [raw_movements]

            movements: list[str] = []
            for raw_movement in movement_candidates:
                movement = str(raw_movement).strip()
                if movement and movement not in movements:
                    movements.append(movement)

            if not movements:
                movements.append("未配置动作细节")

            normalized_options[target] = movements

        return normalized_options

    def _refresh_collect_movement_options(
        self,
        target: str,
        preferred_movement: str | None = None,
    ) -> None:
        """根据当前 target 更新动作细节下拉框内容。"""
        movements = list(self.collect_target_movement_map.get(str(target).strip(), []))
        with QSignalBlocker(self.comboBox_movement_1):
            self.comboBox_movement_1.clear()
            self.comboBox_movement_1.addItems(movements)
            if movements:
                default_movement = (
                    preferred_movement if preferred_movement in movements else movements[0]
                )
                self.comboBox_movement_1.setCurrentText(default_movement)

    def handle_collect_target_changed(self, target: str) -> None:
        """当采集 target 改变时，同步刷新 movement 选项。"""
        self._refresh_collect_movement_options(target)

    def _bind_signals(self) -> None:
        """集中绑定当前仍在使用的界面控件与槽函数。"""
        self.pushButton_scan.clicked.connect(self.scan_serial_port)
        self.pushButton_connect.clicked.connect(self.serial_connect)
        self.pushButton_collect_start_1.clicked.connect(self.collect_start_1)
        self.pushButton_collect_stop_1.clicked.connect(self.collect_stop_1)
        self.pushButton_collect_previous.clicked.connect(self.show_previous_collect_display_sample)
        self.pushButton_collect_next.clicked.connect(self.show_next_collect_display_sample)
        self.pushButton_collect_clear.clicked.connect(self.clear_collect_display_sample)
        self.pushButton_collect_clear_all.clicked.connect(self.clear_collect_display_all_samples)
        self.comboBox_target_1.currentTextChanged.connect(self.handle_collect_target_changed)
        self.checkBox_lp_filter.toggled.connect(self.change_lp_filter_state)
        self.checkBox_auto_recognition.toggled.connect(self.change_auto_recognition_state)
        self.spinBox_auto_recognition_stride.valueChanged.connect(
            self.change_auto_recognition_stride
        )
        self.spinBox_auto_recognition_window_count.valueChanged.connect(
            self.change_auto_recognition_window_count
        )
        self.doubleSpinBox_auto_recognition_threshold.valueChanged.connect(
            self.change_auto_recognition_threshold
        )
        self.spinBox_auto_recognition_vote_threshold.valueChanged.connect(
            self.change_auto_recognition_vote_threshold
        )
        self.spinBox_auto_recognition_freeze_frames.valueChanged.connect(
            self.change_auto_recognition_freeze_frames
        )
        self.graphicsView_subcarrier.scene().sigMouseClicked.connect(self.add_keyframe_by_click)
        self.graphicsView_collect_subcarrier.plotItem.vb.setMouseMode(pg.ViewBox.PanMode)
        self.graphicsView_collect_subcarrier.setMouseEnabled(x=True, y=False)

    def _apply_initial_view_state(self) -> None:
        """设置窗口首次打开时的默认控件状态与空白图表。"""
        self.pushButton_collect_stop_1.setEnabled(False)
        self.pushButton_collect_clear.setEnabled(False)
        self.pushButton_collect_clear_all.setEnabled(False)
        self.checkBox_auto_recognition.setChecked(False)
        self.spinBox_auto_recognition_stride.setValue(10)
        self.spinBox_auto_recognition_window_count.setValue(
            self.auto_recognition_window_count
        )
        self.doubleSpinBox_auto_recognition_threshold.setValue(
            self.auto_recognition_probability_threshold
        )
        self.spinBox_auto_recognition_vote_threshold.setValue(
            self.auto_recognition_count_threshold
        )
        self.spinBox_auto_recognition_freeze_frames.setValue(
            self.auto_recognition_freeze_frames
        )
        self.spinBox_auto_recognition_stride.setEnabled(self.auto_recognition_available)
        self.spinBox_auto_recognition_window_count.setEnabled(self.auto_recognition_available)
        self.doubleSpinBox_auto_recognition_threshold.setEnabled(self.auto_recognition_available)
        self.spinBox_auto_recognition_vote_threshold.setEnabled(self.auto_recognition_available)
        self.spinBox_auto_recognition_freeze_frames.setEnabled(self.auto_recognition_available)
        self.checkBox_auto_recognition.setEnabled(self.auto_recognition_available)
        self._sync_auto_recognition_count_threshold_limit(
            self.spinBox_auto_recognition_window_count.value()
        )
        if self.auto_recognition_available:
            self.label_auto_recognition_result.setText("识别结果：未开启")
        else:
            self.label_auto_recognition_result.setText("识别结果：未找到模型")
        self._reset_auto_recognition_live_inference_labels()
        # 识别图示区保持白底，Invalid 与未识别时都显示为空白。
        self.label_auto_recognition_icon.setStyleSheet("background-color: white;")
        self.label_auto_recognition_icon.setAlignment(Qt.AlignCenter)
        self.label_auto_recognition_icon.setScaledContents(False)
        # 让图示控件在分组框中保持居中，避免随布局拉伸后偏向顶部。
        self.verticalLayout_auto_recognition_visual.setAlignment(
            self.label_auto_recognition_icon,
            Qt.AlignCenter,
        )
        self._set_auto_recognition_visual_class("")
        self.change_lp_filter_state(self.checkBox_lp_filter.isChecked())
        self.collect_plot_controller.load_static_dataset(
            self.valid_subcarriers,
            np.zeros((0, len(self.valid_subcarriers)), dtype=np.float64),
            [],
            1,
        )
        self._update_collect_display_navigation_state()

    def _initialize_inference_worker(self) -> None:
        """在存在模型文件时启动后台自动识别线程。"""
        if not self.auto_recognition_available:
            self.show_textBrowser_log(
                "<font color='yellow'>W (inference) 未找到模型文件，自动识别功能已禁用。</font>"
            )
            return

        self.inference_worker = LstmInferenceWorker(
            checkpoint_path=self.inference_model_path,
            stride=self.spinBox_auto_recognition_stride.value(),
            decision_window_size=self.auto_recognition_window_count,
            probability_threshold=self.auto_recognition_probability_threshold,
            recognition_count_threshold=self.auto_recognition_count_threshold,
            freeze_frames=self.auto_recognition_freeze_frames,
        )
        self.inference_worker.signal_inference.connect(self.update_auto_recognition_live_inference)
        self.inference_worker.signal_status.connect(self.update_auto_recognition_status)
        self.inference_worker.signal_result.connect(self.handle_auto_recognition_result)
        self.inference_worker.signal_error.connect(self.handle_auto_recognition_error)
        self.inference_worker.start()

    def resizeEvent(self, event) -> None:
        """窗口尺寸变化时，按当前最终识别结果重绘图示。"""
        super().resizeEvent(event)
        self._render_auto_recognition_visual()

    def _reset_auto_recognition_sequence(self) -> None:
        """通知识别线程清空当前滑动窗口序列。"""
        self._reset_auto_recognition_live_inference_labels()
        self._set_auto_recognition_visual_class("")
        if self.inference_worker is None:
            return
        self.inference_worker.reset_sequence()

    def _reset_auto_recognition_live_inference_labels(self) -> None:
        """清空实时识别推理展示标签。"""
        inference_text = "--"
        window_text = "--"
        self.label_auto_recognition_inference_result.setText(inference_text)
        self.label_auto_recognition_inference_result.setToolTip(inference_text)
        self.label_auto_recognition_window_results.setText(window_text)
        self.label_auto_recognition_window_results.setToolTip(window_text)

    def _apply_live_plot_initial_y_range(self) -> None:
        """显式设置“原始数据”页图表初始纵轴范围。"""
        self.plot_controller.curve_subcarrier_range = LIVE_PLOT_INITIAL_Y_RANGE.copy()
        self.graphicsView_subcarrier.setYRange(
            LIVE_PLOT_INITIAL_Y_RANGE[0],
            LIVE_PLOT_INITIAL_Y_RANGE[1],
        )

    @staticmethod
    def _normalize_auto_recognition_visual_key(class_name: str) -> str:
        """把类别名归一化为图示键，便于统一绘制方向箭头或圆圈。"""
        normalized_class_name = str(class_name).strip().casefold()
        if not normalized_class_name:
            return ""
        if normalized_class_name in AUTO_RECOGNITION_INVALID_CLASS_ALIASES:
            return ""
        alias_map = {
            "left": "left",
            "right": "right",
            "up": "up",
            "down": "down",
            "push": "push",
            "pull": "pull",
            "clap": "clap",
        }
        return alias_map.get(normalized_class_name, "")

    def _set_auto_recognition_visual_class(self, class_name: str) -> None:
        """缓存最终识别类别，并立即刷新右侧识别图示。"""
        self.auto_recognition_visual_class_name = str(class_name).strip()
        self._render_auto_recognition_visual()

    def _render_auto_recognition_visual(self) -> None:
        """根据最终识别类别绘制红色箭头、圆圈或空白图示。"""
        if not hasattr(self, "label_auto_recognition_icon"):
            return

        visual_key = self._normalize_auto_recognition_visual_key(
            self.auto_recognition_visual_class_name
        )
        if not visual_key:
            self.label_auto_recognition_icon.clear()
            return

        width = max(self.label_auto_recognition_icon.width(), 360)
        height = max(self.label_auto_recognition_icon.height(), 260)
        pixmap = QPixmap(width, height)
        pixmap.fill(Qt.white)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)

        pen = QPen(AUTO_RECOGNITION_ICON_COLOR)
        pen.setWidth(max(10, min(width, height) // 24))
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        painter.setBrush(AUTO_RECOGNITION_ICON_COLOR)

        # 图示区域只保留纯图形，不再额外叠加任何说明文字。
        symbol_rect = QRectF(width * 0.10, height * 0.10, width * 0.80, height * 0.80)

        if visual_key in {"left", "right", "up", "down"}:
            painter.drawPolygon(self._build_arrow_polygon(visual_key, symbol_rect))
        elif visual_key == "clap":
            painter.setBrush(Qt.NoBrush)
            painter.drawEllipse(symbol_rect.adjusted(12, 12, -12, -12))
        elif visual_key in {"push", "pull"}:
            arrow_direction = "up" if visual_key == "push" else "down"
            painter.drawPolygon(self._build_arrow_polygon(arrow_direction, symbol_rect))

        painter.end()
        self.label_auto_recognition_icon.setPixmap(pixmap)

    @staticmethod
    def _build_arrow_polygon(direction: str, rect: QRectF) -> QPolygonF:
        """按给定方向构造一个饱满的实心箭头轮廓。"""
        left = rect.left()
        top = rect.top()
        right = rect.right()
        bottom = rect.bottom()
        center_x = rect.center().x()
        center_y = rect.center().y()
        body_left = left + rect.width() * 0.34
        body_right = right - rect.width() * 0.18
        body_top = top + rect.height() * 0.34
        body_bottom = bottom - rect.height() * 0.34

        if direction == "left":
            points = [
                QPointF(left, center_y),
                QPointF(body_left, top),
                QPointF(body_left, body_top),
                QPointF(body_right, body_top),
                QPointF(body_right, body_bottom),
                QPointF(body_left, body_bottom),
                QPointF(body_left, bottom),
            ]
        elif direction == "right":
            points = [
                QPointF(right, center_y),
                QPointF(body_right, top),
                QPointF(body_right, body_top),
                QPointF(body_left, body_top),
                QPointF(body_left, body_bottom),
                QPointF(body_right, body_bottom),
                QPointF(body_right, bottom),
            ]
        elif direction == "up":
            points = [
                QPointF(center_x, top),
                QPointF(right, body_top),
                QPointF(center_x + rect.width() * 0.14, body_top),
                QPointF(center_x + rect.width() * 0.14, bottom),
                QPointF(center_x - rect.width() * 0.14, bottom),
                QPointF(center_x - rect.width() * 0.14, body_top),
                QPointF(left, body_top),
            ]
        else:
            points = [
                QPointF(center_x, bottom),
                QPointF(right, body_bottom),
                QPointF(center_x + rect.width() * 0.14, body_bottom),
                QPointF(center_x + rect.width() * 0.14, top),
                QPointF(center_x - rect.width() * 0.14, top),
                QPointF(center_x - rect.width() * 0.14, body_bottom),
                QPointF(left, body_bottom),
            ]
        return QPolygonF(points)

    def _sync_auto_recognition_count_threshold_limit(self, window_count: int) -> None:
        """确保“识别个数阈值”不会超过“滑窗计数”。"""
        limit = max(1, int(window_count))
        with QSignalBlocker(self.spinBox_auto_recognition_vote_threshold):
            self.spinBox_auto_recognition_vote_threshold.setMaximum(limit)
            if self.spinBox_auto_recognition_vote_threshold.value() > limit:
                self.spinBox_auto_recognition_vote_threshold.setValue(limit)

    @staticmethod
    def _format_live_window_results(window_results: object) -> str:
        """把滑窗内每次模型推理结果整理成“类别=概率”的紧凑字符串。"""
        if not isinstance(window_results, list) or not window_results:
            return "--"

        result_parts: list[str] = []
        for item in window_results:
            if not isinstance(item, dict):
                continue
            class_name = str(item.get("class_name", "")).strip()
            if not class_name:
                continue
            probability_text = DataGraphicalWindow._format_probability_percentage(
                item.get("probability", 0.0)
            )
            result_parts.append(f"{class_name}={probability_text}")
        return "\n".join(result_parts) if result_parts else "--"

    @staticmethod
    def _format_live_window_counts(
        window_results: object,
        window_queue_length: int,
        decision_window_size: int,
    ) -> str:
        """逐行展示滑窗内每一次推理的类别和概率。"""
        lines = [f"当前滑窗：{window_queue_length}/{decision_window_size}"]
        if isinstance(window_results, list):
            result_lines = []
            for index, item in enumerate(window_results, start=1):
                if not isinstance(item, dict):
                    continue
                class_name = str(item.get("class_name", "")).strip()
                if not class_name:
                    continue
                probability_text = DataGraphicalWindow._format_probability_percentage(
                    item.get("probability", 0.0)
                )
                result_lines.append(f"{index}. {class_name}：{probability_text}")
            if result_lines:
                lines.extend(result_lines)
            else:
                lines.append("暂无结果")
        else:
            lines.append("暂无结果")
        return "\n".join(lines)

    @staticmethod
    def _format_probability_percentage(probability: object) -> str:
        """把概率格式化为 xx.xx%，不足两位整数时使用 0 补齐。"""
        probability_value = float(probability)
        return f"{probability_value * 100:05.2f}%"

    def update_auto_recognition_live_inference(self, result: dict[str, object]) -> None:
        """显示当前推理类别，以及滑窗内全部推理结果。"""
        model_class_name = str(result.get("raw_class_name", "unknown"))
        raw_probability = float(result.get("raw_probability", 0.0))
        counted_class_name = str(result.get("counted_class_name", "")).strip()
        window_queue_length = int(result.get("window_queue_length", 0))
        decision_window_size = int(
            result.get("decision_window_size", self.auto_recognition_window_count)
        )
        is_frozen = bool(result.get("is_frozen", False))
        window_text = self._format_live_window_counts(
            result.get("window_results", []),
            window_queue_length,
            decision_window_size,
        )

        if is_frozen:
            status_text = "冻结中"
        elif counted_class_name:
            status_text = f"计数[{counted_class_name}]"
        else:
            status_text = "不计数"

        inference_text = (
            f"类别：{model_class_name}\n"
            f"概率：{self._format_probability_percentage(raw_probability)}\n"
            f"状态：{status_text}"
        )

        self.label_auto_recognition_inference_result.setText(inference_text)
        self.label_auto_recognition_inference_result.setToolTip(inference_text)
        self.label_auto_recognition_window_results.setText(window_text)
        self.label_auto_recognition_window_results.setToolTip(window_text)

    def update_auto_recognition_status(self, text: str) -> None:
        """刷新自动识别状态标签及其悬浮提示。"""
        self.label_auto_recognition_result.setText(text)
        self.label_auto_recognition_result.setToolTip(text)

    def handle_auto_recognition_result(self, result: dict[str, object]) -> None:
        """接收识别结果，并把概率信息整理成界面可读文本。"""
        class_name = str(result.get("class_name", "unknown"))
        probability = float(result.get("probability", 0.0))
        raw_class_name = str(
            result.get("raw_class_name", result.get("model_output_class_name", class_name))
        )
        raw_probability = float(result.get("raw_probability", probability))
        probability_threshold = float(
            result.get(
                "probability_threshold",
                self.auto_recognition_probability_threshold,
            )
        )
        window_size = int(
            result.get("decision_window_size", self.auto_recognition_window_count)
        )
        recognition_count_threshold = int(
            result.get(
                "recognition_count_threshold",
                self.auto_recognition_count_threshold,
            )
        )
        trigger_count = int(result.get("trigger_count", 0))
        freeze_frames = int(
            result.get("freeze_frames", self.auto_recognition_freeze_frames)
        )
        window_results = result.get("window_results", [])

        if class_name.casefold() in AUTO_RECOGNITION_INVALID_CLASS_ALIASES:
            text = (
                f"识别结果：Invalid "
                f"({trigger_count}/{max(recognition_count_threshold, 1)})"
            )
        else:
            text = (
                f"识别结果：{class_name} "
                f"({trigger_count}/{max(recognition_count_threshold, 1)}, "
                f"{self._format_probability_percentage(probability)})"
            )
        self.label_auto_recognition_result.setText(text)
        self._set_auto_recognition_visual_class(class_name)
        self._speak_auto_recognition_result(class_name)
        tooltip_lines = [
            text,
            "",
            f"滑窗计数：{window_size}",
            f"概率阈值：{self._format_probability_percentage(probability_threshold)}",
            f"识别个数阈值：{recognition_count_threshold}",
            f"冻结帧：{freeze_frames}",
            f"本次触发计数：{trigger_count}",
            f"当前模型输出：{raw_class_name} "
            f"({self._format_probability_percentage(raw_probability)})",
            "",
            f"滑窗结果：{self._format_live_window_results(window_results)}",
        ]
        self.label_auto_recognition_result.setToolTip("\n".join(tooltip_lines))

    def _speak_auto_recognition_result(self, class_name: str) -> None:
        """播报最终识别结果，Invalid 不播报。"""
        normalized_class_name = str(class_name).strip()
        if not normalized_class_name:
            return
        if normalized_class_name.casefold() in AUTO_RECOGNITION_INVALID_CLASS_ALIASES:
            return
        speak_text_async(
            AUTO_RECOGNITION_SPEECH_MAP.get(normalized_class_name, normalized_class_name)
        )

    def handle_auto_recognition_error(self, message: str) -> None:
        """处理自动识别线程抛出的异常，并在必要时禁用识别功能。"""
        self.label_auto_recognition_result.setText(f"识别结果：{message}")
        self.label_auto_recognition_result.setToolTip(message)
        self._reset_auto_recognition_live_inference_labels()
        self._set_auto_recognition_visual_class("")
        if "模型" in message or "checkpoint" in message.lower():
            self.checkBox_auto_recognition.setChecked(False)
            self.checkBox_auto_recognition.setEnabled(False)
            self.spinBox_auto_recognition_stride.setEnabled(False)
            self.spinBox_auto_recognition_window_count.setEnabled(False)
            self.doubleSpinBox_auto_recognition_threshold.setEnabled(False)
            self.spinBox_auto_recognition_vote_threshold.setEnabled(False)
            self.spinBox_auto_recognition_freeze_frames.setEnabled(False)
        self.show_textBrowser_log(
            f"<font color='yellow'>W (inference) {message}</font>"
        )

    def reset_live_csi_view(self) -> None:
        """重新连接串口前，清空实时图表、关键帧和滚动缓冲。"""
        self.reset_live_csi_runtime_state()
        self.latest_csi_waveform = np.array(
            self.processor.set_valid_subcarriers(self.valid_subcarriers),
            copy=True,
        )
        self.plot_controller.clear_keyframes()
        self.plot_controller.reset_subcarriers(self.valid_subcarriers, self.latest_csi_waveform)
        self._apply_live_plot_initial_y_range()

    def reset_live_csi_runtime_state(self) -> None:
        """断开串口时仅重置运行态计数，保留界面上的最后一帧波形。"""
        self.collect_packet_count = 0
        self.collect_session_timestamp = ""
        self.pending_packet_count = 0
        self.total_csi_packets_received = 0
        self.pending_collect_keyframes.clear()
        self._reset_auto_recognition_sequence()

    def reset_collect_display_history(self) -> None:
        """重新连接串口时，清空当前连接会话中的采集样本计数与展示图表。"""
        self.collect_display_history = []
        self._clear_collect_display_state()

    def scan_serial_port(self) -> None:
        """扫描当前系统中的可用串口并刷新下拉框。"""
        self.comboBox_serial_device.clear()
        ports = list(serial.tools.list_ports.comports())
        if not ports:
            QMessageBox.warning(self, "提示", "未检测到可用串口。")
            return
        for port in ports:
            self.comboBox_serial_device.addItem(port.device)

    def serial_connect(self) -> None:
        """连接或断开串口，并维护对应的后台子进程。"""
        if not self.serial_is_connected:
            self.selected_port = self.comboBox_serial_device.currentText().strip()
            if not self.selected_port:
                QMessageBox.warning(self, "提示", "请先扫描并选择串口。")
                return

            self.clear_textBrowser_log()
            self.reset_live_csi_view()
            self.reset_collect_display_history()
            self._ensure_process_channels()
            self._start_ui_bridge()
            self.serial_handle_process = Process(
                target=run_serial_process,
                args=(
                    self.serial_queue_read,
                    self.serial_queue_write,
                    self.selected_port,
                    self.collect_time_queue,
                    DEFAULT_CSI_OUTPUT_TYPE,
                ),
            )
            self.serial_handle_process.daemon = True
            self.serial_handle_process.start()

            self.serial_is_connected = True
            self.pushButton_scan.setEnabled(False)
            self.pushButton_connect.setText("断开")
            return

        self.disconnect_serial()

    def disconnect_serial(self) -> None:
        """主动断开串口连接，并回收相关子进程与线程资源。"""
        self._drain_collect_metadata()
        self.collect_stop_timer.stop()
        self.collect_active = False
        self.collect_mode = ""
        self.collect_packet_limit = 0
        self.collect_packet_count = 0
        self.collect_session_target = ""
        self.collect_session_timestamp = ""
        self.pending_collect_remarks.clear()

        if self.serial_handle_process is not None and self.serial_handle_process.is_alive():
            try:
                self.serial_queue_write.put("restart")
                self.serial_queue_write.put("exit")
            except Exception:
                pass
            self.serial_handle_process.join(timeout=2)
            if self.serial_handle_process.is_alive():
                self.serial_handle_process.terminate()
                self.serial_handle_process.join(timeout=2)

        self.serial_handle_process = None
        self._stop_ui_bridge()
        self.serial_queue_read = None
        self.serial_queue_write = None
        self.collect_time_queue = None
        self.serial_is_connected = False
        self.pushButton_scan.setEnabled(True)
        self.pushButton_connect.setText("连接")
        self.pushButton_collect_start_1.setEnabled(True)
        self.pushButton_collect_stop_1.setEnabled(False)
        self.reset_live_csi_runtime_state()

    def collect_start_1(self) -> None:
        """启动一次采集任务，并根据模式配置 count/time 收口策略。"""
        if not self.serial_is_connected:
            QMessageBox.warning(self, "提示", "请先连接串口。")
            return

        self._drain_collect_metadata()
        target = self.comboBox_target_1.currentText().strip()
        if not target:
            QMessageBox.warning(self, "提示", "请先填写采集标签。")
            return

        self.collect_packet_count = 0
        self.collect_active = True
        self.collect_session_target = target
        self.collect_session_timestamp = ""

        if self.radioButton_collect_csi_num_1.isChecked():
            self.collect_mode = "count"
            self.collect_packet_limit = self.spinBox_collect_csi_num_1.value()
            self.command_collect_csi_num(target, self.collect_packet_limit)
        else:
            self.collect_mode = "time"
            self.collect_packet_limit = 0
            self.command_change_target(target)
            self.collect_stop_timer.start(self.spinBox_collect_time_1.value())

        self.pushButton_collect_start_1.setEnabled(False)
        self.pushButton_collect_stop_1.setEnabled(True)

    def collect_stop_1(self) -> None:
        """手动停止当前采集任务。"""
        if not self.serial_is_connected:
            QMessageBox.warning(self, "提示", "请先连接串口。")
            return

        self._drain_collect_metadata()
        self._finish_collect_session(issue_stop_command=True)

    def _finish_collect_session(
        self,
        issue_stop_command: bool,
        collect_result: dict[str, object] | None = None,
    ) -> None:
        """统一收口采集状态，并在样本落盘后写入 remark。"""
        remark_payload = {
            "target": self.collect_session_target or self.comboBox_target_1.currentText(),
            "people": self.comboBox_people_1.currentText(),
            "location": self.comboBox_location_1.currentText(),
            "device": self.comboBox_device_1.currentText(),
            "movement": self.comboBox_movement_1.currentText(),
        }

        self.collect_stop_timer.stop()
        self.collect_active = False
        self.collect_mode = ""
        self.collect_packet_limit = 0
        self.collect_packet_count = 0

        if issue_stop_command:
            self.command_change_target("unknown")

        self.pushButton_collect_start_1.setEnabled(True)
        self.pushButton_collect_stop_1.setEnabled(False)

        if collect_result is None:
            self.pending_collect_remarks.append(remark_payload)
            return

        self._write_collect_remark(remark_payload, collect_result)
        self.announce_collect_completion()

    def announce_collect_completion(self) -> None:
        """采集样本成功写入后，播报当前连接会话内累计的样本数。"""
        sample_count = len(self.collect_display_history)
        if sample_count <= 0:
            return
        speak_text_async(f"{sample_count}")

    @staticmethod
    def _build_collect_boundary_remark(target: str, phase: str) -> str:
        """构造采集开始/结束关键帧的备注文本。"""
        normalized_target = str(target).strip() or "unknown"
        phase_text = "开始" if phase == "start" else "结束"
        return f"采集 {normalized_target} {phase_text}"

    @staticmethod
    def _is_collect_start_remark(remark: str) -> bool:
        """判断关键帧备注是否表示采集开始。"""
        normalized_remark = str(remark).strip()
        return normalized_remark == "采集开始" or (
            normalized_remark.startswith("采集 ") and normalized_remark.endswith(" 开始")
        )

    @staticmethod
    def _is_collect_end_remark(remark: str) -> bool:
        """判断关键帧备注是否表示采集结束。"""
        normalized_remark = str(remark).strip()
        return normalized_remark == "采集结束" or (
            normalized_remark.startswith("采集 ") and normalized_remark.endswith(" 结束")
        )

    def _drain_collect_metadata(self) -> None:
        """把串口子进程回传的采集元数据同步到主窗口状态。"""
        if self.collect_time_queue is None:
            return

        while True:
            try:
                item = self.collect_time_queue.get_nowait()
            except queue.Empty:
                return

            if isinstance(item, str):
                self.collect_session_timestamp = item
                continue

            if not isinstance(item, dict):
                continue

            item_type = str(item.get("type", ""))
            if item_type == "COLLECT_START":
                start_target = str(item.get("target", self.collect_session_target or self.comboBox_target_1.currentText()))
                self.collect_session_target = start_target
                self.collect_session_timestamp = str(
                    item.get("timestamp")
                    or datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3]
                )
                self.queue_collect_keyframe(
                    item.get("start_packet_index"),
                    self._build_collect_boundary_remark(start_target, "start"),
                )
                continue

            if item_type != "COLLECT_RESULT":
                continue

            timestamp = str(
                item.get("timestamp")
                or self.collect_session_timestamp
                or datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3]
            )
            target = str(item.get("target", self.collect_session_target or self.comboBox_target_1.currentText()))
            try:
                num = int(item.get("num", 0))
            except (TypeError, ValueError):
                num = 0
            start_packet_index = self._coerce_int(item.get("start_packet_index"))
            end_packet_index = self._coerce_int(item.get("end_packet_index"))
            self.queue_collect_keyframe(
                item.get("end_packet_index"),
                self._build_collect_boundary_remark(target, "end"),
            )
            collect_result = {
                "timestamp": timestamp,
                "target": target,
                "num": num,
            }
            if start_packet_index is not None:
                collect_result["start_packet_index"] = start_packet_index
            if end_packet_index is not None:
                collect_result["end_packet_index"] = end_packet_index
            keyframe_csv_path = str(item.get("keyframe_csv_path", "")).strip()
            if keyframe_csv_path:
                collect_result["keyframe_csv_path"] = keyframe_csv_path
            self.load_collect_display_from_result(collect_result)

            if self.collect_active and self.collect_mode == "count" and target == self.collect_session_target:
                self._finish_collect_session(issue_stop_command=True, collect_result=collect_result)
                continue

            if self.pending_collect_remarks:
                remark_payload = self.pending_collect_remarks.pop(0)
                self._write_collect_remark(remark_payload, collect_result)
                self.announce_collect_completion()

    def _write_collect_remark(
        self,
        remark_payload: dict[str, str],
        collect_result: dict[str, object],
    ) -> None:
        """把一次样本采集的备注信息追加到 remark.csv。"""
        self._ensure_collect_remark_schema()
        timestamp = str(
            collect_result.get("timestamp")
            or self.collect_session_timestamp
            or datetime.now().strftime("%Y-%m-%d_%H-%M-%S-%f")[:-3]
        )
        try:
            num = int(collect_result.get("num", 0))
        except (TypeError, ValueError):
            num = 0

        append_csv_row(
            COLLECT_REMARK_FILE,
            ["timestamp", "num", "target", "people", "location", "device", "movement"],
            [
                timestamp,
                num,
                remark_payload.get("target", ""),
                remark_payload.get("people", ""),
                remark_payload.get("location", ""),
                remark_payload.get("device", ""),
                remark_payload.get("movement", ""),
            ],
        )

    def _ensure_collect_remark_schema(self) -> None:
        """兼容旧版 remark.csv 表头，必要时迁移到当前字段结构。"""
        remark_path = Path(COLLECT_REMARK_FILE)
        if not remark_path.exists():
            return

        with remark_path.open("r", newline="", encoding="utf-8") as file_obj:
            rows = list(csv.reader(file_obj))
        if not rows:
            return

        expected_header = ["timestamp", "num", "target", "people", "location", "device", "movement"]
        current_header = rows[0]
        if current_header == expected_header:
            return

        migrated_rows = [expected_header]
        if current_header == ["timestamp", "num", "target", "people", "location", "note"]:
            for row in rows[1:]:
                migrated_rows.append(
                    [
                        row[0] if len(row) > 0 else "",
                        row[1] if len(row) > 1 else "",
                        row[2] if len(row) > 2 else "",
                        row[3] if len(row) > 3 else "",
                        row[4] if len(row) > 4 else "",
                        "",
                        row[5] if len(row) > 5 else "",
                    ]
                )
        elif current_header == ["timestamp", "target", "people", "location", "note"]:
            for row in rows[1:]:
                migrated_rows.append(
                    [
                        row[0] if len(row) > 0 else "",
                        "",
                        row[1] if len(row) > 1 else "",
                        row[2] if len(row) > 2 else "",
                        row[3] if len(row) > 3 else "",
                        "",
                        row[4] if len(row) > 4 else "",
                    ]
                )
        else:
            return

        with remark_path.open("w", newline="", encoding="utf-8") as file_obj:
            writer = csv.writer(file_obj)
            writer.writerows(migrated_rows)

    def clear_textBrowser_log(self) -> None:
        """清空左侧串口日志显示区。"""
        self.textBrowser_log.clear()

    def show_textBrowser_log(self, log_html: str) -> None:
        """向日志显示区追加一条 HTML 格式日志。"""
        self.textBrowser_log.append(log_html)
        self.textBrowser_log.moveCursor(QTextCursor.End)

    def change_lp_filter_state(self, enabled: bool) -> None:
        """切换实时页低通滤波开关，并重算当前波形。"""
        if self.ui_data_thread is not None:
            self.ui_data_thread.set_filter_enabled(enabled)
        else:
            self.latest_csi_waveform = np.array(
                self.processor.set_filter_enabled(enabled),
                copy=True,
            )
        if self.collect_display_path is not None:
            self.render_collect_display()

    def change_auto_recognition_state(self, enabled: bool) -> None:
        """开启或关闭自动识别功能。"""
        if not self.auto_recognition_available or self.inference_worker is None:
            text = "识别结果：未找到模型"
            self.label_auto_recognition_result.setText(text)
            self.label_auto_recognition_result.setToolTip(text)
            self._reset_auto_recognition_live_inference_labels()
            self._set_auto_recognition_visual_class("")
            return

        self._reset_auto_recognition_live_inference_labels()
        self._set_auto_recognition_visual_class("")
        self.inference_worker.set_enabled(enabled)
        if enabled:
            text = "识别结果：等待数据..."
        else:
            text = "识别结果：未开启"
        self.label_auto_recognition_result.setText(text)
        self.label_auto_recognition_result.setToolTip(text)

    def change_auto_recognition_stride(self, stride: int) -> None:
        """把新的识别步长同步给后台识别线程。"""
        if self.inference_worker is not None:
            self.inference_worker.set_stride(stride)

    def change_auto_recognition_window_count(self, window_count: int) -> None:
        """把新的滑窗计数同步给后台识别线程。"""
        self.auto_recognition_window_count = int(window_count)
        self._sync_auto_recognition_count_threshold_limit(self.auto_recognition_window_count)
        self.auto_recognition_count_threshold = int(
            self.spinBox_auto_recognition_vote_threshold.value()
        )
        if self.inference_worker is not None:
            self.inference_worker.set_decision_window_size(self.auto_recognition_window_count)
            self.inference_worker.set_recognition_count_threshold(
                self.auto_recognition_count_threshold
            )

    def change_auto_recognition_threshold(self, threshold: float) -> None:
        """把新的概率阈值同步给后台识别线程。"""
        self.auto_recognition_probability_threshold = float(threshold)
        if self.inference_worker is not None:
            self.inference_worker.set_probability_threshold(
                self.auto_recognition_probability_threshold
            )

    def change_auto_recognition_vote_threshold(self, threshold: int) -> None:
        """把新的识别个数阈值同步给后台识别线程。"""
        self.auto_recognition_count_threshold = int(threshold)
        if self.inference_worker is not None:
            self.inference_worker.set_recognition_count_threshold(
                self.auto_recognition_count_threshold
            )

    def change_auto_recognition_freeze_frames(self, freeze_frames: int) -> None:
        """把新的冻结帧数同步给后台识别线程。"""
        self.auto_recognition_freeze_frames = int(freeze_frames)
        if self.inference_worker is not None:
            self.inference_worker.set_freeze_frames(self.auto_recognition_freeze_frames)

    def update_csi_subcarrier_data(self, csi_data, packet_delta: int) -> None:
        """接收后台线程回推的最新实时波形数据。"""
        self.latest_csi_waveform = np.array(csi_data, copy=True)
        self.pending_packet_count += packet_delta
        self.total_csi_packets_received += packet_delta
        self._drain_collect_metadata()

    def handle_live_csi_frame(self, event: dict[str, object]) -> None:
        """把实时 CSI 帧转交给自动识别线程。"""
        if self.inference_worker is None or not self.checkBox_auto_recognition.isChecked():
            return
        self.inference_worker.enqueue_csi_frame(event)

    def show_curve_subcarrier(self) -> None:
        """按定时器节奏刷新实时波形与待绘制关键帧。"""
        self._drain_collect_metadata()
        self.plot_controller.render(self.latest_csi_waveform, self.pending_packet_count)
        self.pending_packet_count = 0
        self.render_pending_collect_keyframes()

    def add_keyframe_by_click(self, event) -> None:
        """允许用户在实时图上手动点击打关键帧。"""
        # 仅在实时接收 CSI 数据时，允许在“原始数据”页打关键帧。
        if not self.serial_is_connected or self.total_csi_packets_received <= 0:
            return

        pos = event.scenePos()
        if self.graphicsView_subcarrier.sceneBoundingRect().contains(pos):
            mouse_point = self.graphicsView_subcarrier.plotItem.vb.mapSceneToView(pos)
            display_x = int(mouse_point.x())
            self.plot_controller.add_keyframe(display_x, "手动标记")
            self.persist_live_keyframe(display_x, "手动标记")

    def persist_live_keyframe(
        self,
        display_x: int,
        remark: str,
        packet_index: int | None = None,
    ) -> None:
        """把界面上新增的关键帧持久化到 runtime 目录。"""
        if packet_index is None:
            packet_index = self.plot_controller.live_packet_index_from_x(
                display_x,
                self.total_csi_packets_received,
            )
        if packet_index is None or not self.serial_is_connected or self.serial_queue_write is None:
            return

        try:
            self.serial_queue_write.put(
                {
                    "type": "KEYFRAME_EVENT",
                    "packet_index": packet_index,
                    "display_x": display_x,
                    "remark": remark,
                }
            )
        except Exception:
            pass

    def queue_collect_keyframe(self, packet_index: object, remark: str) -> None:
        """缓存记录器回传的采集边界关键帧，等待实时图刷新到对应位置后再绘制。"""
        try:
            normalized_packet_index = int(packet_index)
        except (TypeError, ValueError):
            return
        if normalized_packet_index < 0:
            return
        self.pending_collect_keyframes.append(
            {
                "packet_index": normalized_packet_index,
                "remark": remark,
                # 允许在“关键帧事件先到、对应 CSI 包后到”时先画一个最右侧占位线。
                "placeholder_drawn": False,
            }
        )

    def render_pending_collect_keyframes(self) -> None:
        """把已确认落盘边界的关键帧映射到当前实时滚动图坐标系中。"""
        if not self.pending_collect_keyframes or self.total_csi_packets_received <= 0:
            return

        remaining_keyframes: list[dict[str, object]] = []
        for item in self.pending_collect_keyframes:
            packet_index = int(item["packet_index"])
            # 关键帧元数据与实时 CSI 数据走的是两条异步链路：
            # 当 packet_index 恰好等于当前已接收包数时，说明关键帧已经到了，
            # 但对应的那一帧 CSI 还没真正推进到动态图上。此时先在最右侧补一条占位线，
            # 避免用户在采集瞬间完全看不到开始/结束边界。
            if packet_index > self.total_csi_packets_received:
                remaining_keyframes.append(item)
                continue

            if packet_index == self.total_csi_packets_received:
                if not bool(item.get("placeholder_drawn", False)):
                    self.plot_controller.add_keyframe(CSI_BUFFER_SIZE, str(item["remark"]))
                    item["placeholder_drawn"] = True
                remaining_keyframes.append(item)
                continue

            display_x = packet_index - self.total_csi_packets_received + CSI_BUFFER_SIZE
            if bool(item.get("placeholder_drawn", False)):
                # 占位线已经画过，后续只需等实时滚动把它带到正确位置即可。
                continue

            if 0 <= display_x <= CSI_BUFFER_SIZE:
                self.plot_controller.add_keyframe(display_x, str(item["remark"]))

        self.pending_collect_keyframes = remaining_keyframes

    def load_csi_events_from_csv(self, csi_csv_path: Path) -> tuple[list[dict], int]:
        """从样本或 runtime CSV 中解析出标准化 CSI 事件列表。"""
        imported_events: list[dict] = []
        skipped_rows = 0
        with csi_csv_path.open("r", newline="", encoding="utf-8") as file_obj:
            reader = csv.DictReader(file_obj)
            for row in reader:
                try:
                    raw_values = ast.literal_eval(row["data"])
                    if not isinstance(raw_values, list):
                        raise ValueError("CSI data field is not a list.")
                    imported_events.append(
                        {
                            "data": [int(value) for value in raw_values],
                            "len": int(row["len"]),
                            "rssi": int(row.get("rssi", 0) or 0),
                        }
                    )
                except Exception:
                    skipped_rows += 1
        return imported_events, skipped_rows

    def load_collect_display_from_result(
        self,
        collect_result: dict[str, object],
        retry_count: int = 0,
        remember: bool = True,
    ) -> None:
        """把某次采集结果加载到“采集显示”区域。"""
        sample_path = self._resolve_collect_display_path(collect_result)
        if sample_path is None:
            return

        if not sample_path.exists():
            if retry_count < 5:
                QTimer.singleShot(
                    100,
                    lambda result=dict(collect_result), retries=retry_count + 1: self.load_collect_display_from_result(
                        result,
                        retries,
                        remember,
                    ),
                )
            return

        try:
            events, skipped_rows = self.load_csi_events_from_csv(sample_path)
        except PermissionError:
            if retry_count < 5:
                QTimer.singleShot(
                    100,
                    lambda result=dict(collect_result), retries=retry_count + 1: self.load_collect_display_from_result(
                        result,
                        retries,
                        remember,
                    ),
                )
            return

        self.collect_display_path = sample_path
        self.collect_display_events = events
        self.collect_display_skipped_rows = skipped_rows
        self.collect_display_result = dict(collect_result)
        self.collect_display_keyframe_csv_path = self._resolve_collect_keyframe_csv_path(collect_result)
        self.collect_display_result["sample_path"] = str(sample_path)
        if self.collect_display_keyframe_csv_path is not None:
            self.collect_display_result["keyframe_csv_path"] = str(self.collect_display_keyframe_csv_path)
        if remember:
            self._remember_collect_display_result(self.collect_display_result)
        else:
            self.collect_display_current_index = self._find_collect_display_history_index(self.collect_display_result)
        self.render_collect_display()
        self._update_collect_display_navigation_state()

    def _resolve_collect_display_path(self, collect_result: dict[str, object]) -> Path | None:
        """根据采集结果字典推断对应样本 CSV 的实际路径。"""
        sample_path_value = str(collect_result.get("sample_path", "")).strip()
        if sample_path_value:
            candidate_path = Path(sample_path_value).resolve()
            if candidate_path.exists():
                return candidate_path

        timestamp = str(collect_result.get("timestamp", "")).strip()
        target = str(collect_result.get("target", "")).strip()
        if not timestamp or not target:
            return None

        candidate_paths = [
            (self.repo_root / COLLECT_DATA_ROOT / target / f"{timestamp}.csv").resolve(),
            (self.collect_pc_tool_root / COLLECT_DATA_ROOT / target / f"{timestamp}.csv").resolve(),
        ]
        for candidate_path in candidate_paths:
            if candidate_path.exists():
                return candidate_path
        return candidate_paths[0]

    @staticmethod
    def _collect_display_result_key(collect_result: dict[str, object]) -> tuple[str, str]:
        """生成用于历史去重的采集结果键。"""
        return (
            str(collect_result.get("timestamp", "")).strip(),
            str(collect_result.get("target", "")).strip(),
        )

    def _find_collect_display_history_index(self, collect_result: dict[str, object]) -> int:
        """在历史列表中查找某次采集结果的索引。"""
        result_key = self._collect_display_result_key(collect_result)
        if not any(result_key):
            return -1
        for index, item in enumerate(self.collect_display_history):
            if self._collect_display_result_key(item) == result_key:
                return index
        return -1

    def _remember_collect_display_result(self, collect_result: dict[str, object]) -> None:
        """把采集结果加入历史，并更新当前显示指针。"""
        existing_index = self._find_collect_display_history_index(collect_result)
        if existing_index >= 0:
            self.collect_display_history[existing_index] = dict(collect_result)
            self.collect_display_current_index = existing_index
            return
        self.collect_display_history.append(dict(collect_result))
        self.collect_display_current_index = len(self.collect_display_history) - 1

    def _remove_collect_display_result_from_history(self, collect_result: dict[str, object]) -> int:
        """从采集历史中移除一条结果，并调整当前索引。"""
        existing_index = self._find_collect_display_history_index(collect_result)
        if existing_index < 0:
            return -1

        del self.collect_display_history[existing_index]
        if not self.collect_display_history:
            self.collect_display_current_index = -1
        elif self.collect_display_current_index > existing_index:
            self.collect_display_current_index -= 1
        elif self.collect_display_current_index >= len(self.collect_display_history):
            self.collect_display_current_index = len(self.collect_display_history) - 1
        return existing_index

    def _update_collect_display_navigation_state(self) -> None:
        """根据采集历史状态刷新上一个/下一个/清除按钮可用性。"""
        has_history = bool(self.collect_display_history)
        has_current = has_history and 0 <= self.collect_display_current_index < len(self.collect_display_history)
        self.pushButton_collect_previous.setEnabled(has_current and self.collect_display_current_index > 0)
        self.pushButton_collect_next.setEnabled(
            has_current and self.collect_display_current_index < len(self.collect_display_history) - 1
        )
        self.pushButton_collect_clear.setEnabled(self.collect_display_path is not None and self.collect_display_result is not None)
        self.pushButton_collect_clear_all.setEnabled(has_history)

        if not has_current or self.collect_display_path is None:
            self.label_collect_summary.setText("暂无采集样本")
            return

        sample_label = self.collect_display_path.name
        current_position = self.collect_display_current_index + 1
        total_samples = len(self.collect_display_history)
        if self.collect_display_events:
            self.label_collect_summary.setText(
                f"当前 {current_position}/{total_samples}: {sample_label}， "
                f"{len(self.collect_display_events)} 条数据"
            )
        else:
            self.label_collect_summary.setText(
                f"当前 {current_position}/{total_samples}: {sample_label}，无效数据"
            )

    def set_collect_display_index(self, index: int) -> None:
        """切换当前展示的采集样本索引。"""
        if not self.collect_display_history:
            self._clear_collect_display_state()
            return

        target_index = max(0, min(int(index), len(self.collect_display_history) - 1))
        while self.collect_display_history:
            target_index = max(0, min(target_index, len(self.collect_display_history) - 1))
            target_result = dict(self.collect_display_history[target_index])
            target_path = self._resolve_collect_display_path(target_result)
            if target_path is not None and target_path.exists():
                self.collect_display_current_index = target_index
                self.load_collect_display_from_result(target_result, remember=False)
                return
            del self.collect_display_history[target_index]

        self._clear_collect_display_state()

    def show_previous_collect_display_sample(self) -> None:
        """显示上一条采集样本。"""
        if self.collect_display_current_index > 0:
            self.set_collect_display_index(self.collect_display_current_index - 1)

    def show_next_collect_display_sample(self) -> None:
        """显示下一条采集样本。"""
        if 0 <= self.collect_display_current_index < len(self.collect_display_history) - 1:
            self.set_collect_display_index(self.collect_display_current_index + 1)

    def render_collect_display(self) -> None:
        """重绘“采集显示”区域中的静态样本波形。"""
        if self.collect_display_path is None:
            self.collect_plot_controller.load_static_dataset(
                self.valid_subcarriers,
                np.zeros((0, len(self.valid_subcarriers)), dtype=np.float64),
                [],
                1,
            )
            return

        collect_processor = CsiBufferProcessor(
            buffer_size=max(len(self.collect_display_events), 1),
            sample_rate=self.processor.sample_rate,
            valid_subcarriers=self.valid_subcarriers,
            display_unit=DEFAULT_UNIT,
            filter_enabled=self.checkBox_lp_filter.isChecked(),
        )
        waveform = collect_processor.build_waveform_from_events(self.collect_display_events)
        self.collect_plot_controller.load_static_dataset(
            self.valid_subcarriers,
            waveform,
            [],
            max(waveform.shape[0], 1),
        )

    def _delete_collect_display_result_artifacts(self, collect_result: dict[str, object]) -> bool:
        """删除采集样本文件、备注记录以及关键帧记录。"""
        sample_path = self._resolve_collect_display_path(collect_result)
        if sample_path is None:
            return False

        deleted_sample = False
        try:
            if sample_path.exists():
                sample_path.unlink()
                deleted_sample = True
        except OSError:
            return False

        remark_csv_path = self._resolve_collect_remark_path(sample_path)
        try:
            self._delete_collect_remark_rows(remark_csv_path, collect_result)
        except OSError:
            pass

        keyframe_csv_path = self._resolve_collect_keyframe_csv_path(collect_result)
        try:
            if self.serial_is_connected and self.serial_queue_write is not None and keyframe_csv_path is not None:
                self.serial_queue_write.put(
                    {
                        "type": "DELETE_COLLECT_KEYFRAMES",
                        "start_packet_index": collect_result.get("start_packet_index"),
                        "end_packet_index": collect_result.get("end_packet_index"),
                        "keyframe_csv_path": str(keyframe_csv_path),
                    }
                )
            else:
                self._delete_collect_keyframe_rows(keyframe_csv_path, collect_result)
        except (OSError, ValueError):
            pass

        return deleted_sample or not sample_path.exists()

    def clear_collect_display_sample(self) -> None:
        """删除当前展示的单个采集样本及其配套记录。"""
        if self.collect_display_path is None or self.collect_display_result is None:
            return

        collect_result = dict(self.collect_display_result)
        if not self._delete_collect_display_result_artifacts(collect_result):
            return

        current_index = self.collect_display_current_index
        removed_index = self._remove_collect_display_result_from_history(collect_result)
        if self.collect_display_history:
            if removed_index >= 0:
                target_index = min(max(removed_index - 1, 0), len(self.collect_display_history) - 1)
            else:
                target_index = min(max(current_index - 1, 0), len(self.collect_display_history) - 1)
            self.set_collect_display_index(target_index)
            return
        self._clear_collect_display_state()

    def clear_collect_display_all_samples(self) -> None:
        """删除当前历史列表中的全部采集样本。"""
        if not self.collect_display_history:
            return

        history_snapshot = [dict(item) for item in self.collect_display_history]
        remaining_history: list[dict[str, object]] = []
        for collect_result in history_snapshot:
            if not self._delete_collect_display_result_artifacts(collect_result):
                remaining_history.append(dict(collect_result))

        self.collect_display_history = remaining_history
        if self.collect_display_history:
            self.set_collect_display_index(0)
            return
        self._clear_collect_display_state()

    def _clear_collect_display_state(self) -> None:
        """清空采集显示页当前载入的数据状态。"""
        self.collect_display_path = None
        self.collect_display_events = []
        self.collect_display_skipped_rows = 0
        self.collect_display_result = None
        self.collect_display_keyframe_csv_path = None
        self.collect_display_current_index = -1
        self.render_collect_display()
        self._update_collect_display_navigation_state()

    def _resolve_collect_remark_path(self, sample_path: Path | None = None) -> Path | None:
        """推断某个采集样本对应的 remark.csv 路径。"""
        candidate_paths: list[Path] = []
        resolved_sample_path = sample_path or self.collect_display_path
        if resolved_sample_path is not None and len(resolved_sample_path.parents) >= 2:
            candidate_paths.append((resolved_sample_path.parent.parent / "remark.csv").resolve())
        candidate_paths.extend(
            [
                (self.repo_root / COLLECT_REMARK_FILE).resolve(),
                (self.collect_pc_tool_root / COLLECT_REMARK_FILE).resolve(),
            ]
        )
        for candidate_path in self._deduplicate_paths(candidate_paths):
            if candidate_path.exists():
                return candidate_path
        deduplicated_paths = self._deduplicate_paths(candidate_paths)
        return deduplicated_paths[0] if deduplicated_paths else None

    def _resolve_collect_keyframe_csv_path(self, collect_result: dict[str, object]) -> Path | None:
        """推断某个采集样本对应的关键帧 CSV 路径。"""
        keyframe_csv_value = str(collect_result.get("keyframe_csv_path", "")).strip()
        if keyframe_csv_value:
            candidate_path = Path(keyframe_csv_value).resolve()
            if candidate_path.exists():
                return candidate_path

        start_packet_index = self._coerce_int(collect_result.get("start_packet_index"))
        end_packet_index = self._coerce_int(collect_result.get("end_packet_index"))
        if start_packet_index is None or end_packet_index is None:
            return None

        candidate_paths: list[Path] = []
        for runtime_root in self._runtime_log_roots():
            if not runtime_root.exists():
                continue
            candidate_paths.extend(runtime_root.glob("*/keyframe_marks.csv"))

        def mtime_key(path: Path) -> float:
            try:
                return path.stat().st_mtime
            except OSError:
                return 0.0

        for candidate_path in sorted(self._deduplicate_paths(candidate_paths), key=mtime_key, reverse=True):
            if self._keyframe_csv_contains_collect_bounds(candidate_path, start_packet_index, end_packet_index):
                return candidate_path
        return None

    def _runtime_log_roots(self) -> list[Path]:
        """返回可能存放 runtime 日志的根目录候选列表。"""
        return self._deduplicate_paths(
            [
                (self.repo_root / RUNTIME_LOG_ROOT).resolve(),
                (self.collect_pc_tool_root / RUNTIME_LOG_ROOT).resolve(),
            ]
        )

    @staticmethod
    def _deduplicate_paths(paths: list[Path]) -> list[Path]:
        """按路径字符串去重，并保留原始遍历顺序。"""
        unique_paths: list[Path] = []
        seen_paths: set[str] = set()
        for path in paths:
            normalized_path = str(path)
            if normalized_path in seen_paths:
                continue
            seen_paths.add(normalized_path)
            unique_paths.append(path)
        return unique_paths

    @staticmethod
    def _coerce_int(value: object) -> int | None:
        """把任意对象转换成整数；失败时返回 None。"""
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _keyframe_csv_contains_collect_bounds(
        self,
        keyframe_csv_path: Path,
        start_packet_index: int,
        end_packet_index: int,
    ) -> bool:
        """检查关键帧 CSV 中是否包含某次采集的开始/结束边界。"""
        if not keyframe_csv_path.exists():
            return False

        found_start = False
        found_end = False
        _, rows = self._read_csv_dict_rows_safely(keyframe_csv_path)
        for row in rows:
            packet_index = self._coerce_int(row.get("packet_index"))
            remark = str(row.get("remark", "")).strip()
            if not found_start and packet_index == start_packet_index and self._is_collect_start_remark(remark):
                found_start = True
                continue
            if not found_end and packet_index == end_packet_index and self._is_collect_end_remark(remark):
                found_end = True
            if found_start and found_end:
                return True
        return False

    @staticmethod
    def _read_csv_dict_rows_safely(csv_path: Path) -> tuple[list[str], list[dict[str, str]]]:
        """稳妥读取 CSV，兼容 BOM、空文件和脏字符。"""
        if not csv_path.exists():
            return [], []
        csv_text = csv_path.read_text(encoding="utf-8-sig", errors="ignore").replace("\x00", "")
        if not csv_text.strip():
            return [], []
        reader = csv.DictReader(StringIO(csv_text))
        return reader.fieldnames or [], list(reader)

    def _delete_collect_remark_rows(
        self,
        remark_csv_path: Path | None,
        collect_result: dict[str, object],
    ) -> int:
        """删除某次采集结果在 remark.csv 中对应的备注行。"""
        if remark_csv_path is None or not remark_csv_path.exists():
            return 0

        timestamp = str(collect_result.get("timestamp", "")).strip()
        target = str(collect_result.get("target", "")).strip()
        num = str(collect_result.get("num", "")).strip()
        with remark_csv_path.open("r", newline="", encoding="utf-8-sig") as file_obj:
            reader = csv.DictReader(file_obj)
            fieldnames = reader.fieldnames or []
            rows = list(reader)
        if "timestamp" not in fieldnames:
            return 0

        deleted_rows = 0
        remaining_rows: list[dict[str, str]] = []
        for row in rows:
            row_timestamp = str(row.get("timestamp", "")).strip()
            row_target = str(row.get("target", "")).strip()
            row_num = str(row.get("num", "")).strip()
            num_matches = not num or not row_num or row_num == num
            if deleted_rows == 0 and row_timestamp == timestamp and row_target == target and num_matches:
                deleted_rows = 1
                continue
            remaining_rows.append(row)

        if deleted_rows == 0:
            return 0

        with remark_csv_path.open("w", newline="", encoding="utf-8") as file_obj:
            writer = csv.DictWriter(file_obj, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(remaining_rows)
        return deleted_rows

    def _delete_collect_keyframe_rows(
        self,
        keyframe_csv_path: Path | None,
        collect_result: dict[str, object],
    ) -> int:
        """删除某次采集结果对应的开始/结束关键帧。"""
        if keyframe_csv_path is None or not keyframe_csv_path.exists():
            return 0

        start_packet_index = self._coerce_int(collect_result.get("start_packet_index"))
        end_packet_index = self._coerce_int(collect_result.get("end_packet_index"))
        if start_packet_index is None or end_packet_index is None:
            return 0

        fieldnames, rows = self._read_csv_dict_rows_safely(keyframe_csv_path)
        if "packet_index" not in fieldnames or "remark" not in fieldnames:
            return 0

        deleted_rows = 0
        deleted_start = False
        deleted_end = False
        remaining_rows: list[dict[str, str]] = []
        for row in rows:
            packet_index = self._coerce_int(row.get("packet_index"))
            remark = str(row.get("remark", "")).strip()
            if not deleted_start and packet_index == start_packet_index and self._is_collect_start_remark(remark):
                deleted_start = True
                deleted_rows += 1
                continue
            if not deleted_end and packet_index == end_packet_index and self._is_collect_end_remark(remark):
                deleted_end = True
                deleted_rows += 1
                continue
            remaining_rows.append(row)

        if deleted_rows == 0:
            return 0

        with keyframe_csv_path.open("w", newline="", encoding="utf-8") as file_obj:
            writer = csv.DictWriter(file_obj, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(remaining_rows)
        return deleted_rows

    def _count_collect_keyframe_rows(
        self,
        keyframe_csv_path: Path | None,
        collect_result: dict[str, object],
    ) -> int:
        """统计某次采集在关键帧 CSV 中仍保留了多少边界标记。"""
        if keyframe_csv_path is None or not keyframe_csv_path.exists():
            return 0

        start_packet_index = self._coerce_int(collect_result.get("start_packet_index"))
        end_packet_index = self._coerce_int(collect_result.get("end_packet_index"))
        if start_packet_index is None or end_packet_index is None:
            return 0

        _, rows = self._read_csv_dict_rows_safely(keyframe_csv_path)
        found_start = False
        found_end = False
        for row in rows:
            packet_index = self._coerce_int(row.get("packet_index"))
            remark = str(row.get("remark", "")).strip()
            if not found_start and packet_index == start_packet_index and self._is_collect_start_remark(remark):
                found_start = True
                continue
            if not found_end and packet_index == end_packet_index and self._is_collect_end_remark(remark):
                found_end = True
            if found_start and found_end:
                break
        return int(found_start) + int(found_end)

    def handle_fail_event(self, message: str) -> None:
        """处理串口子进程上报的致命异常。"""
        QMessageBox.critical(self, "串口异常", message)
        self.disconnect_serial()

    def command_change_target(self, target: str) -> None:
        """向设备发送 target 切换命令。"""
        if self.serial_queue_write is not None:
            if target == "unknown":
                self.serial_queue_write.put({"type": "COLLECT_ABORT"})
            self.serial_queue_write.put(
                {
                    "type": "COLLECT_CONFIG",
                    "target": "",
                    "packet_limit": 0,
                }
            )
            self.serial_queue_write.put(f"radar --change_target {target}")

    def command_collect_csi_num(self, target: str, num: int) -> None:
        """配置下一次按包数采集的目标与数量。"""
        if self.serial_queue_write is not None:
            self.serial_queue_write.put(
                {
                    "type": "COLLECT_CONFIG",
                    "target": target,
                    "packet_limit": int(num),
                }
            )
            # 设备侧按包数采集命令存在偶发少一包的问题，这里改为仅切换 target，
            # 由本地记录器按 unknown->target 启动并在满额时精确收口。
            self.serial_queue_write.put(f"radar --change_target {target}")

    def _ensure_process_channels(self) -> None:
        """按需创建主进程与串口子进程通信所需的队列。"""
        if self.serial_queue_read is None:
            self.serial_queue_read = Queue(maxsize=128)
        if self.serial_queue_write is None:
            self.serial_queue_write = Queue(maxsize=128)
        if self.collect_time_queue is None:
            self.collect_time_queue = Queue(maxsize=16)

    def _start_ui_bridge(self) -> None:
        """启动 UI 桥接线程，把后台事件转成 Qt 信号。"""
        if self.ui_data_thread is not None:
            return

        self.ui_data_thread = UiEventBridge(self.serial_queue_read, self.processor)
        self.ui_data_thread.signal_log_msg.connect(self.show_textBrowser_log)
        self.ui_data_thread.signal_update_csi_subcarrier.connect(self.update_csi_subcarrier_data)
        self.ui_data_thread.signal_live_csi_frame.connect(self.handle_live_csi_frame)
        self.ui_data_thread.signal_fail.connect(self.handle_fail_event)
        self.ui_data_thread.start()

    def _stop_ui_bridge(self) -> None:
        """停止 UI 桥接线程并等待其安全退出。"""
        if self.ui_data_thread is None:
            return

        self.ui_data_thread.is_running = False
        self.ui_data_thread.quit()
        self.ui_data_thread.wait(1000)
        self.ui_data_thread = None

    def closeEvent(self, event) -> None:
        """关闭窗口前，统一回收串口、线程和识别资源。"""
        self.disconnect_serial()
        self._stop_ui_bridge()
        if self.inference_worker is not None:
            self.inference_worker.stop()
            self.inference_worker.wait(1000)
            self.inference_worker = None
        event.accept()


def main() -> int:
    """创建 QApplication 和主窗口，并进入 Qt 事件循环。"""
    app = QApplication(sys.argv)
    window = DataGraphicalWindow()
    window.show()
    return app.exec_()
