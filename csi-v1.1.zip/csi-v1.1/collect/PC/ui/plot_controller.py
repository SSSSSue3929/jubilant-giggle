"""CSI 子载波绘图与关键帧标记控制。

该模块把 pyqtgraph 的直接操作封装起来，统一管理实时波形、
静态样本波形以及关键帧标记的绘制逻辑。
"""

from __future__ import annotations

import colorsys

import numpy as np
import pyqtgraph as pg
from PyQt5.QtCore import Qt
from pyqtgraph import InfiniteLine

from core.constants import CSI_BUFFER_SIZE


class SubcarrierPlotController:
    """封装单个 PlotWidget 的 CSI 波形绘制状态。"""

    def __init__(
        self,
        plot_widget,
        buffer_size: int = CSI_BUFFER_SIZE,
        show_legend: bool = True,
    ) -> None:
        """初始化绘图控件、图例配置和关键帧缓存。"""
        # 保存绘图控件与横轴长度，后续所有绘图刷新都基于这两个对象。
        self.plot_widget = plot_widget
        self.buffer_size = buffer_size
        self.show_legend = show_legend
        # static_data_length 用于导入分析场景下的横轴范围控制。
        self.static_data_length = buffer_size
        # curves 保存每条子载波曲线对象，便于后续逐条更新数据。
        self.curves = []
        # colors 保存为每条曲线生成的颜色。
        self.colors = []
        # key_frames 记录逻辑上的关键帧位置和备注。
        self.key_frames = []
        # keyframe_items 保存已经画到图上的垂直线对象，便于清理和重绘。
        self.keyframe_items = []
        # 维护当前 Y 轴范围，避免每次刷新都强制跳动。
        self.curve_subcarrier_range = np.array([0.0, float(buffer_size)])

    def reset_subcarriers(self, valid_subcarriers: list[int], initial_waveform: np.ndarray) -> None:
        """在子载波集合变化时，重建整张实时曲线图。"""
        # 子载波配置变化后先清空画布，再按新的子载波列表重建曲线。
        self.plot_widget.clear()
        self.curves.clear()
        self.static_data_length = initial_waveform.shape[0] if initial_waveform.ndim == 2 else 0
        # 为每条子载波重新生成可区分的颜色。
        self.colors = self._generate_distinct_rgb_colors(len(valid_subcarriers))
        self.curve_subcarrier_range = np.array([0.0, float(self.buffer_size)])
        self.plot_widget.setYRange(self.curve_subcarrier_range[0], self.curve_subcarrier_range[1])
        self._reset_legend()
        if self.show_legend:
            self.plot_widget.addLegend()

        for index, subcarrier in enumerate(valid_subcarriers):
            # name 使用真实子载波编号，方便图例直接对照配置。
            curve = self.plot_widget.plot(
                initial_waveform[:, index],
                name=str(subcarrier),
                pen=self.colors[index],
            )
            self.curves.append(curve)

        # 重建曲线后把关键帧标记一并补回去。
        self._redraw_keyframe_items()

    def load_static_dataset(
        self,
        valid_subcarriers: list[int],
        waveform: np.ndarray,
        key_frames: list[list[object]] | None = None,
        visible_window: int | None = None,
    ) -> None:
        """加载导入分析场景下的完整静态波形和关键帧。"""
        self.plot_widget.clear()
        self.curves.clear()
        self.colors = self._generate_distinct_rgb_colors(len(valid_subcarriers))
        self.static_data_length = waveform.shape[0] if waveform.ndim == 2 else 0
        self.key_frames = [[int(x_axis), str(remark)] for x_axis, remark in (key_frames or [])]

        if waveform.size > 0:
            min_value = float(np.min(waveform))
            max_value = float(np.max(waveform))
            lower = min_value - 1 if min_value > 0 else min_value
            upper = max_value + 1 if max_value >= lower else lower + 1
            self.curve_subcarrier_range = np.array([lower, upper], dtype=np.float64)
        else:
            self.curve_subcarrier_range = np.array([0.0, float(self.buffer_size)])

        self.plot_widget.setYRange(self.curve_subcarrier_range[0], self.curve_subcarrier_range[1])
        self._reset_legend()
        if self.show_legend:
            self.plot_widget.addLegend()

        x_axis = np.arange(self.static_data_length, dtype=np.float64)
        for index, subcarrier in enumerate(valid_subcarriers):
            curve = self.plot_widget.plot(
                x=x_axis,
                y=waveform[:, index] if waveform.size > 0 else np.array([], dtype=np.float64),
                name=str(subcarrier),
                pen=self.colors[index],
            )
            self.curves.append(curve)

        self._redraw_keyframe_items()

        x_max = max(self.static_data_length - 1, 0)
        self.plot_widget.setLimits(xMin=0, xMax=x_max)
        if self.static_data_length > 0:
            window = min(max(visible_window or self.buffer_size, 1), self.static_data_length)
            self.plot_widget.setXRange(0, window - 1, padding=0)

    def render(self, waveform: np.ndarray, shift_packets: int) -> None:
        """刷新实时波形，并把关键帧同步左移到新坐标。"""
        if waveform.size == 0:
            return

        # 根据当前数据动态放宽 Y 轴范围，避免波形超出视图。
        min_value = float(np.min(waveform))
        max_value = float(np.max(waveform))
        if self.curve_subcarrier_range[0] > min_value or self.curve_subcarrier_range[1] < max_value:
            if min_value > 0 and self.curve_subcarrier_range[0] > min_value:
                self.curve_subcarrier_range[0] = min_value - 1
            if self.curve_subcarrier_range[1] < max_value:
                self.curve_subcarrier_range[1] = max_value + 1
            self.plot_widget.setYRange(self.curve_subcarrier_range[0], self.curve_subcarrier_range[1])

        for index, curve in enumerate(self.curves):
            # 每条曲线只更新自己的那一列数据，避免反复创建图形对象。
            curve.setData(waveform[:, index])

        # 刷新波形后，同步把关键帧按接收到的新包数量向左平移。
        self._shift_keyframes(shift_packets)

    def set_visible_x_range(self, start_index: int, visible_window: int) -> None:
        """设置静态导入分析图的横向可视窗口。"""
        if self.static_data_length <= 0:
            return

        window = min(max(visible_window, 1), self.static_data_length)
        start = max(0, min(int(start_index), self.static_data_length - window))
        end = start + window - 1
        self.plot_widget.setXRange(start, end, padding=0)

    def add_keyframe(self, x_axis: int, remark: str = "手动标记") -> None:
        """向当前图中追加一个关键帧标记。"""
        # 先把横坐标限制在图像缓冲区内，避免越界标记。
        x_axis = max(0, min(x_axis, self.buffer_size))
        self.key_frames.append([x_axis, remark])
        self._redraw_keyframe_items()

    def clear_keyframes(self) -> None:
        """清空当前图中的所有关键帧标记。"""
        self.key_frames = []
        self._redraw_keyframe_items()

    def live_packet_index_from_x(self, x_axis: int, total_packets: int) -> int | None:
        """将实时滚动图中的横坐标换算为 csi_data.csv 中的全局包序号。"""
        if total_packets <= 0:
            return None

        packet_index = total_packets - self.buffer_size + int(x_axis)
        return max(0, min(total_packets - 1, packet_index))

    def _shift_keyframes(self, shift_packets: int) -> None:
        """随着实时窗口滚动，整体平移关键帧位置。"""
        if shift_packets <= 0:
            self._redraw_keyframe_items()
            return

        # 重新生成关键帧列表，丢弃已经移出左边界的标记。
        shifted_key_frames = []
        for x_axis, remark in self.key_frames:
            shifted_x = x_axis - shift_packets
            if shifted_x > 0:
                shifted_key_frames.append([shifted_x, remark])
        self.key_frames = shifted_key_frames
        self._redraw_keyframe_items()

    def _redraw_keyframe_items(self) -> None:
        """按当前 key_frames 状态重新绘制垂直标记线。"""
        # 每次重绘前先删除旧线条，避免关键帧重复叠加。
        for item in self.keyframe_items:
            self.plot_widget.removeItem(item)
        self.keyframe_items.clear()

        for x_axis, _remark in self.key_frames:
            # 使用白色虚线强调关键帧位置，不干扰主波形颜色。
            line = InfiniteLine(
                pos=x_axis,
                angle=90,
                pen=pg.mkPen(color="white", style=Qt.DashLine, width=1),
            )
            self.plot_widget.addItem(line)
            self.keyframe_items.append(line)

    def _reset_legend(self) -> None:
        """删除旧图例，为下一轮曲线重建腾出空间。"""
        legend = self.plot_widget.plotItem.legend
        if legend is None:
            return
        self.plot_widget.plotItem.legend = None
        if legend.scene() is not None:
            legend.scene().removeItem(legend)

    @staticmethod
    def _generate_distinct_rgb_colors(color_count: int) -> list[tuple[int, int, int]]:
        """生成一组彼此区分度较高的 RGB 颜色。"""
        # 通过均匀分布 HSV 色相生成一组较容易区分的颜色。
        saturation = 0.9
        brightness = 0.95
        rgb_colors = []
        for index in range(max(color_count, 1)):
            hue = index / max(color_count, 1)
            red, green, blue = colorsys.hsv_to_rgb(hue, saturation, brightness)
            rgb_colors.append((int(red * 255), int(green * 255), int(blue * 255)))
        return rgb_colors
