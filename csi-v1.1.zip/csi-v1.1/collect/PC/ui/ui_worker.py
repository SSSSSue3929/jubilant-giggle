"""面向 UI 的工作线程，负责把进程事件桥接成 Qt 信号。

主窗口不会直接阻塞式读取串口子进程输出，而是通过这个线程把事件
转成 Qt 信号，再安全地交回主线程更新界面。
"""

from __future__ import annotations

import queue

from PyQt5.QtCore import QThread, pyqtSignal

from core.csi_processing import CsiBufferProcessor


class UiEventBridge(QThread):
    """负责消费串口子进程事件，并转发给主窗口。"""

    signal_log_msg = pyqtSignal(str)
    signal_update_csi_subcarrier = pyqtSignal(object, int)
    signal_live_csi_frame = pyqtSignal(object)
    signal_fail = pyqtSignal(str)

    def __init__(self, serial_queue_read, processor: CsiBufferProcessor) -> None:
        """保存事件来源队列和 CSI 处理器引用。"""
        super().__init__()
        # 保存跨进程读取队列，线程只负责消费事件并转发给界面。
        self.serial_queue_read = serial_queue_read
        # 业务处理器负责解码、滤波和单位转换。
        self.processor = processor
        # 使用显式运行标志，便于窗口关闭时优雅退出线程。
        self.is_running = True

    def run(self) -> None:
        """线程主循环：按事件类型分发日志、波形和异常。"""
        while self.is_running:
            try:
                # 定时从进程队列中拉取一条事件，避免线程永久阻塞。
                event = self.serial_queue_read.get(timeout=0.05)
            except queue.Empty:
                continue

            # 所有事件都以 type 字段区分，便于 UI 层做路由处理。
            event_type = event.get("type")
            if event_type == "CSI_DATA":
                # CSI 数据先交给业务层处理，再把波形发回主线程刷新图像。
                waveform = self.processor.append_csi_event(event)
                self.signal_update_csi_subcarrier.emit(waveform, 1)
                self.signal_live_csi_frame.emit(
                    {
                        "data": list(event.get("data", [])),
                        "len": int(event.get("len", 0) or 0),
                        "timestamp": event.get("timestamp", ""),
                    }
                )
                continue

            if event_type == "LOG_DATA":
                # 日志数据转换成带颜色的 HTML，再追加到日志窗口。
                self.signal_log_msg.emit(self._format_log_html(event))
                continue

            if event_type == "FAIL_EVENT":
                # 一旦底层串口失败，通知主窗口弹窗并终止当前桥接线程。
                self.signal_fail.emit(event.get("data", "未知错误"))
                self.is_running = False

    def set_valid_subcarriers(self, valid_subcarriers: list[int]) -> None:
        """在后台线程中切换有效子载波，并回推最新波形。"""
        # 子载波切换后需要立即把清空后的波形回推给 UI 重绘。
        waveform = self.processor.set_valid_subcarriers(valid_subcarriers)
        self.signal_update_csi_subcarrier.emit(waveform, 0)

    def set_display_unit(self, display_unit: str) -> None:
        """在后台线程中切换显示单位，并回推当前波形。"""
        # 单位切换不会新增 CSI 包，因此 packet_delta 传 0。
        waveform = self.processor.set_display_unit(display_unit)
        self.signal_update_csi_subcarrier.emit(waveform, 0)

    def set_filter_enabled(self, enabled: bool) -> None:
        """在后台线程中切换滤波开关，并立即输出重算后的波形。"""
        # 滤波开关切换时，也需要立即返回重新计算后的当前波形。
        waveform = self.processor.set_filter_enabled(enabled)
        self.signal_update_csi_subcarrier.emit(waveform, 0)

    @staticmethod
    def _format_log_html(event: dict) -> str:
        """把日志事件包装成带颜色的 HTML 文本。"""
        # 根据日志等级映射颜色，便于在界面中快速识别异常级别。
        color_map = {"I": "green", "W": "yellow", "E": "red"}
        tag = event.get("tag", "I")
        color = color_map.get(tag, "white")
        timestamp = event.get("timestamp", "")
        message = event.get("data", "")
        return f"<font color='{color}'>{tag} ({timestamp}) {message}</font>"
