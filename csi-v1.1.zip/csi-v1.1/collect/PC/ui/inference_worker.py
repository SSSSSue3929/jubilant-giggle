"""自动识别后台线程。

该线程把主窗口投递过来的 CSI 帧、开关状态和步长配置串行处理，
避免模型推理阻塞 Qt 主线程。
"""

from __future__ import annotations

import queue
from pathlib import Path
from typing import Any

from PyQt5.QtCore import QThread, pyqtSignal

from model import (
    DEFAULT_NON_INVALID_CONFIDENCE_THRESHOLD,
    LstmSlidingWindowRecognizer,
)


class LstmInferenceWorker(QThread):
    """负责管理 LSTM 识别器生命周期的后台工作线程。"""

    signal_result = pyqtSignal(object)
    signal_status = pyqtSignal(str)
    signal_error = pyqtSignal(str)

    def __init__(
        self,
        checkpoint_path: Path,
        stride: int = 65,
        non_invalid_confidence_threshold: float = DEFAULT_NON_INVALID_CONFIDENCE_THRESHOLD,
    ) -> None:
        """保存初始配置，并准备线程内命令队列。"""
        super().__init__()
        self.checkpoint_path = Path(checkpoint_path)
        self.initial_stride = int(stride)
        self.initial_non_invalid_confidence_threshold = float(non_invalid_confidence_threshold)
        self.command_queue: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.is_running = True
        self.is_enabled = False
        self._last_status = ""

    def set_enabled(self, enabled: bool) -> None:
        """异步切换自动识别开关。"""
        self.command_queue.put(("enabled", bool(enabled)))

    def set_stride(self, stride: int) -> None:
        """异步更新滑动窗口步长。"""
        self.command_queue.put(("stride", int(stride)))

    def enqueue_csi_frame(self, frame: Any) -> None:
        """把最新一帧 CSI 特征送入后台线程。"""
        self.command_queue.put(("frame", frame))

    def reset_sequence(self) -> None:
        """清空线程内识别序列，重新等待新的窗口。"""
        self.command_queue.put(("reset", None))

    def stop(self) -> None:
        """请求线程结束，并唤醒阻塞中的命令队列。"""
        self.is_running = False
        self.command_queue.put(("stop", None))

    def run(self) -> None:
        """线程主循环：初始化识别器，并串行处理各类识别命令。"""
        try:
            recognizer = LstmSlidingWindowRecognizer(
                checkpoint_path=self.checkpoint_path,
                stride=self.initial_stride,
                non_invalid_confidence_threshold=self.initial_non_invalid_confidence_threshold,
            )
        except Exception as exc:
            self.signal_error.emit(str(exc))
            return

        self._emit_status("识别结果：未开启")

        while self.is_running:
            try:
                command, payload = self.command_queue.get(timeout=0.1)
            except queue.Empty:
                continue

            if command == "stop":
                break

            if command == "enabled":
                self.is_enabled = bool(payload)
                # 切换开关后重置窗口，避免把旧状态带入新一轮识别。
                recognizer.reset()
                self._emit_status(
                    recognizer.waiting_status() if self.is_enabled else "识别结果：未开启"
                )
                continue

            if command == "stride":
                try:
                    recognizer.set_stride(int(payload))
                except ValueError as exc:
                    self.signal_error.emit(str(exc))
                    continue
                if self.is_enabled:
                    # 步长变化会影响窗口采样节奏，因此同步清空旧序列。
                    recognizer.reset()
                    self._emit_status(recognizer.waiting_status())
                continue

            if command == "reset":
                recognizer.reset()
                self._emit_status(
                    recognizer.waiting_status() if self.is_enabled else "识别结果：未开启"
                )
                continue

            if command != "frame" or not self.is_enabled:
                continue

            try:
                result = recognizer.ingest_frame(payload)
            except ValueError as exc:
                # 当前帧维度不匹配时，清空窗口并等待新的兼容输入。
                recognizer.reset()
                self._emit_status(str(exc))
                continue
            except Exception as exc:
                self.signal_error.emit(str(exc))
                continue

            if result is None:
                if not recognizer.has_prediction:
                    self._emit_status(recognizer.waiting_status())
                continue

            self.signal_result.emit(result)
            self._last_status = ""

    def _emit_status(self, text: str) -> None:
        """避免重复发出相同状态文本，减少界面闪烁。"""
        if text == self._last_status:
            return
        self._last_status = text
        self.signal_status.emit(text)
