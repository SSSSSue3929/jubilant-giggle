"""实时识别后台线程。

该线程把主窗口投递过来的 CSI 帧、开关状态和识别配置串行处理，
避免模型推理阻塞 Qt 主线程。当前策略为：
1. 连续滑窗推理。
2. 最近 N 次推理构成一个判定窗口。
3. 仅当某类概率大于等于阈值时，该类计数加 1。
4. 当某个非 Invalid 类在窗口内的计数达到阈值时，触发最终识别。
5. 识别后冻结指定帧数，在冻结期间不再进行窗口判定。
"""

from __future__ import annotations

import queue
from collections import Counter, deque
from pathlib import Path
from typing import Any

from PyQt5.QtCore import QThread, pyqtSignal

from model import LstmSlidingWindowRecognizer

DEFAULT_DECISION_WINDOW_SIZE = 6
DEFAULT_PROBABILITY_THRESHOLD = 0.5
DEFAULT_RECOGNITION_COUNT_THRESHOLD = 3
DEFAULT_FREEZE_FRAMES = 20
INVALID_CLASS_ALIASES = {"invalid", "invaild"}


class LstmInferenceWorker(QThread):
    """负责管理 LSTM 识别器生命周期的后台工作线程。"""

    signal_inference = pyqtSignal(object)
    signal_result = pyqtSignal(object)
    signal_status = pyqtSignal(str)
    signal_error = pyqtSignal(str)

    def __init__(
        self,
        checkpoint_path: Path,
        stride: int = 10,
        decision_window_size: int = DEFAULT_DECISION_WINDOW_SIZE,
        probability_threshold: float = DEFAULT_PROBABILITY_THRESHOLD,
        recognition_count_threshold: int = DEFAULT_RECOGNITION_COUNT_THRESHOLD,
        freeze_frames: int = DEFAULT_FREEZE_FRAMES,
    ) -> None:
        super().__init__()
        self.checkpoint_path = Path(checkpoint_path)
        self.initial_stride = int(stride)
        self.initial_decision_window_size = int(decision_window_size)
        self.initial_probability_threshold = float(probability_threshold)
        self.initial_recognition_count_threshold = int(recognition_count_threshold)
        self.initial_freeze_frames = int(freeze_frames)
        self.command_queue: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.is_running = True
        self.is_enabled = False
        self._last_status = ""

    def set_enabled(self, enabled: bool) -> None:
        self.command_queue.put(("enabled", bool(enabled)))

    def set_stride(self, stride: int) -> None:
        self.command_queue.put(("stride", int(stride)))

    def set_decision_window_size(self, window_size: int) -> None:
        self.command_queue.put(("decision_window_size", int(window_size)))

    def set_probability_threshold(self, threshold: float) -> None:
        self.command_queue.put(("probability_threshold", float(threshold)))

    def set_recognition_count_threshold(self, threshold: int) -> None:
        self.command_queue.put(("recognition_count_threshold", int(threshold)))

    def set_freeze_frames(self, freeze_frames: int) -> None:
        self.command_queue.put(("freeze_frames", int(freeze_frames)))

    def enqueue_csi_frame(self, frame: Any) -> None:
        self.command_queue.put(("frame", frame))

    def reset_sequence(self) -> None:
        self.command_queue.put(("reset", None))

    def stop(self) -> None:
        self.is_running = False
        self.command_queue.put(("stop", None))

    def run(self) -> None:
        try:
            recognizer = LstmSlidingWindowRecognizer(
                checkpoint_path=self.checkpoint_path,
                stride=self.initial_stride,
                non_invalid_confidence_threshold=0.0,
            )
        except Exception as exc:
            self.signal_error.emit(str(exc))
            return

        class_names = [str(class_name) for class_name in recognizer.class_names]
        invalid_class_name = self._resolve_invalid_class_name(recognizer.invalid_class_name)
        decision_window_size = self._validate_decision_window_size(
            self.initial_decision_window_size
        )
        probability_threshold = self._validate_probability_threshold(
            self.initial_probability_threshold
        )
        recognition_count_threshold = self._validate_recognition_count_threshold(
            self.initial_recognition_count_threshold,
            decision_window_size,
        )
        freeze_frames = self._validate_freeze_frames(self.initial_freeze_frames)
        decision_queue: deque[dict[str, Any]] = deque(maxlen=decision_window_size)
        freeze_remaining_frames = 0
        frozen_window_results: list[dict[str, Any]] = []
        frozen_window_queue_length = 0
        last_recognized_class_name = ""
        self._emit_status("识别结果：未开启")

        while self.is_running:
            try:
                command, payload = self.command_queue.get(timeout=0.1)
            except queue.Empty:
                continue

            if command == "stop":
                break

            if command == "enabled":
                self.is_enabled = bool(payload)
                recognizer.reset()
                decision_queue.clear()
                freeze_remaining_frames = 0
                frozen_window_results = []
                frozen_window_queue_length = 0
                last_recognized_class_name = ""
                self._emit_status(
                    recognizer.waiting_status() if self.is_enabled else "识别结果：未开启"
                )
                continue

            if command == "stride":
                try:
                    recognizer.set_stride(int(payload))
                except ValueError as exc:
                    self.signal_error.emit(str(exc))
                    continue
                if self.is_enabled:
                    recognizer.reset()
                    decision_queue.clear()
                    freeze_remaining_frames = 0
                    frozen_window_results = []
                    frozen_window_queue_length = 0
                    last_recognized_class_name = ""
                    self._emit_status(recognizer.waiting_status())
                continue

            if command == "decision_window_size":
                try:
                    decision_window_size = self._validate_decision_window_size(int(payload))
                except ValueError as exc:
                    self.signal_error.emit(str(exc))
                    continue
                recognition_count_threshold = min(
                    int(recognition_count_threshold),
                    int(decision_window_size),
                )
                decision_queue = deque(maxlen=decision_window_size)
                freeze_remaining_frames = 0
                frozen_window_results = []
                frozen_window_queue_length = 0
                last_recognized_class_name = ""
                if self.is_enabled:
                    self._emit_status(recognizer.waiting_status())
                continue

            if command == "probability_threshold":
                try:
                    probability_threshold = self._validate_probability_threshold(float(payload))
                except ValueError as exc:
                    self.signal_error.emit(str(exc))
                    continue
                decision_queue.clear()
                freeze_remaining_frames = 0
                frozen_window_results = []
                frozen_window_queue_length = 0
                last_recognized_class_name = ""
                if self.is_enabled and recognizer.has_prediction:
                    self._emit_status("识别结果：滑窗参数已更新")
                continue

            if command == "recognition_count_threshold":
                try:
                    recognition_count_threshold = self._validate_recognition_count_threshold(
                        int(payload),
                        decision_window_size,
                    )
                except ValueError as exc:
                    self.signal_error.emit(str(exc))
                    continue
                decision_queue.clear()
                freeze_remaining_frames = 0
                frozen_window_results = []
                frozen_window_queue_length = 0
                last_recognized_class_name = ""
                if self.is_enabled and recognizer.has_prediction:
                    self._emit_status("识别结果：滑窗参数已更新")
                continue

            if command == "freeze_frames":
                try:
                    freeze_frames = self._validate_freeze_frames(int(payload))
                except ValueError as exc:
                    self.signal_error.emit(str(exc))
                continue

            if command == "reset":
                recognizer.reset()
                decision_queue.clear()
                freeze_remaining_frames = 0
                frozen_window_results = []
                frozen_window_queue_length = 0
                last_recognized_class_name = ""
                self._emit_status(
                    recognizer.waiting_status() if self.is_enabled else "识别结果：未开启"
                )
                continue

            if command != "frame" or not self.is_enabled:
                continue

            try:
                result = recognizer.ingest_frame(payload)
            except ValueError as exc:
                recognizer.reset()
                decision_queue.clear()
                freeze_remaining_frames = 0
                frozen_window_results = []
                frozen_window_queue_length = 0
                last_recognized_class_name = ""
                self._emit_status(str(exc))
                continue
            except Exception as exc:
                self.signal_error.emit(str(exc))
                continue

            if not recognizer.has_prediction:
                self._emit_status(recognizer.waiting_status())
                continue
            if result is None:
                continue

            raw_class_name = str(result.get("raw_class_name", result.get("class_name", ""))).strip()
            raw_probability = float(
                result.get("raw_probability", result.get("probability", 0.0))
            )
            counted_class_name = self._resolve_counted_class_name(
                raw_class_name=raw_class_name,
                raw_probability=raw_probability,
                probability_threshold=probability_threshold,
            )

            currently_frozen = freeze_remaining_frames > 0
            if currently_frozen:
                freeze_remaining_frames = max(0, freeze_remaining_frames - 1)

            if not currently_frozen:
                decision_queue.append(
                    {
                        "counted_class_name": counted_class_name,
                        "raw_class_name": raw_class_name,
                        "raw_probability": raw_probability,
                    }
                )

            live_payload = self._build_live_inference_payload(
                result=result,
                class_names=class_names,
                invalid_class_name=invalid_class_name,
                decision_queue=decision_queue,
                decision_window_size=decision_window_size,
                probability_threshold=probability_threshold,
                recognition_count_threshold=recognition_count_threshold,
                counted_class_name=counted_class_name,
                freeze_frames=freeze_frames,
                freeze_remaining_frames=freeze_remaining_frames,
                is_frozen=currently_frozen,
                display_window_results=frozen_window_results if currently_frozen else None,
                display_window_queue_length=(
                    frozen_window_queue_length if currently_frozen else None
                ),
            )
            self.signal_inference.emit(live_payload)

            if currently_frozen:
                self._emit_status(
                    self._format_frozen_status(
                        class_name=last_recognized_class_name,
                        freeze_remaining_frames=freeze_remaining_frames,
                        freeze_frames=freeze_frames,
                    )
                )
                continue

            finalized_result = self._maybe_finalize_window(
                result=result,
                class_names=class_names,
                invalid_class_name=invalid_class_name,
                decision_queue=decision_queue,
                decision_window_size=decision_window_size,
                probability_threshold=probability_threshold,
                recognition_count_threshold=recognition_count_threshold,
                freeze_frames=freeze_frames,
            )
            if finalized_result is not None:
                last_recognized_class_name = str(finalized_result.get("class_name", "")).strip()
                frozen_result_items = finalized_result.get("window_results", [])
                if not isinstance(frozen_result_items, list):
                    frozen_result_items = []
                frozen_window_results = [
                    dict(item)
                    for item in frozen_result_items
                    if isinstance(item, dict)
                ]
                frozen_window_queue_length = int(
                    finalized_result.get("window_queue_length", len(decision_queue))
                )
                self.signal_result.emit(finalized_result)
                decision_queue.clear()
                freeze_remaining_frames = freeze_frames
                self._last_status = ""
                continue

            self._emit_status(
                self._format_live_status(
                    decision_queue=decision_queue,
                    decision_window_size=decision_window_size,
                    recognition_count_threshold=recognition_count_threshold,
                    invalid_class_name=invalid_class_name,
                )
            )

    def _emit_status(self, text: str) -> None:
        if text == self._last_status:
            return
        self._last_status = text
        self.signal_status.emit(text)

    @staticmethod
    def _validate_decision_window_size(window_size: int) -> int:
        window_size_value = int(window_size)
        if window_size_value <= 0:
            raise ValueError(f"Decision window size must be positive, got {window_size}.")
        return window_size_value

    @staticmethod
    def _validate_probability_threshold(threshold: float) -> float:
        threshold_value = float(threshold)
        if not 0.0 <= threshold_value <= 1.0:
            raise ValueError(
                f"Probability threshold must be between 0 and 1, got {threshold}."
            )
        return threshold_value

    @staticmethod
    def _validate_recognition_count_threshold(
        threshold: int,
        decision_window_size: int,
    ) -> int:
        threshold_value = int(threshold)
        if threshold_value <= 0:
            raise ValueError(
                f"Recognition count threshold must be positive, got {threshold}."
            )
        if threshold_value > int(decision_window_size):
            raise ValueError(
                "Recognition count threshold cannot exceed the decision window size, "
                f"got {threshold_value}>{decision_window_size}."
            )
        return threshold_value

    @staticmethod
    def _validate_freeze_frames(freeze_frames: int) -> int:
        freeze_frames_value = int(freeze_frames)
        if freeze_frames_value < 0:
            raise ValueError(f"Freeze frames must be non-negative, got {freeze_frames}.")
        return freeze_frames_value

    @staticmethod
    def _resolve_invalid_class_name(candidate: str | None) -> str:
        normalized = str(candidate or "").strip()
        return normalized or "Invalid"

    @staticmethod
    def _is_invalid_class_name(class_name: str, invalid_class_name: str) -> bool:
        normalized = str(class_name).strip()
        if not normalized:
            return False
        return normalized.casefold() in INVALID_CLASS_ALIASES or normalized == invalid_class_name

    @staticmethod
    def _resolve_counted_class_name(
        *,
        raw_class_name: str,
        raw_probability: float,
        probability_threshold: float,
    ) -> str:
        normalized_class_name = str(raw_class_name).strip()
        if not normalized_class_name:
            return ""
        if float(raw_probability) < float(probability_threshold):
            return ""
        return normalized_class_name

    @staticmethod
    def _build_window_counts(
        *,
        class_names: list[str],
        decision_queue: deque[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        counter = Counter(
            str(item.get("counted_class_name", "")).strip()
            for item in decision_queue
            if str(item.get("counted_class_name", "")).strip()
        )
        return [
            {
                "class_name": class_name,
                "count": int(counter.get(class_name, 0)),
            }
            for class_name in class_names
        ]

    @staticmethod
    def _build_window_results(decision_queue: deque[dict[str, Any]]) -> list[dict[str, Any]]:
        """提取滑窗内每一次模型推理结果，供界面完整展示类别和概率。"""
        window_results: list[dict[str, Any]] = []
        for item in decision_queue:
            class_name = str(item.get("raw_class_name", "")).strip()
            if not class_name:
                continue
            window_results.append(
                {
                    "class_name": class_name,
                    "probability": float(item.get("raw_probability", 0.0)),
                }
            )
        return window_results

    def _build_live_inference_payload(
        self,
        *,
        result: dict[str, Any],
        class_names: list[str],
        invalid_class_name: str,
        decision_queue: deque[dict[str, Any]],
        decision_window_size: int,
        probability_threshold: float,
        recognition_count_threshold: int,
        counted_class_name: str,
        freeze_frames: int,
        freeze_remaining_frames: int,
        is_frozen: bool,
        display_window_results: list[dict[str, Any]] | None = None,
        display_window_queue_length: int | None = None,
    ) -> dict[str, Any]:
        queue_snapshot = list(decision_queue)
        window_counts = self._build_window_counts(
            class_names=class_names,
            decision_queue=decision_queue,
        )
        window_results = self._build_window_results(decision_queue)
        display_results = (
            window_results
            if display_window_results is None
            else display_window_results
        )
        display_queue_length = (
            len(queue_snapshot)
            if display_window_queue_length is None
            else int(display_window_queue_length)
        )
        top_class_name, top_count = self._resolve_top_count(
            class_names=class_names,
            invalid_class_name=invalid_class_name,
            window_counts=window_counts,
        )
        return {
            "raw_class_name": str(result.get("raw_class_name", result.get("class_name", ""))),
            "raw_probability": float(
                result.get("raw_probability", result.get("probability", 0.0))
            ),
            "counted_class_name": counted_class_name,
            "counted": bool(counted_class_name),
            "probabilities": list(result.get("probabilities", [])),
            "window_counts": window_counts,
            "window_results": display_results,
            "window_queue_length": display_queue_length,
            "decision_window_size": int(decision_window_size),
            "probability_threshold": float(probability_threshold),
            "recognition_count_threshold": int(recognition_count_threshold),
            "freeze_frames": int(freeze_frames),
            "freeze_remaining_frames": int(freeze_remaining_frames),
            "is_frozen": bool(is_frozen),
            "top_class_name": top_class_name,
            "top_count": int(top_count),
        }

    def _resolve_top_count(
        self,
        *,
        class_names: list[str],
        invalid_class_name: str,
        window_counts: list[dict[str, Any]],
    ) -> tuple[str, int]:
        ranked_candidates: list[tuple[str, int]] = []
        for item in window_counts:
            if not isinstance(item, dict):
                continue
            class_name = str(item.get("class_name", "")).strip()
            count = int(item.get("count", 0))
            if not class_name or count <= 0:
                continue
            if self._is_invalid_class_name(class_name, invalid_class_name):
                continue
            ranked_candidates.append((class_name, count))

        ranked_candidates.sort(
            key=lambda item: (
                -item[1],
                class_names.index(item[0]) if item[0] in class_names else len(class_names),
            )
        )
        if not ranked_candidates:
            return "", 0
        return ranked_candidates[0]

    def _maybe_finalize_window(
        self,
        *,
        result: dict[str, Any],
        class_names: list[str],
        invalid_class_name: str,
        decision_queue: deque[dict[str, Any]],
        decision_window_size: int,
        probability_threshold: float,
        recognition_count_threshold: int,
        freeze_frames: int,
    ) -> dict[str, Any] | None:
        window_counts = self._build_window_counts(
            class_names=class_names,
            decision_queue=decision_queue,
        )
        winner_class_name, winner_count = self._resolve_top_count(
            class_names=class_names,
            invalid_class_name=invalid_class_name,
            window_counts=window_counts,
        )
        if not winner_class_name or winner_count < recognition_count_threshold:
            return None

        matched_probabilities = [
            float(item.get("raw_probability", 0.0))
            for item in decision_queue
            if str(item.get("counted_class_name", "")).strip() == winner_class_name
        ]
        aggregated_probability = (
            float(sum(matched_probabilities) / len(matched_probabilities))
            if matched_probabilities
            else float(result.get("raw_probability", result.get("probability", 0.0)))
        )

        finalized_result = dict(result)
        finalized_result["class_name"] = winner_class_name
        finalized_result["probability"] = aggregated_probability
        finalized_result["trigger_count"] = int(winner_count)
        finalized_result["decision_window_size"] = int(decision_window_size)
        finalized_result["window_queue_length"] = len(decision_queue)
        finalized_result["window_counts"] = window_counts
        finalized_result["window_results"] = self._build_window_results(decision_queue)
        finalized_result["probability_threshold"] = float(probability_threshold)
        finalized_result["recognition_count_threshold"] = int(recognition_count_threshold)
        finalized_result["freeze_frames"] = int(freeze_frames)
        finalized_result["window_finalized"] = True
        finalized_result["model_output_class_name"] = str(
            result.get("raw_class_name", result.get("class_name", ""))
        )
        return finalized_result

    def _format_live_status(
        self,
        *,
        decision_queue: deque[dict[str, Any]],
        decision_window_size: int,
        recognition_count_threshold: int,
        invalid_class_name: str,
    ) -> str:
        unique_class_names = list(
            dict.fromkeys(
                str(item.get("counted_class_name", "")).strip()
                for item in decision_queue
                if str(item.get("counted_class_name", "")).strip()
            )
        )
        window_counts = self._build_window_counts(
            class_names=unique_class_names,
            decision_queue=decision_queue,
        )
        winner_class_name, winner_count = self._resolve_top_count(
            class_names=unique_class_names,
            invalid_class_name=invalid_class_name,
            window_counts=window_counts,
        )
        queue_length = len(decision_queue)
        if winner_class_name:
            return (
                "识别结果：滑窗判定中 "
                f"({queue_length}/{decision_window_size}, "
                f"{winner_class_name} {winner_count}/{recognition_count_threshold})"
            )
        return f"识别结果：滑窗判定中 ({queue_length}/{decision_window_size})"

    @staticmethod
    def _format_frozen_status(
        *,
        class_name: str,
        freeze_remaining_frames: int,
        freeze_frames: int,
    ) -> str:
        normalized_class_name = str(class_name).strip()
        if normalized_class_name:
            return (
                f"识别结果：{normalized_class_name}，冻结中 "
                f"({freeze_remaining_frames}/{freeze_frames})"
            )
        return f"识别结果：冻结中 ({freeze_remaining_frames}/{freeze_frames})"
