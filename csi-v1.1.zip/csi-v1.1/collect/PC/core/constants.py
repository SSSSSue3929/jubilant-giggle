"""重构版 ESP-CSI 上位机的共享常量定义。"""

from pathlib import Path


# 设备上报的 CSI CSV 列顺序必须与固件输出保持一致，后续写盘和解析都依赖这一顺序。
CSI_DATA_COLUMNS_NAMES = [
    "type",
    "seq",
    "timestamp",
    "target_seq",
    "target",
    "mac",
    "rssi",
    "rate",
    "sig_mode",
    "mcs",
    "cwb",
    "smoothing",
    "not_sounding",
    "aggregation",
    "stbc",
    "fec_coding",
    "sgi",
    "noise_floor",
    "ampdu_cnt",
    "channel_primary",
    "channel_secondary",
    "local_timestamp",
    "ant",
    "sig_len",
    "rx_state",
    "agc_gain",
    "fft_gain",
    "len",
    "first_word_invalid",
    "data",
]

# CSI 处理链路的基础采样配置。
CSI_SAMPLE_RATE = 100
CSI_BUFFER_SIZE = 500
CSI_SUBCARRIER_NUM_ALL = 26
CSI_VALID_SUBCARRIER_MIN = 1
CSI_VALID_SUBCARRIER_MAX = CSI_VALID_SUBCARRIER_MIN + CSI_SUBCARRIER_NUM_ALL - 1
DEFAULT_VALID_SUBCARRIERS = list(range(CSI_VALID_SUBCARRIER_MIN, CSI_VALID_SUBCARRIER_MAX + 1))

# 低通滤波器参数与 raw 参考工具保持一致。
FILTER_ORDER = 8
FILTER_CUTOFF_HZ = 20

# 串口连接配置。
SERIAL_BAUDRATE = 2_000_000
SERIAL_TIMEOUT = 0.1

# 统一维护各类日志根目录，避免路径散落在业务代码中。
LOG_ROOT = Path("log_csi")
RUNTIME_LOG_ROOT = LOG_ROOT

# 采集数据与采集备注文件路径。
COLLECT_ROOT = Path("collect")
COLLECT_DATA_ROOT = COLLECT_ROOT
COLLECT_REMARK_FILE = COLLECT_ROOT / "remark.csv"

# 界面启动时默认使用的 CSI 输出类型与显示单位。
DEFAULT_CSI_OUTPUT_TYPE = "LLTF"
DEFAULT_UNIT = "raw"
