"""各模块共享的轻量文件与解码工具。"""

from __future__ import annotations

import base64
import csv
import re
from pathlib import Path
from typing import Iterable


LOG_PATTERNS = [
    r"->valid_len",
    r":\s*\d+",
    r"\(\d+\)",
    r"[DIWE]\s*\(",
]


def ensure_dir(path_like: str | Path) -> Path:
    """在目录不存在时自动创建，并返回对应的 Path 对象。"""
    path = Path(path_like)
    path.mkdir(parents=True, exist_ok=True)
    return path


def clean_base64_payload(raw_text: str) -> str:
    """清理 base64 载荷中的空白字符和尾部日志碎片。"""
    # 设备输出中可能夹带换行、空格或后续日志片段，先统一清洗。
    payload = str(raw_text).strip().replace("\n", "").replace("\r", "").replace(" ", "")
    min_log_start = len(payload)
    for pattern in LOG_PATTERNS:
        # 一旦发现日志特征片段，就截断掉后续内容，避免污染 base64 解码。
        match = re.search(pattern, payload)
        if match:
            min_log_start = min(min_log_start, match.start())

    if 10 < min_log_start < len(payload):
        payload = payload[:min_log_start]

    # base64 长度必须是 4 的倍数，不足时自动补齐等号。
    missing_padding = len(payload) % 4
    if missing_padding:
        payload += "=" * (4 - missing_padding)
    return payload


def base64_decode_bin(raw_text: str) -> list[int]:
    """把 CSI 的 base64 字符串解码为有符号 8 位整数列表。"""
    payload = clean_base64_payload(raw_text)
    try:
        decoded = base64.b64decode(payload, validate=True)
    except Exception:
        # 遇到非法载荷时直接返回空列表，由上层决定是否丢弃该帧。
        return []

    values = list(decoded)
    # 串口原始字节需要还原为有符号 8 位整数，便于后续幅值计算。
    return [value - 256 if value > 127 else value for value in values]


def append_csv_row(file_path: str | Path, header: Iterable[str], data_row: Iterable[object]) -> None:
    """追加一行 CSV 数据，并在首次写入时自动补齐表头。"""
    path = Path(file_path)
    if path.parent:
        ensure_dir(path.parent)

    file_exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as file_obj:
        writer = csv.writer(file_obj)
        if not file_exists:
            # 首次创建文件时先写入表头，保证后续直接可被 pandas 等工具读取。
            writer.writerow(list(header))
        # 统一转成字符串写入，避免混入 Path、datetime 等对象导致序列化不一致。
        writer.writerow([str(item) for item in data_row])
