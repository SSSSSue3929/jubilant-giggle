"""业务层 CSI 解码与滤波处理。"""

from __future__ import annotations

import threading

import numpy as np
from scipy import signal

from core.constants import (
    CSI_BUFFER_SIZE,
    CSI_SAMPLE_RATE,
    DEFAULT_UNIT,
    DEFAULT_VALID_SUBCARRIERS,
    FILTER_CUTOFF_HZ,
    FILTER_ORDER,
)


class CsiBufferProcessor:
    """维护 CSI 滚动缓冲区，并根据开关决定是否执行低通滤波。"""

    def __init__(
        self,
        buffer_size: int = CSI_BUFFER_SIZE,
        sample_rate: int = CSI_SAMPLE_RATE,
        valid_subcarriers: list[int] | None = None,
        display_unit: str = DEFAULT_UNIT,
        filter_enabled: bool = False,
    ) -> None:
        # 记录缓冲区长度和采样率，滤波系数与数组尺寸都依赖这两个值。
        self.buffer_size = buffer_size
        self.sample_rate = sample_rate
        # 记录当前显示单位和滤波开关状态，便于 UI 动态切换。
        self.display_unit = display_unit
        self.filter_enabled = filter_enabled
        # 保存当前启用的子载波序号列表。
        self.valid_subcarriers = list(valid_subcarriers or DEFAULT_VALID_SUBCARRIERS)
        # 预先生成低通滤波器系数，避免每个 CSI 包都重复设计滤波器。
        self._filter_b, self._filter_a = signal.butter(
            FILTER_ORDER,
            FILTER_CUTOFF_HZ / (sample_rate / 2),
            "lowpass",
        )
        # 处理线程和 UI 线程会共享数据，因此使用互斥锁保护内部状态。
        self._lock = threading.Lock()
        # 初始化内部缓冲区。
        self._reset_buffers()

    def _reset_buffers(self) -> None:
        # 原始幅值缓冲区保存最近一段 CSI 幅值序列。
        self.amplitude_buffer = np.zeros(
            (self.buffer_size, len(self.valid_subcarriers)),
            dtype=np.float64,
        )
        # 处理后缓冲区保存“原始或滤波后”的最终波形。
        self.processed_buffer = np.zeros_like(self.amplitude_buffer)
        # 预留 RSSI 缓冲区，便于后续扩展更多联动分析。
        self.rssi_buffer = np.zeros(self.buffer_size, dtype=np.float64)

    def set_valid_subcarriers(self, valid_subcarriers: list[int]) -> np.ndarray:
        """切换子载波配置，并返回重置后的当前显示波形。"""
        with self._lock:
            # 保存新的子载波列表。
            self.valid_subcarriers = list(valid_subcarriers)
            # 子载波数量变化后，原缓冲区尺寸已经不再匹配，需要整体重置。
            self._reset_buffers()
            return self._current_display_waveform()

    def set_display_unit(self, display_unit: str) -> np.ndarray:
        """切换显示单位，并返回单位转换后的当前波形。"""
        with self._lock:
            # 仅更新显示层的单位，不改变内部保存的原始/处理后数据。
            self.display_unit = display_unit
            return self._current_display_waveform()

    def set_filter_enabled(self, enabled: bool) -> np.ndarray:
        """切换低通滤波状态，并返回当前开关对应的波形。"""
        with self._lock:
            # 记录新的滤波开关状态。
            self.filter_enabled = enabled
            # 基于当前缓冲区重新生成处理结果，保证 UI 能即时刷新。
            self._refresh_processed_buffer()
            return self._current_display_waveform()

    def append_csi_event(self, event: dict) -> np.ndarray:
        """写入一个新的 CSI 事件，并返回当前用于显示的波形。"""
        # 先把原始字节数组解码成当前子载波范围内的幅值向量。
        amplitudes = self._decode_amplitudes(event["data"], int(event["len"]))
        if amplitudes is None:
            # 解码失败时不破坏现有缓冲区，直接返回当前快照。
            return self.snapshot()

        with self._lock:
            # 整体左移缓冲区，为最新数据腾出最后一行。
            self.amplitude_buffer[:-1] = self.amplitude_buffer[1:]
            # 把最新 CSI 幅值写入缓冲区末尾。
            self.amplitude_buffer[-1] = amplitudes
            # RSSI 也同步左移，保持与 CSI 波形时间对齐。
            self.rssi_buffer[:-1] = self.rssi_buffer[1:]
            # 当前项目暂时只绘制 CSI，但仍保留 RSSI 以便后续扩展。
            self.rssi_buffer[-1] = float(event.get("rssi", 0) or 0)
            # 根据当前滤波开关刷新处理结果。
            self._refresh_processed_buffer()
            return self._current_display_waveform()

    def snapshot(self) -> np.ndarray:
        """返回当前显示状态下的波形副本。"""
        with self._lock:
            return self._current_display_waveform()

    def build_waveform_from_events(self, events: list[dict]) -> np.ndarray:
        """基于一批 CSI 事件构建完整波形，供导入分析等离线场景复用。"""
        if not events:
            return np.zeros((0, len(self.valid_subcarriers)), dtype=np.float64)

        waveform = np.zeros((len(events), len(self.valid_subcarriers)), dtype=np.float64)
        for row_index, event in enumerate(events):
            amplitudes = self._decode_amplitudes(event["data"], int(event["len"]))
            if amplitudes is not None:
                waveform[row_index] = amplitudes

        if self.filter_enabled:
            waveform = self._apply_filter(waveform)
        return self._to_display_unit(waveform)

    def _refresh_processed_buffer(self) -> None:
        """根据滤波开关刷新最终用于显示的处理结果。"""
        if self.filter_enabled:
            # 选中低通滤波时，执行与参考工具一致的中值修正 + 低通滤波。
            self.processed_buffer = self._apply_filter(self.amplitude_buffer)
        else:
            # 未选中时保持原始幅值，仅复制一份供 UI 使用。
            self.processed_buffer = self.amplitude_buffer.copy()

    def _current_display_waveform(self) -> np.ndarray:
        """返回按当前显示单位转换后的波形副本。"""
        return self._to_display_unit(self.processed_buffer).copy()

    def _decode_amplitudes(self, csi_raw_data: list[int], data_len: int) -> np.ndarray | None:
        """将设备上传的 CSI 原始数组解码为幅值向量。"""
        if data_len <= 0:
            return None

        # 为当前所有有效子载波预先分配输出数组。
        amplitudes = np.zeros(len(self.valid_subcarriers), dtype=np.float64)
        effective_len = min(len(csi_raw_data), data_len)
        if effective_len <= 0:
            return None

        if data_len == 104:
            # 恢复 77ee954 版本的 LLTF 解码方式：4 字节表示 1 个复数子载波。
            for column, index in enumerate(self.valid_subcarriers):
                sample_index = index - 1
                if sample_index < 0:
                    return None

                data_index = sample_index * 4
                # 一旦越界，说明本帧数据不完整，直接放弃本次更新。
                if data_index + 3 >= effective_len:
                    return None

                # 依次取出实部和虚部的高低字节。
                real_high = csi_raw_data[data_index + 1]
                imag_high = csi_raw_data[data_index + 3]
                real_low = csi_raw_data[data_index] & 0xFF
                imag_low = csi_raw_data[data_index + 2] & 0xFF

                # 按原协议将高低位拼成 16 位有符号整数。
                real = (((int(real_high) << 12) >> 4) | real_low)
                imag = (((int(imag_high) << 12) >> 4) | imag_low)

                # 把超过 32767 的值还原为负数。
                if real > 32767:
                    real -= 65536
                if imag > 32767:
                    imag -= 65536

                # 复数模值就是当前子载波的幅值。
                amplitudes[column] = np.abs(complex(real, imag))

            return amplitudes

        for column, index in enumerate(self.valid_subcarriers):
            sample_index = index - 1
            if sample_index < 0:
                return None

            data_index = sample_index * 2
            # 每个复数样本都需要连续的实部、虚部两个字节。
            if data_index + 1 >= effective_len:
                return None

            real = csi_raw_data[data_index]
            imag = csi_raw_data[data_index + 1]
            amplitudes[column] = np.abs(complex(real, imag))

        return amplitudes

    def _apply_filter(self, waveform: np.ndarray) -> np.ndarray:
        """执行与参考工具一致的中值修正和 Butterworth 低通滤波。"""
        # 先修正明显离群的整行采样点，避免尖峰影响后续低通结果。
        median_filtered = self._median_filtering(waveform)
        try:
            # 按列滤波，因此先转置到“子载波在行、时间在列”的形式，再转回。
            return signal.filtfilt(self._filter_b, self._filter_a, median_filtered.T).T
        except ValueError:
            # 缓冲区样本数不足时，直接返回中值修正结果。
            return median_filtered

    @staticmethod
    def _median_filtering(waveform: np.ndarray) -> np.ndarray:
        """复刻参考工具中的离群点修正规则。"""
        # 复制一份数组，避免直接污染输入数据。
        filtered = waveform.copy()
        # 首尾两行缺少前后邻居，不参与离群检测。
        for row_index in range(1, waveform.shape[0] - 1):
            outliers_count = 0
            # 逐列统计当前时刻是否在大量子载波上同时表现为尖峰。
            for column_index in range(waveform.shape[1]):
                current_value = waveform[row_index, column_index]
                prev_delta = waveform[row_index - 1, column_index] - current_value
                next_delta = waveform[row_index + 1, column_index] - current_value
                if (prev_delta > 2 and next_delta > 2) or (prev_delta < -2 and next_delta < -2):
                    outliers_count += 1

            # 当整行超过阈值时，用前后两行均值替换这一行。
            if outliers_count > 16:
                for column_index in range(1, waveform.shape[1] - 1):
                    filtered[row_index, column_index] = (
                        waveform[row_index - 1, column_index] + waveform[row_index + 1, column_index]
                    ) / 2
        return filtered

    def _to_display_unit(self, waveform: np.ndarray) -> np.ndarray:
        """把内部幅值转换成 UI 需要显示的单位。"""
        if self.display_unit.lower() == "db":
            # 对数运算前先做下限保护，避免出现 log(0)。
            safe_waveform = np.maximum(waveform, 1e-6)
            return 20 * np.log10(safe_waveform)
        # raw 模式下直接返回原始幅值。
        return waveform
