# collect/PC

`collect/PC` 是 CSI 采集与实时识别的 PC 端上位机项目，负责串口连接、波形显示、样本采集、导入分析和模型推理。

## 主要用途

- 启动 PyQt 上位机并连接 ESP32-C5 设备。
- 实时显示 CSI 波形，保存采集样本和备注信息。
- 加载 `recognition` 训练得到的模型进行实时识别。

## 用法

启动上位机：

```powershell
conda run -n esp-csi python ".\collect\PC\esp_csi_tool.py"
```

说明：

- `model/best_model.pt` 可替换为训练生成的实时识别模型。
- `dataset/` 为本地样本缓存目录，默认不提交到远程仓库。
- `collect/`、`log_csi/` 为运行期输出目录。

## 目录结构

```text
collect/PC/                         # PC 端上位机项目
├── collect/                        # 采集样本输出目录
├── config/                         # 上位机配置文件
├── core/                           # CSI 处理与公共逻辑
├── dataset/                        # 本地样本目录，占位后默认忽略
├── drivers/                        # 串口、语音等驱动封装
├── log_csi/                        # 运行日志与辅助输出
├── model/                          # 识别模型与运行时加载逻辑
├── ui/                             # 主窗口、界面资源与识别线程
└── esp_csi_tool.py                 # 上位机启动入口
```
