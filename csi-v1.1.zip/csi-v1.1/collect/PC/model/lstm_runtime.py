"""LSTM 运行期推理模块。

该模块负责读取训练阶段保存的 checkpoint，恢复标准化参数与模型结构，
并把连续 CSI 帧组织成滑动窗口，输出当前窗口的动作识别结果。
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Any

import numpy as np
import torch
from scipy import signal
from torch import nn

# 运行期需要同时访问仓库根目录下的共享配置，以及当前上位机目录下的本地模块。
# 运行期需要同时访问仓库根目录下的共享配置。
PROJECT_ROOT = Path(__file__).resolve().parents[3]
PROJECT_ROOT = Path(__file__).resolve().parents[3]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))
# 当前目录下还保留了上位机自身的本地模块。
COLLECT_PC_TOOL_ROOT = Path(__file__).resolve().parents[1]
COLLECT_PC_TOOL_ROOT = Path(__file__).resolve().parents[1]
if str(COLLECT_PC_TOOL_ROOT) not in sys.path:
    sys.path.insert(0, str(COLLECT_PC_TOOL_ROOT))

from class_config import validate_runtime_class_count
from model_input_config import (
    format_model_input_shape,
    get_model_decoded_feature_dim,
    get_model_raw_feature_dim,
    get_model_sequence_length,
)
from recognition.model_registry import (
    get_model_class,
    normalize_model_type as normalize_registered_model_type,
)

DEFAULT_NON_INVALID_CONFIDENCE_THRESHOLD = 0.9631
INVALID_CLASS_ALIASES = {"invalid", "invaild"}
UI_OUTLIER_DELTA = 2.0
UI_OUTLIER_ROW_THRESHOLD = 16


class CSILSTMClassifier(nn.Module):
    """与训练脚本保持一致的 LSTM 分类器结构。"""

    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        num_layers: int,
        num_classes: int,
        dropout: float,
    ) -> None:
        """根据 checkpoint 中的超参数重建推理期网络。"""
        super().__init__()
        lstm_dropout = dropout if num_layers > 1 else 0.0
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=lstm_dropout,
        )
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """执行一次前向传播，并兼容两种常见输入张量形状。"""
        if x.ndim == 4:
            if x.size(1) != 1:
                raise ValueError(
                    f"Expected a single CSI channel, got input shape {tuple(x.shape)}."
                )
            x = x[:, 0, :, :]
        elif x.ndim != 3:
            raise ValueError(
                "Expected input shape [batch, seq, feat] or [batch, 1, seq, feat], "
                f"got {tuple(x.shape)}."
            )

        output, _ = self.lstm(x)
        output = output[:, -1, :]
        output = self.relu(output)
        output = self.dropout(output)
        return self.fc(output)


class CSICNNLSTMClassifier(nn.Module):
    """与训练端 CNN-LSTM 保持一致的运行期分类器结构。"""

    def __init__(
        self,
        input_size: int,
        cnn_channels: int = 64,
        hidden_size: int = 128,
        num_layers: int = 2,
        num_classes: int = 5,
        dropout: float = 0.3,
        kernel_size: int = 5,
    ) -> None:
        super().__init__()
        if kernel_size <= 0 or kernel_size % 2 == 0:
            raise ValueError(f"kernel_size must be a positive odd number, got {kernel_size}.")

        padding = kernel_size // 2
        lstm_dropout = dropout if num_layers > 1 else 0.0
        # CNN 先沿时间轴提取局部波形模式，再交给 LSTM 建模动作时序。
        self.cnn = nn.Sequential(
            nn.Conv1d(
                in_channels=input_size,
                out_channels=cnn_channels,
                kernel_size=kernel_size,
                padding=padding,
            ),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(
                in_channels=cnn_channels,
                out_channels=cnn_channels,
                kernel_size=3,
                padding=1,
            ),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
        )
        self.lstm = nn.LSTM(
            input_size=cnn_channels,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=lstm_dropout,
        )
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(hidden_size, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """执行一次前向推理，并返回各类别 logits。"""
        if x.ndim == 4:
            if x.size(1) != 1:
                raise ValueError(
                    f"Expected a single CSI channel, got input shape {tuple(x.shape)}."
                )
            x = x[:, 0, :, :]
        elif x.ndim != 3:
            raise ValueError(
                "Expected input shape [batch, seq, feat] or [batch, 1, seq, feat], "
                f"got {tuple(x.shape)}."
            )

        local_features = self.cnn(x.transpose(1, 2))
        sequence_features = local_features.transpose(1, 2)
        output, _ = self.lstm(sequence_features)
        output = self.dropout(output[:, -1, :])
        return self.fc(output)


class CSIDeepNetClassifier(get_model_class("csi-deepnet")):
    """通过共享模型注册表动态加载 CSI-DeepNet 结构。"""


RUNTIME_MODEL_REGISTRY: dict[str, type[nn.Module]] = {
    "lstm": CSILSTMClassifier,
    "cnn-lstm": CSICNNLSTMClassifier,
    "csi-deepnet": CSIDeepNetClassifier,
}


def normalize_runtime_model_type(model_type: object) -> str:
    """把 checkpoint 中的模型类型统一成运行期可识别的键名。"""
    return normalize_registered_model_type(model_type)


def infer_runtime_model_type(checkpoint: dict[str, Any]) -> str:
    """优先读取 checkpoint 元数据；旧模型没有元数据时根据权重名兜底判断。"""
    checkpoint_model_type = str(checkpoint.get("model_type", "")).strip()
    if checkpoint_model_type:
        return normalize_runtime_model_type(checkpoint_model_type)

    state_dict = checkpoint.get("model_state_dict", {})
    if isinstance(state_dict, dict) and any(str(key).startswith("cnn.") for key in state_dict):
        return "cnn-lstm"
    if isinstance(state_dict, dict) and any(str(key).startswith("stem.") for key in state_dict):
        return "csi-deepnet"
    return "lstm"


@dataclass
class FeatureNormalizer:
    """保存训练期统计到的均值与标准差，用于运行期标准化。"""

    mean: np.ndarray
    std: np.ndarray

    @classmethod
    def from_checkpoint(cls, payload: dict[str, Any]) -> "FeatureNormalizer":
        """从 checkpoint 字典中恢复标准化器。"""
        mean = np.asarray(payload["mean"], dtype=np.float32)
        std = np.asarray(payload["std"], dtype=np.float32)
        std = np.where(std < 1e-6, 1.0, std)
        return cls(mean=mean, std=std)

    def transform(self, sample: np.ndarray) -> np.ndarray:
        """按训练期统计量对单个窗口做逐特征标准化。"""
        return (sample - self.mean) / self.std


@dataclass
class RuntimePreprocessor:
    """Restore the training-time CSI preprocessing path for live inference."""

    model_input_dim: int
    raw_feature_dim: int
    decoded_feature_dim: int
    decode_mode: str | None
    baseline_frames: int
    filter_b: np.ndarray | None
    filter_a: np.ndarray | None
    use_filter: bool
    use_front_static_baseline: bool

    @classmethod
    def from_checkpoint(
        cls,
        *,
        model_input_dim: int,
        payload: dict[str, Any] | None,
    ) -> "RuntimePreprocessor":
        if not isinstance(payload, dict):
            return cls(
                model_input_dim=model_input_dim,
                raw_feature_dim=get_model_raw_feature_dim(),
                decoded_feature_dim=model_input_dim,
                decode_mode=None,
                baseline_frames=0,
                filter_b=None,
                filter_a=None,
                use_filter=False,
                use_front_static_baseline=False,
            )

        raw_feature_dim = int(payload.get("raw_feature_dim", get_model_raw_feature_dim()))
        decoded_feature_dim = int(payload.get("feature_dim", model_input_dim))
        if decoded_feature_dim != model_input_dim:
            raise ValueError(
                "Checkpoint preprocessing metadata is inconsistent: "
                f"feature_dim={decoded_feature_dim}, input_size={model_input_dim}."
            )

        filter_payload = payload.get("filter")
        filter_b: np.ndarray | None = None
        filter_a: np.ndarray | None = None
        use_filter = False
        if isinstance(filter_payload, dict) and filter_payload.get("name") == "ui_lowpass":
            sample_rate_hz = float(filter_payload.get("sample_rate_hz", 100))
            order = int(filter_payload.get("order", 8))
            cutoff_hz = float(filter_payload.get("cutoff_hz", 20))
            if sample_rate_hz <= 0 or cutoff_hz <= 0:
                raise ValueError("Checkpoint preprocessing filter metadata is invalid.")
            filter_b, filter_a = signal.butter(
                order,
                cutoff_hz / (sample_rate_hz / 2),
                "lowpass",
            )
            use_filter = True

        baseline_frames = 0
        use_front_static_baseline = False
        sample_baseline_payload = payload.get("sample_baseline")
        if isinstance(sample_baseline_payload, dict):
            baseline_mode = str(sample_baseline_payload.get("mode", "")).strip()
            apply_after_filter = bool(sample_baseline_payload.get("apply_after_filter", False))
            if baseline_mode == "per_sample_front_static" and apply_after_filter:
                baseline_frames = int(sample_baseline_payload.get("frames", 0) or 0)
                use_front_static_baseline = baseline_frames > 0

        return cls(
            model_input_dim=model_input_dim,
            raw_feature_dim=raw_feature_dim,
            decoded_feature_dim=decoded_feature_dim,
            decode_mode=str(payload.get("decode_mode", "")).strip() or None,
            baseline_frames=baseline_frames,
            filter_b=filter_b,
            filter_a=filter_a,
            use_filter=use_filter,
            use_front_static_baseline=use_front_static_baseline,
        )

    def expected_runtime_feature_counts(self) -> tuple[int, ...]:
        counts = [self.raw_feature_dim]
        if self.decoded_feature_dim not in counts:
            counts.append(self.decoded_feature_dim)
        return tuple(counts)

    def coerce_runtime_frame(self, frame: Any) -> tuple[np.ndarray, int]:
        if isinstance(frame, dict):
            raw_values = frame.get("data", [])
            declared_len = int(frame.get("len", 0) or 0)
        else:
            raw_values = frame
            declared_len = 0

        vector = np.asarray(raw_values, dtype=np.float32).reshape(-1)
        feature_count = int(vector.size)
        if feature_count <= 0:
            raise ValueError("CSI frame is empty.")

        effective_len = declared_len if declared_len > 0 else feature_count
        effective_len = min(effective_len, feature_count)
        if effective_len in self.expected_runtime_feature_counts():
            return vector[:effective_len].astype(np.float32, copy=True), effective_len

        expected = "/".join(str(count) for count in self.expected_runtime_feature_counts())
        raise ValueError(f"Expected {expected} runtime CSI values, got {feature_count}.")

    def preprocess_window(self, frames: list[tuple[np.ndarray, int]]) -> np.ndarray:
        if not frames:
            raise ValueError("Cannot preprocess an empty CSI window.")

        decoded_window = np.stack(
            [self._decode_runtime_frame(values, data_len) for values, data_len in frames],
            axis=0,
        ).astype(np.float32)

        processed_window = decoded_window
        if self.use_filter:
            processed_window = self._apply_ui_lowpass_filter(processed_window)
        if self.use_front_static_baseline:
            baseline = self._estimate_front_static_baseline(processed_window)
            processed_window = processed_window - baseline
        return processed_window.astype(np.float32)

    def decode_runtime_frame(self, frame: Any) -> np.ndarray:
        """Decode a single runtime CSI frame into the model feature layout."""
        values, data_len = self.coerce_runtime_frame(frame)
        return self._decode_runtime_frame(values, data_len).astype(np.float32, copy=False)

    def _decode_runtime_frame(self, values: np.ndarray, data_len: int) -> np.ndarray:
        if data_len == self.decoded_feature_dim:
            return values[: self.decoded_feature_dim].astype(np.float32, copy=False)
        if data_len != self.raw_feature_dim:
            raise ValueError(
                f"Expected runtime frame length {self.raw_feature_dim} or {self.decoded_feature_dim}, "
                f"got {data_len}."
            )

        if self.decode_mode in {
            "esp_csi_tool_104_bytes_to_26_amplitudes",
            "esp_csi_tool_raw_bytes_to_amplitudes",
        }:
            return self._decode_esp_csi_tool_frame(values)

        if self.raw_feature_dim == self.decoded_feature_dim:
            return values[: self.decoded_feature_dim].astype(np.float32, copy=False)

        raise ValueError(f"Unsupported runtime decode mode: {self.decode_mode!r}.")

    def _decode_esp_csi_tool_frame(self, values: np.ndarray) -> np.ndarray:
        amplitudes = np.zeros(self.decoded_feature_dim, dtype=np.float32)
        for subcarrier_index in range(self.decoded_feature_dim):
            data_index = subcarrier_index * 4
            real_high = int(values[data_index + 1])
            imag_high = int(values[data_index + 3])
            real_low = int(values[data_index]) & 0xFF
            imag_low = int(values[data_index + 2]) & 0xFF

            real = (((real_high << 12) >> 4) | real_low)
            imag = (((imag_high << 12) >> 4) | imag_low)
            if real > 32767:
                real -= 65536
            if imag > 32767:
                imag -= 65536

            amplitudes[subcarrier_index] = float(np.abs(complex(real, imag)))
        return amplitudes

    def _apply_ui_lowpass_filter(self, waveform: np.ndarray) -> np.ndarray:
        if self.filter_b is None or self.filter_a is None:
            return waveform.astype(np.float32, copy=False)

        median_filtered = self._median_filter_waveform(waveform)
        try:
            return signal.filtfilt(self.filter_b, self.filter_a, median_filtered.T).T.astype(
                np.float32
            )
        except ValueError:
            return median_filtered.astype(np.float32)

    def _estimate_front_static_baseline(self, waveform: np.ndarray) -> np.ndarray:
        window_size = min(int(self.baseline_frames), int(waveform.shape[0]))
        if window_size <= 0:
            raise ValueError("Cannot estimate a baseline from an empty CSI window.")
        return np.median(waveform[:window_size], axis=0).astype(np.float32)

    @staticmethod
    def _median_filter_waveform(waveform: np.ndarray) -> np.ndarray:
        filtered = waveform.copy()
        for row_index in range(1, waveform.shape[0] - 1):
            outliers_count = 0
            for column_index in range(waveform.shape[1]):
                current_value = waveform[row_index, column_index]
                prev_delta = waveform[row_index - 1, column_index] - current_value
                next_delta = waveform[row_index + 1, column_index] - current_value
                if (
                    (prev_delta > UI_OUTLIER_DELTA and next_delta > UI_OUTLIER_DELTA)
                    or (prev_delta < -UI_OUTLIER_DELTA and next_delta < -UI_OUTLIER_DELTA)
                ):
                    outliers_count += 1

            if outliers_count > UI_OUTLIER_ROW_THRESHOLD:
                for column_index in range(1, waveform.shape[1] - 1):
                    filtered[row_index, column_index] = (
                        waveform[row_index - 1, column_index] + waveform[row_index + 1, column_index]
                    ) / 2
        return filtered


class LstmSlidingWindowRecognizer:
    """加载 checkpoint，并以滑动窗口方式持续执行 CSI 推理。"""

    def __init__(
        self,
        checkpoint_path: Path,
        stride: int = 65,
        non_invalid_confidence_threshold: float = DEFAULT_NON_INVALID_CONFIDENCE_THRESHOLD,
        device: str | None = None,
    ) -> None:
        """初始化模型、标准化器和滑动窗口推理状态。"""
        self.checkpoint_path = Path(checkpoint_path)
        if not self.checkpoint_path.exists():
            raise FileNotFoundError(f"Missing checkpoint: {self.checkpoint_path}")

        self.device = torch.device(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.checkpoint = torch.load(
            self.checkpoint_path,
            map_location=self.device,
            weights_only=False,
        )

        self.model_type = infer_runtime_model_type(self.checkpoint)
        model_kwargs_payload = self.checkpoint.get("model_kwargs")
        self.checkpoint_model_kwargs = (
            dict(model_kwargs_payload) if isinstance(model_kwargs_payload, dict) else {}
        )
        self.input_size = int(
            self.checkpoint_model_kwargs.get(
                "input_size",
                self.checkpoint.get("input_size", get_model_decoded_feature_dim()),
            )
        )
        self.sequence_length = get_model_sequence_length()
        self.checkpoint_sequence_length = int(
            self.checkpoint.get("sequence_length", self.sequence_length)
        )
        self.hidden_size = int(
            self.checkpoint_model_kwargs.get("hidden_size", self.checkpoint.get("hidden_size", 128))
        )
        self.num_layers = int(
            self.checkpoint_model_kwargs.get("num_layers", self.checkpoint.get("num_layers", 2))
        )
        self.num_classes = int(
            self.checkpoint_model_kwargs.get("num_classes", self.checkpoint.get("num_classes", 0))
        )
        self.dropout = float(
            self.checkpoint_model_kwargs.get("dropout", self.checkpoint.get("dropout", 0.0))
        )
        self.cnn_channels = int(
            self.checkpoint_model_kwargs.get("cnn_channels", self.checkpoint.get("cnn_channels", 64))
        )
        self.kernel_size = int(
            self.checkpoint_model_kwargs.get("kernel_size", self.checkpoint.get("kernel_size", 5))
        )
        self.class_names = list(self.checkpoint.get("class_names", []))
        if len(self.class_names) != self.num_classes:
            raise ValueError(
                "Checkpoint class metadata is inconsistent: "
                f"{len(self.class_names)} class names for {self.num_classes} classes."
            )
        validate_runtime_class_count(self.class_names)
        # 运行期滑窗长度统一以共享配置为准，这样训练脚本和上位机只需改一处变量。
        # checkpoint 中旧的 sequence_length 仍会保留下来，便于后续排查历史模型来源。
        self.configured_raw_input_shape = format_model_input_shape()

        normalizer_payload = self.checkpoint.get("normalizer")
        if not isinstance(normalizer_payload, dict):
            raise ValueError("Checkpoint is missing normalizer statistics.")
        self.normalizer = FeatureNormalizer.from_checkpoint(normalizer_payload)
        self.preprocessor = RuntimePreprocessor.from_checkpoint(
            model_input_dim=self.input_size,
            payload=self.checkpoint.get("preprocessing"),
        )
        if (
            self.normalizer.mean.shape[-1] != self.input_size
            or self.normalizer.std.shape[-1] != self.input_size
        ):
            raise ValueError(
                "Checkpoint normalizer metadata is inconsistent with the model input size."
            )

        model_cls = RUNTIME_MODEL_REGISTRY[self.model_type]
        self.model = model_cls(**self._runtime_model_kwargs()).to(self.device)
        self.model.load_state_dict(self.checkpoint["model_state_dict"])
        self.model.eval()

        self.set_stride(stride)
        self.invalid_class_name = self._resolve_invalid_class_name(self.class_names)
        self.set_non_invalid_confidence_threshold(non_invalid_confidence_threshold)
        self.reset()

    def _runtime_model_kwargs(self) -> dict[str, int | float]:
        """生成当前 checkpoint 对应模型的构造参数。"""
        # 新版 checkpoint 会把模型构造参数完整保存在 model_kwargs 中，运行期优先直接复用。
        if self.checkpoint_model_kwargs:
            model_kwargs = dict(self.checkpoint_model_kwargs)
            model_kwargs.setdefault("input_size", self.input_size)
            model_kwargs.setdefault("num_classes", self.num_classes)
            model_kwargs.setdefault("dropout", self.dropout)
            return model_kwargs

        model_kwargs: dict[str, int | float] = {
            "input_size": self.input_size,
            "hidden_size": self.hidden_size,
            "num_layers": self.num_layers,
            "num_classes": self.num_classes,
            "dropout": self.dropout,
        }
        if self.model_type == "cnn-lstm":
            model_kwargs["cnn_channels"] = self.cnn_channels
            model_kwargs["kernel_size"] = self.kernel_size
        return model_kwargs

    def reset(self) -> None:
        """清空滑动窗口缓存，重新开始累计新序列。"""
        self._window: deque[tuple[np.ndarray, int]] = deque(maxlen=self.sequence_length)
        self.total_frames = 0
        self.frames_since_last_inference = 0
        self.has_prediction = False

    def set_stride(self, stride: int) -> None:
        """设置两次推理之间至少间隔多少帧。"""
        stride_value = int(stride)
        if stride_value <= 0:
            raise ValueError(f"Stride must be positive, got {stride}.")
        self.stride = stride_value

    def set_non_invalid_confidence_threshold(self, threshold: float) -> None:
        """设置非 Invalid 类最低置信度阈值。"""
        threshold_value = float(threshold)
        if not 0.0 <= threshold_value <= 1.0:
            raise ValueError(
                "Non-invalid confidence threshold must be between 0 and 1, "
                f"got {threshold}."
            )
        self.non_invalid_confidence_threshold = threshold_value

    def waiting_status(self) -> str:
        """生成“等待更多 CSI 帧”时的提示文案。"""
        return f"识别结果：等待数据 ({len(self._window)}/{self.sequence_length})"

    def invalid_frame_status(self, feature_count: int) -> str:
        """生成“当前帧特征维度不匹配”时的提示文案。"""
        expected = "/".join(str(count) for count in self.preprocessor.expected_runtime_feature_counts())
        return (
            "识别结果：等待兼容输入 "
            f"({feature_count}/{expected} 维)"
        )

    def ingest_frame(self, frame: Any) -> dict[str, Any] | None:
        """将一帧 CSI 特征送入滑窗，并在满足条件时返回识别结果。"""
        try:
            vector, feature_count = self.preprocessor.coerce_runtime_frame(frame)
        except ValueError as exc:
            raw_values = frame.get("data", []) if isinstance(frame, dict) else frame
            current_feature_count = int(np.asarray(raw_values, dtype=np.float32).reshape(-1).size)
            if current_feature_count > 0:
                raise ValueError(self.invalid_frame_status(current_feature_count)) from exc
            raise ValueError(str(exc)) from exc

        self._window.append((vector.copy(), feature_count))
        self.total_frames += 1
        self.frames_since_last_inference += 1

        if len(self._window) < self.sequence_length:
            return None
        if self.has_prediction and self.frames_since_last_inference < self.stride:
            return None

        window = self.preprocessor.preprocess_window(list(self._window))
        normalized_window = self.normalizer.transform(window).astype(np.float32)
        input_tensor = torch.from_numpy(normalized_window).unsqueeze(0).to(self.device)

        with torch.no_grad():
            logits = self.model(input_tensor)
            probabilities = torch.softmax(logits, dim=1).squeeze(0).cpu().numpy()

        predicted_index = int(np.argmax(probabilities))
        predicted_class = self.class_names[predicted_index]
        predicted_probability = float(probabilities[predicted_index])
        ranked_probabilities = [
            {
                "class_name": class_name,
                "probability": float(probability),
            }
            for class_name, probability in sorted(
                zip(self.class_names, probabilities.tolist()),
                key=lambda item: item[1],
                reverse=True,
            )
        ]

        final_class_name = predicted_class
        threshold_rejected = False
        if (
            self.invalid_class_name is not None
            and predicted_class.casefold() not in INVALID_CLASS_ALIASES
            and predicted_probability < self.non_invalid_confidence_threshold
        ):
            final_class_name = self.invalid_class_name
            threshold_rejected = True

        self.frames_since_last_inference = 0
        self.has_prediction = True
        return {
            "class_name": final_class_name,
            "probability": predicted_probability,
            "raw_class_name": predicted_class,
            "raw_probability": predicted_probability,
            "threshold_rejected": threshold_rejected,
            "non_invalid_confidence_threshold": self.non_invalid_confidence_threshold,
            "invalid_class_name": self.invalid_class_name,
            "probabilities": ranked_probabilities,
            "window_size": self.sequence_length,
            "stride": self.stride,
            "total_frames": self.total_frames,
            "window_end_index": self.total_frames,
            "window_start_index": self.total_frames - self.sequence_length + 1,
        }

    @staticmethod
    def _resolve_invalid_class_name(class_names: list[str]) -> str | None:
        """在类别表中查找 Invalid 类的真实名称。"""
        for class_name in class_names:
            if class_name.casefold() in INVALID_CLASS_ALIASES:
                return class_name
        return None
