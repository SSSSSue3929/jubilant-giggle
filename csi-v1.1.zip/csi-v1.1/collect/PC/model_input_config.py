"""共享的模型输入尺度配置。

训练脚本与上位机运行期统一从这里读取原始 CSI 输入尺度。
如果后续要切换为其他窗口规格，例如把输入从 ``[130, 104]``
改成 ``[100, 104]``，只需要修改下面的 ``MODEL_INPUT_SHAPE``
这一个变量即可。

说明：
- 第一维表示时间窗长度，也就是每个样本保留多少帧 CSI。
- 第二维表示每帧原始 CSI 数值长度；当前项目通常保持为 ``104``。
"""

from __future__ import annotations


# 统一从这里维护模型原始输入尺度：[时间窗长度, 每帧原始 CSI 数值长度]。
MODEL_INPUT_SHAPE = (130, 104)


def get_model_input_shape() -> tuple[int, int]:
    """返回经过校验后的共享模型输入尺度。"""
    return _validate_model_input_shape(MODEL_INPUT_SHAPE)


def get_model_sequence_length() -> int:
    """返回共享配置中的时间窗长度。"""
    sequence_length, _ = get_model_input_shape()
    return sequence_length


def get_model_raw_feature_dim() -> int:
    """返回共享配置中的原始 CSI 特征维度。"""
    _, raw_feature_dim = get_model_input_shape()
    return raw_feature_dim


def get_model_decoded_feature_dim() -> int:
    """返回按当前 CSI 解码逻辑还原后的子载波幅度维度。"""
    raw_feature_dim = get_model_raw_feature_dim()
    if raw_feature_dim % 4 != 0:
        raise ValueError(
            "当前 ESP-CSI 解码逻辑要求原始 CSI 维度必须能被 4 整除，"
            f"当前配置为 {raw_feature_dim}。"
        )
    return raw_feature_dim // 4


def format_model_input_shape() -> str:
    """把共享输入尺度格式化成便于日志显示的文本。"""
    sequence_length, raw_feature_dim = get_model_input_shape()
    return f"[{sequence_length}, {raw_feature_dim}]"


def _validate_model_input_shape(input_shape: object) -> tuple[int, int]:
    """校验输入尺度配置是否合法。"""
    if not isinstance(input_shape, (tuple, list)) or len(input_shape) != 2:
        raise ValueError(
            "MODEL_INPUT_SHAPE 必须是两个正整数构成的 tuple/list，例如 (130, 104)。"
        )

    sequence_length = int(input_shape[0])
    raw_feature_dim = int(input_shape[1])
    if sequence_length <= 0 or raw_feature_dim <= 0:
        raise ValueError(
            "MODEL_INPUT_SHAPE 的两个维度都必须为正整数，"
            f"当前为 ({sequence_length}, {raw_feature_dim})。"
        )
    return sequence_length, raw_feature_dim
