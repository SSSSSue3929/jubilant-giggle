"""ESP-CSI 上位机程序入口。

该文件只负责准备 Windows 多进程运行环境，并把真正的界面启动
流程交给 ``ui.main_window`` 模块中的 ``main`` 函数。

如需统一调整训练侧与上位机侧的模型输入尺度，请修改同目录
``model_input_config.py`` 中的 ``MODEL_INPUT_SHAPE``。
"""

from multiprocessing import freeze_support

from model_input_config import get_model_input_shape
from ui.main_window import main


if __name__ == "__main__":
    # 启动前先校验共享输入尺度配置，确保训练侧与上位机侧使用同一份窗口规格。
    get_model_input_shape()
    # Windows 下启用 multiprocessing 时，需要显式保护主入口，
    # 否则串口子进程会在导入阶段被重复拉起。
    freeze_support()
    # 将 Qt 事件循环的退出码透传给系统环境，便于外部脚本判断启动结果。
    raise SystemExit(main())
