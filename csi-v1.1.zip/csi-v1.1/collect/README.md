# collect

`collect` 存放 CSI 采集相关代码，分为 MCU 固件与 PC 端上位机两部分。

## 主要用途

- `MCU/`：ESP32-C5 发送端与接收端固件。
- `PC/`：PyQt 上位机，负责串口连接、实时显示、采集落盘和实时识别。

## 用法

启动 PC 端上位机：

```powershell
conda run -n esp-csi python ".\collect\PC\esp_csi_tool.py"
```

MCU 端使用 ESP-IDF 进行编译与烧录；`build/`、`managed_components/` 等中间产物已加入忽略规则。

## 目录结构

```text
collect/                            # 采集链路总目录
├── MCU/                            # ESP32-C5 固件工程集合
│   ├── ESP32-C5-RECV/              # 接收端固件工程
│   └── ESP32-C5-SEND/              # 发送端固件工程
└── PC/                             # PC 端上位机项目
    ├── collect/                    # 采集样本输出目录
    ├── config/                     # 上位机配置文件
    ├── core/                       # CSI 处理核心逻辑
    ├── dataset/                    # 本地样本目录，占位后默认忽略
    ├── drivers/                    # 串口、语音等驱动封装
    ├── log_csi/                    # 运行期日志目录
    ├── model/                      # 实时识别模型与运行时
    └── ui/                         # 主窗口、子线程与界面资源
```
