from __future__ import annotations

import argparse
import csv
import json
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
# 数据增强默认直接读取仓库根目录下的数据集目录。
DEFAULT_INPUT_DIR = PROJECT_ROOT / "data"
# 增强结果统一输出到 preprocessing/enhancement/output。
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "preprocessing" / "enhancement" / "output"
DEFAULT_WINDOW_LENGTH = 130
DEFAULT_STRIDE = 10
DEFAULT_SEGMENTS = 3


@dataclass(frozen=True)
class Window:
    segment_index: int
    start_row: int
    end_row: int


@dataclass(frozen=True)
class GeneratedSample:
    source_relative_path: str
    output_relative_path: str
    segment_index: int
    start_row: int
    end_row: int
    start_frame_1_based: int
    end_frame_1_based: int
    original_row_count: int
    output_row_count: int


@dataclass(frozen=True)
class SkippedSample:
    source_relative_path: str
    row_count: int
    required_min_rows: int
    reason: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create sliding-window sub-samples for every CSV stored under "
            "data/<session>/<class>/."
        )
    )
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=DEFAULT_INPUT_DIR,
        help="Root directory that stores session/class CSV samples.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory used to store the augmented dataset.",
    )
    parser.add_argument(
        "--window-length",
        type=int,
        default=DEFAULT_WINDOW_LENGTH,
        help="Number of rows kept in each generated sub-sample.",
    )
    parser.add_argument(
        "--stride",
        type=int,
        default=DEFAULT_STRIDE,
        help="Sliding stride, in rows.",
    )
    parser.add_argument(
        "--segments",
        type=int,
        default=DEFAULT_SEGMENTS,
        help="Maximum number of generated sub-samples per source CSV.",
    )
    return parser.parse_args()


def validate_positive(name: str, value: int) -> None:
    if value <= 0:
        raise ValueError(f"{name} must be positive, got {value}.")


def iter_sample_paths(input_dir: Path) -> list[Path]:
    sample_paths: list[Path] = []
    for csv_path in sorted(input_dir.rglob("*.csv")):
        relative_path = csv_path.relative_to(input_dir)
        if any(part.startswith(".") for part in relative_path.parts):
            continue
        if len(relative_path.parts) < 3:
            continue
        sample_paths.append(csv_path)
    return sample_paths


def read_csv_rows(csv_path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"{csv_path} does not contain a header row.")
        rows = list(reader)
    return list(reader.fieldnames), rows


def build_windows(row_count: int, window_length: int, stride: int, segments: int) -> list[Window]:
    windows: list[Window] = []
    for segment_index in range(segments):
        start_row = segment_index * stride
        end_row = start_row + window_length
        if end_row > row_count:
            break
        windows.append(
            Window(
                segment_index=segment_index,
                start_row=start_row,
                end_row=end_row,
            )
        )
    return windows


def required_row_count(window_length: int, stride: int, segments: int) -> int:
    return window_length + stride * (segments - 1)


def build_output_name(source_path: Path, window: Window) -> str:
    return (
        f"{source_path.stem}"
        f"__seg{window.segment_index + 1:02d}"
        f"_s{window.start_row:03d}"
        f"_e{window.end_row:03d}"
        f"{source_path.suffix}"
    )


def write_csv_rows(
    output_path: Path,
    fieldnames: list[str],
    rows: list[dict[str, str]],
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_manifest(output_dir: Path, records: list[GeneratedSample]) -> None:
    manifest_path = output_dir / "manifest.csv"
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "source_relative_path",
        "output_relative_path",
        "segment_index",
        "start_row",
        "end_row",
        "start_frame_1_based",
        "end_frame_1_based",
        "original_row_count",
        "output_row_count",
    ]
    with manifest_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for record in records:
            writer.writerow(asdict(record))


def write_summary(
    output_dir: Path,
    input_dir: Path,
    output_path: Path,
    window_length: int,
    stride: int,
    segments: int,
    source_count: int,
    generated: list[GeneratedSample],
    skipped: list[SkippedSample],
) -> None:
    summary_path = output_dir / "summary.json"
    payload = {
        "generated_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "input_dir": str(input_dir),
        "output_dir": str(output_path),
        "window_length": window_length,
        "stride": stride,
        "segments_per_sample": segments,
        "source_sample_count": source_count,
        "generated_sample_count": len(generated),
        "expansion_ratio": (len(generated) / source_count) if source_count else 0.0,
        "skipped_sample_count": len(skipped),
        "skipped_samples": [asdict(item) for item in skipped],
    }
    summary_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def augment_dataset(
    input_dir: Path,
    output_dir: Path,
    window_length: int,
    stride: int,
    segments: int,
) -> tuple[list[GeneratedSample], list[SkippedSample]]:
    validate_positive("window_length", window_length)
    validate_positive("stride", stride)
    validate_positive("segments", segments)

    input_dir = input_dir.resolve()
    output_dir = output_dir.resolve()
    if not input_dir.exists():
        raise FileNotFoundError(f"Input directory does not exist: {input_dir}")

    sample_paths = iter_sample_paths(input_dir)
    generated: list[GeneratedSample] = []
    skipped: list[SkippedSample] = []
    min_required_rows = required_row_count(window_length, stride, segments)

    for csv_path in sample_paths:
        relative_path = csv_path.relative_to(input_dir)
        fieldnames, rows = read_csv_rows(csv_path)
        if len(rows) < min_required_rows:
            skipped.append(
                SkippedSample(
                    source_relative_path=str(relative_path),
                    row_count=len(rows),
                    required_min_rows=min_required_rows,
                    reason="row_count_is_shorter_than_requested_segments",
                )
            )
            continue
        windows = build_windows(
            row_count=len(rows),
            window_length=window_length,
            stride=stride,
            segments=segments,
        )

        for window in windows:
            output_relative_path = relative_path.parent / build_output_name(csv_path, window)
            output_path = output_dir / output_relative_path
            window_rows = rows[window.start_row : window.end_row]
            write_csv_rows(output_path, fieldnames, window_rows)
            generated.append(
                GeneratedSample(
                    source_relative_path=str(relative_path),
                    output_relative_path=str(output_relative_path),
                    segment_index=window.segment_index + 1,
                    start_row=window.start_row,
                    end_row=window.end_row,
                    start_frame_1_based=window.start_row + 1,
                    end_frame_1_based=window.end_row,
                    original_row_count=len(rows),
                    output_row_count=len(window_rows),
                )
            )

    write_manifest(output_dir, generated)
    write_summary(
        output_dir=output_dir,
        input_dir=input_dir,
        output_path=output_dir,
        window_length=window_length,
        stride=stride,
        segments=segments,
        source_count=len(sample_paths),
        generated=generated,
        skipped=skipped,
    )
    return generated, skipped


def main() -> None:
    args = parse_args()
    source_count = len(iter_sample_paths(args.input_dir.resolve()))
    generated, skipped = augment_dataset(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        window_length=args.window_length,
        stride=args.stride,
        segments=args.segments,
    )
    print(
        "Generated "
        f"{len(generated)} samples from "
        f"{source_count} source CSV files into "
        f"{args.output_dir.resolve()}."
    )
    if skipped:
        print(
            f"Skipped {len(skipped)} samples that were shorter than the requested "
            "window coverage."
        )


if __name__ == "__main__":
    main()
