"""Sliding-window CSV augmentation utilities for recognition data."""
