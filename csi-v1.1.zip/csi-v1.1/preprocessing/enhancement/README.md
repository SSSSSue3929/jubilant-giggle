# preprocessing/enhancement

`preprocessing/enhancement` 用于对 `data/` 下的原始样本做滑窗增强，生成可用于训练的扩展样本。

## 主要用途

- 扫描 `data/` 中的 session 与类别样本。
- 对原始样本执行滑窗切分等增强操作。
- 将增强后的样本输出到 `preprocessing/enhancement/output/`。

## 用法

```powershell
conda run -n esp-csi python ".\preprocessing\enhancement\augment.py" --input-dir .\data --output-dir ".\preprocessing\enhancement\output"
```

说明：

- 默认输入目录为 `data/`。
- `dataset/` 与 `output/` 为本地增强工作目录，默认不提交到远程仓库。

## 目录结构

```text
preprocessing/enhancement/          # 样本增强工具目录
├── dataset/                        # 增强过程使用的本地数据目录
├── output/                         # 增强样本输出目录
├── augment.py                      # 样本增强脚本
└── __init__.py                     # 包初始化文件
```
