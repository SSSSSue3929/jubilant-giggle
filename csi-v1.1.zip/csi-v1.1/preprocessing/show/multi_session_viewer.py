from __future__ import annotations

import colorsys
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Button, CheckButtons, TextBox

try:
    from matplotlib.backends.qt_compat import QtWidgets
except Exception:
    QtWidgets = None

try:
    from .loader import (
        DatasetCatalog,
        SampleRecord,
        collect_sample_csv_paths,
        discover_dataset_catalog,
        load_sample_record,
    )
except ImportError:
    from loader import DatasetCatalog, SampleRecord, collect_sample_csv_paths, discover_dataset_catalog, load_sample_record


def bootstrap_esp_csi_tool_path() -> Path:
    repo_root = Path(__file__).resolve().parents[2]
    # 展示工具复用 PC 端上位机里的 CSI 预处理与绘图配置。
    tool_root = repo_root / "collect" / "PC"
    if str(tool_root) not in sys.path:
        sys.path.insert(0, str(tool_root))
    return repo_root


REPO_ROOT = bootstrap_esp_csi_tool_path()

from core.constants import CSI_SAMPLE_RATE, DEFAULT_UNIT, DEFAULT_VALID_SUBCARRIERS  # noqa: E402
from core.csi_processing import CsiBufferProcessor  # noqa: E402


plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


GRID_ROWS = 4
GRID_COLS = 5
GRID_SIZE = GRID_ROWS * GRID_COLS


class SessionSampleViewer:
    def __init__(self, initial_dataset_path: Path | None = None) -> None:
        self.dataset_root: Path | None = None
        self.session_dirs: list[Path] = []
        self.class_names: list[str] = []
        self.current_class_names: list[str] = []
        self.class_dirs_by_session: dict[Path, dict[str, Path]] = {}
        self.current_session_index = -1
        self.current_class_index = -1
        self.filter_enabled = True
        self.sample_cache: dict[Path, SampleRecord] = {}
        self.waveform_cache: dict[tuple[Path, bool], np.ndarray] = {}
        self.line_colors = self._generate_distinct_rgb_colors(len(DEFAULT_VALID_SUBCARRIERS))
        self._syncing_textbox = False
        self._syncing_session_selector = False
        self._syncing_class_selector = False
        self.session_selector_container = None
        self.session_selector = None
        self.class_selector_container = None
        self.class_selector = None

        self.figure, axes_grid = plt.subplots(GRID_ROWS, GRID_COLS, figsize=(24, 13))
        self.axes = [axis for row_axes in np.atleast_2d(axes_grid) for axis in row_axes]
        self.figure.patch.set_facecolor("#111111")
        self.figure.subplots_adjust(left=0.025, right=0.99, bottom=0.05, top=0.82, wspace=0.18, hspace=0.34)
        try:
            self.figure.canvas.manager.set_window_title("CSI Multi-Session Sample Viewer")
        except Exception:
            pass

        self._build_controls()
        self._render_empty_grid("请选择包含多个 session 的根目录")
        self._update_header("尚未选择数据目录。", "支持直接选择根目录，也兼容选择单个 session 目录。")

        if initial_dataset_path is not None:
            self.load_dataset_path(initial_dataset_path)

    def _build_controls(self) -> None:
        self.header_text = self.figure.text(
            0.03,
            0.885,
            "",
            color="white",
            fontsize=11,
            ha="left",
            va="center",
        )
        self.summary_text = self.figure.text(
            0.03,
            0.858,
            "",
            color="#d0d0d0",
            fontsize=10,
            ha="left",
            va="center",
        )

        root_box_ax = self.figure.add_axes([0.08, 0.925, 0.46, 0.035])
        root_box_ax.set_facecolor("#f5f5f5")
        self.root_text_box = TextBox(root_box_ax, "Root ", initial="")
        self.root_text_box.on_submit(self._on_root_text_submit)

        browse_ax = self.figure.add_axes([0.56, 0.925, 0.08, 0.035])
        self.button_browse = Button(browse_ax, "选择目录", color="#d9d9d9", hovercolor="#efefef")
        self.button_browse.on_clicked(self._on_browse_clicked)

        prev_session_ax = self.figure.add_axes([0.08, 0.875, 0.10, 0.035])
        self.button_prev_session = Button(prev_session_ax, "上一Session", color="#d9d9d9", hovercolor="#efefef")
        self.button_prev_session.on_clicked(self._on_previous_session_clicked)

        next_session_ax = self.figure.add_axes([0.40, 0.875, 0.10, 0.035])
        self.button_next_session = Button(next_session_ax, "下一Session", color="#d9d9d9", hovercolor="#efefef")
        self.button_next_session.on_clicked(self._on_next_session_clicked)

        filter_ax = self.figure.add_axes([0.82, 0.862, 0.14, 0.06])
        filter_ax.set_facecolor("#111111")
        self.filter_checks = CheckButtons(filter_ax, ["低通滤波"], [self.filter_enabled])
        for text in self.filter_checks.labels:
            text.set_color("white")
        for rectangle in getattr(self.filter_checks, "rectangles", []):
            rectangle.set_edgecolor("white")
            rectangle.set_facecolor("#111111")
        for pair in getattr(self.filter_checks, "lines", []):
            for line in pair:
                line.set_color("#56b4e9")
        self.filter_checks.on_clicked(self._on_filter_toggled)
        self._build_session_selector()
        self._build_class_selector()
        self._sync_session_navigation_buttons()

    def _on_browse_clicked(self, _event) -> None:
        selected_dir = self._choose_dataset_dir()
        if selected_dir is None:
            return
        self.load_dataset_path(selected_dir)

    def _on_root_text_submit(self, dataset_text: str) -> None:
        if self._syncing_textbox:
            return
        dataset_text = dataset_text.strip()
        if not dataset_text:
            return
        self.load_dataset_path(Path(dataset_text))

    def _on_previous_session_clicked(self, _event) -> None:
        if self.current_session_index > 0:
            self._set_current_session_index(self.current_session_index - 1, self._get_current_class_name())

    def _on_next_session_clicked(self, _event) -> None:
        if 0 <= self.current_session_index < len(self.session_dirs) - 1:
            self._set_current_session_index(self.current_session_index + 1, self._get_current_class_name())

    def _on_filter_toggled(self, _label) -> None:
        self.filter_enabled = not self.filter_enabled
        self.render_current_selection()

    def _choose_dataset_dir(self) -> Path | None:
        try:
            import tkinter as tk
            from tkinter import filedialog
        except Exception as exc:
            self._update_header("无法打开目录选择器。", str(exc))
            return None

        default_dir = self.dataset_root or (REPO_ROOT / "data")
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected_dir = filedialog.askdirectory(
            title="选择包含多个 session 的根目录",
            initialdir=str(default_dir),
        )
        root.destroy()
        if not selected_dir:
            return None
        return Path(selected_dir)

    def load_dataset_path(self, dataset_path: Path) -> None:
        try:
            catalog = discover_dataset_catalog(dataset_path)
        except Exception as exc:
            self._render_empty_grid("加载失败")
            self._update_header("数据目录加载失败。", str(exc))
            self.figure.canvas.draw_idle()
            return

        self._apply_catalog(catalog)
        self.render_current_selection()

    def _apply_catalog(self, catalog: DatasetCatalog) -> None:
        self.dataset_root = catalog.root_dir
        self.session_dirs = catalog.session_dirs
        self.class_names = catalog.class_names
        self.class_dirs_by_session = catalog.class_dirs_by_session
        self.current_session_index = catalog.initial_session_index
        self.current_class_index = -1
        self.current_class_names = []
        self.sample_cache.clear()
        self.waveform_cache.clear()
        self._set_dataset_text(str(self.dataset_root))
        self._sync_session_selector()
        self._sync_session_navigation_buttons()
        self._refresh_current_session_classes()

    def render_current_selection(self) -> None:
        session_dir = self._get_current_session_dir()
        if (
            self.dataset_root is None
            or not self.session_dirs
            or session_dir is None
            or not self.current_class_names
            or self.current_session_index < 0
            or self.current_class_index < 0
        ):
            self._render_empty_grid("暂无可显示的数据")
            self._update_header("尚未选择有效数据目录。", "")
            self.figure.canvas.draw_idle()
            return

        class_name = self.current_class_names[self.current_class_index]
        class_dir = self.class_dirs_by_session[session_dir][class_name]
        sample_paths = collect_sample_csv_paths(class_dir)
        visible_paths = sample_paths[:GRID_SIZE]

        for slot_index, axis in enumerate(self.axes):
            axis.clear()
            self._style_axis(axis, slot_index)

            if slot_index >= len(visible_paths):
                self._render_empty_axis(axis, slot_index, "空样本")
                continue

            sample_record = self._get_sample_record(visible_paths[slot_index])
            waveform = self._get_waveform(sample_record, self.filter_enabled)
            self._render_sample_axis(axis, sample_record, waveform, slot_index)

        filter_text = "开启" if self.filter_enabled else "关闭"
        total_count = len(sample_paths)
        shown_count = len(visible_paths)
        extra_suffix = f" | 仅显示前 {GRID_SIZE} 个样本" if total_count > GRID_SIZE else ""

        self._update_header(
            f"根目录: {self.dataset_root}",
            (
                f"Session {self.current_session_index + 1}/{len(self.session_dirs)}: {session_dir.name}"
                f" | 类别 {self.current_class_index + 1}/{len(self.current_class_names)}: {class_name}"
                f" | 当前显示 {shown_count}/{total_count} 个样本"
                f" | 低通滤波: {filter_text}{extra_suffix}"
            ),
        )
        self.figure.canvas.draw_idle()

    def _build_session_selector(self) -> None:
        if QtWidgets is None or self.session_selector is not None:
            return

        canvas_widget = getattr(self.figure, "canvas", None)
        if canvas_widget is None or not hasattr(canvas_widget, "width"):
            return

        container = QtWidgets.QWidget(canvas_widget)
        container.setStyleSheet(
            "background-color: rgba(17, 17, 17, 235);"
            "border: 1px solid #666666;"
            "border-radius: 6px;"
        )
        layout = QtWidgets.QHBoxLayout(container)
        layout.setContentsMargins(10, 4, 10, 4)
        layout.setSpacing(8)

        label = QtWidgets.QLabel("Session", container)
        label.setStyleSheet("color: white; font-size: 12px;")

        combo_box = QtWidgets.QComboBox(container)
        combo_box.setStyleSheet(
            "QComboBox {"
            " background-color: #f5f5f5;"
            " color: #111111;"
            " padding: 3px 8px;"
            " border: 1px solid #888888;"
            " border-radius: 4px;"
            "}"
            "QComboBox QAbstractItemView {"
            " background-color: #ffffff;"
            " color: #111111;"
            " selection-background-color: #d9edf8;"
            " selection-color: #111111;"
            "}"
        )
        combo_box.currentIndexChanged.connect(self._on_session_selector_changed)

        layout.addWidget(label)
        layout.addWidget(combo_box, 1)

        self.session_selector_container = container
        self.session_selector = combo_box
        self._position_session_selector()
        self.figure.canvas.mpl_connect("resize_event", self._on_figure_resized)
        self._sync_session_selector()

    def _build_class_selector(self) -> None:
        if QtWidgets is None or self.class_selector is not None:
            return

        canvas_widget = getattr(self.figure, "canvas", None)
        if canvas_widget is None or not hasattr(canvas_widget, "width"):
            return

        container = QtWidgets.QWidget(canvas_widget)
        container.setStyleSheet(
            "background-color: rgba(17, 17, 17, 235);"
            "border: 1px solid #666666;"
            "border-radius: 6px;"
        )
        layout = QtWidgets.QHBoxLayout(container)
        layout.setContentsMargins(10, 4, 10, 4)
        layout.setSpacing(8)

        label = QtWidgets.QLabel("类别", container)
        label.setStyleSheet("color: white; font-size: 12px;")

        combo_box = QtWidgets.QComboBox(container)
        combo_box.setStyleSheet(
            "QComboBox {"
            " background-color: #f5f5f5;"
            " color: #111111;"
            " padding: 3px 8px;"
            " border: 1px solid #888888;"
            " border-radius: 4px;"
            "}"
            "QComboBox QAbstractItemView {"
            " background-color: #ffffff;"
            " color: #111111;"
            " selection-background-color: #d9edf8;"
            " selection-color: #111111;"
            "}"
        )
        combo_box.currentTextChanged.connect(self._on_class_selector_changed)

        layout.addWidget(label)
        layout.addWidget(combo_box, 1)

        self.class_selector_container = container
        self.class_selector = combo_box
        self._position_class_selector()
        self._sync_class_selector()

    def _position_class_selector(self) -> None:
        if self.class_selector_container is None:
            return

        canvas_widget = getattr(self.figure, "canvas", None)
        if canvas_widget is None or not hasattr(canvas_widget, "width"):
            return

        canvas_width = max(int(canvas_widget.width()), 1)
        canvas_height = max(int(canvas_widget.height()), 1)
        left = int(canvas_width * 0.54)
        top = int(canvas_height * 0.085)
        width = max(int(canvas_width * 0.18), 240)
        height = max(int(canvas_height * 0.042), 34)
        self.class_selector_container.setGeometry(left, top, width, height)
        self.class_selector_container.raise_()
        self.class_selector_container.show()

    def _position_session_selector(self) -> None:
        if self.session_selector_container is None:
            return

        canvas_widget = getattr(self.figure, "canvas", None)
        if canvas_widget is None or not hasattr(canvas_widget, "width"):
            return

        canvas_width = max(int(canvas_widget.width()), 1)
        canvas_height = max(int(canvas_widget.height()), 1)
        left = int(canvas_width * 0.20)
        top = int(canvas_height * 0.085)
        width = max(int(canvas_width * 0.19), 260)
        height = max(int(canvas_height * 0.042), 34)
        self.session_selector_container.setGeometry(left, top, width, height)
        self.session_selector_container.raise_()
        self.session_selector_container.show()

    def _on_figure_resized(self, _event) -> None:
        self._position_session_selector()
        self._position_class_selector()

    def _get_current_session_dir(self) -> Path | None:
        if 0 <= self.current_session_index < len(self.session_dirs):
            return self.session_dirs[self.current_session_index]
        return None

    def _get_current_class_name(self) -> str | None:
        if 0 <= self.current_class_index < len(self.current_class_names):
            return self.current_class_names[self.current_class_index]
        return None

    def _set_current_session_index(self, session_index: int, preferred_class_name: str | None = None) -> None:
        if not 0 <= session_index < len(self.session_dirs):
            return

        self.current_session_index = session_index
        self._sync_session_selector()
        self._sync_session_navigation_buttons()
        self._refresh_current_session_classes(preferred_class_name)
        self.render_current_selection()

    def _get_current_session_class_names(self) -> list[str]:
        session_dir = self._get_current_session_dir()
        if session_dir is None:
            return []
        return sorted(self.class_dirs_by_session.get(session_dir, {}))

    def _sync_session_selector(self) -> None:
        if self.session_selector is None:
            return

        self._syncing_session_selector = True
        self.session_selector.blockSignals(True)
        try:
            self.session_selector.clear()
            if self.session_dirs:
                self.session_selector.addItems([session_dir.name for session_dir in self.session_dirs])
                self.session_selector.setEnabled(True)
                if 0 <= self.current_session_index < len(self.session_dirs):
                    self.session_selector.setCurrentIndex(self.current_session_index)
            else:
                self.session_selector.addItem("无可用Session")
                self.session_selector.setCurrentIndex(0)
                self.session_selector.setEnabled(False)
        finally:
            self.session_selector.blockSignals(False)
            self._syncing_session_selector = False

    def _sync_session_navigation_buttons(self) -> None:
        session_count = len(self.session_dirs)
        prev_enabled = self.current_session_index > 0
        next_enabled = 0 <= self.current_session_index < session_count - 1

        for button, enabled in (
            (self.button_prev_session, prev_enabled),
            (self.button_next_session, next_enabled),
        ):
            button.ax.set_facecolor("#d9d9d9" if enabled else "#777777")
            button.label.set_color("#111111" if enabled else "#dddddd")
            button.hovercolor = "#efefef" if enabled else "#777777"
        self.figure.canvas.draw_idle()

    def _on_session_selector_changed(self, session_index: int) -> None:
        if self._syncing_session_selector or not 0 <= session_index < len(self.session_dirs):
            return

        if session_index == self.current_session_index:
            return

        self._set_current_session_index(session_index, self._get_current_class_name())

    def _refresh_current_session_classes(self, preferred_class_name: str | None = None) -> None:
        current_class_name = preferred_class_name or self._get_current_class_name()
        self.current_class_names = self._get_current_session_class_names()

        if not self.current_class_names:
            self.current_class_index = -1
        elif current_class_name in self.current_class_names:
            self.current_class_index = self.current_class_names.index(current_class_name)
        else:
            self.current_class_index = 0

        self._sync_class_selector()

    def _sync_class_selector(self) -> None:
        if self.class_selector is None:
            return

        self._syncing_class_selector = True
        self.class_selector.blockSignals(True)
        try:
            self.class_selector.clear()
            if self.current_class_names:
                self.class_selector.addItems(self.current_class_names)
                self.class_selector.setEnabled(True)
                if 0 <= self.current_class_index < len(self.current_class_names):
                    self.class_selector.setCurrentIndex(self.current_class_index)
            else:
                self.class_selector.addItem("无可用类别")
                self.class_selector.setCurrentIndex(0)
                self.class_selector.setEnabled(False)
        finally:
            self.class_selector.blockSignals(False)
            self._syncing_class_selector = False

    def _on_class_selector_changed(self, class_name: str) -> None:
        if self._syncing_class_selector or class_name not in self.current_class_names:
            return

        new_index = self.current_class_names.index(class_name)
        if new_index == self.current_class_index:
            return

        self.current_class_index = new_index
        self.render_current_selection()

    def _render_sample_axis(
        self,
        axis,
        sample_record: SampleRecord,
        waveform: np.ndarray,
        slot_index: int,
    ) -> None:
        axis.set_title(f"{slot_index + 1}. {sample_record.path.name}", color="white", fontsize=7)

        if waveform.size == 0:
            axis.text(
                0.5,
                0.5,
                f"无有效 CSI\n跳过 {sample_record.skipped_rows} 行",
                color="#bbbbbb",
                ha="center",
                va="center",
                transform=axis.transAxes,
                fontsize=8,
            )
            return

        x_axis = np.arange(waveform.shape[0], dtype=np.float64)
        for column_index in range(waveform.shape[1]):
            axis.plot(
                x_axis,
                waveform[:, column_index],
                color=self.line_colors[column_index],
                linewidth=0.55,
                alpha=0.9,
            )

        axis.text(
            0.01,
            0.98,
            f"有效 {len(sample_record.events)} | 跳过 {sample_record.skipped_rows}",
            color="#cccccc",
            ha="left",
            va="top",
            transform=axis.transAxes,
            fontsize=6,
            bbox={"facecolor": "#111111", "edgecolor": "none", "alpha": 0.7, "pad": 1.0},
        )

    def _render_empty_grid(self, message: str) -> None:
        for slot_index, axis in enumerate(self.axes):
            axis.clear()
            self._style_axis(axis, slot_index)
            self._render_empty_axis(axis, slot_index, message)

    def _render_empty_axis(self, axis, slot_index: int, message: str) -> None:
        axis.set_title(f"样本 {slot_index + 1}", color="white", fontsize=8)
        axis.text(
            0.5,
            0.5,
            message,
            color="#bbbbbb",
            ha="center",
            va="center",
            transform=axis.transAxes,
            fontsize=9,
        )

    def _style_axis(self, axis, slot_index: int) -> None:
        axis.set_facecolor("#000000")
        row_index, col_index = divmod(slot_index, GRID_COLS)
        axis.grid(True, alpha=0.15, color="white", linewidth=0.4)
        axis.tick_params(
            axis="both",
            colors="#dddddd",
            labelsize=5,
            length=2,
            labelbottom=row_index == GRID_ROWS - 1,
            labelleft=col_index == 0,
        )
        for spine in axis.spines.values():
            spine.set_color("#666666")
        axis.set_xlabel("")
        axis.set_ylabel("")
        axis.margins(x=0)

    def _get_sample_record(self, sample_path: Path) -> SampleRecord:
        cached_record = self.sample_cache.get(sample_path)
        if cached_record is not None:
            return cached_record

        sample_record = load_sample_record(sample_path)
        self.sample_cache[sample_path] = sample_record
        return sample_record

    def _get_waveform(self, sample_record: SampleRecord, filter_enabled: bool) -> np.ndarray:
        cache_key = (sample_record.path, filter_enabled)
        cached_waveform = self.waveform_cache.get(cache_key)
        if cached_waveform is not None:
            return cached_waveform

        processor = CsiBufferProcessor(
            buffer_size=max(len(sample_record.events), 1),
            sample_rate=CSI_SAMPLE_RATE,
            valid_subcarriers=list(DEFAULT_VALID_SUBCARRIERS),
            display_unit=DEFAULT_UNIT,
            filter_enabled=filter_enabled,
        )
        waveform = processor.build_waveform_from_events(sample_record.events)
        self.waveform_cache[cache_key] = waveform
        return waveform

    def _update_header(self, header_message: str, summary_message: str) -> None:
        self.header_text.set_text(header_message)
        self.summary_text.set_text(summary_message)

    def _set_dataset_text(self, dataset_text: str) -> None:
        self._syncing_textbox = True
        self.root_text_box.set_val(dataset_text)
        self._syncing_textbox = False

    def save_preview(self, output_path: Path) -> None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        self.figure.savefig(output_path, dpi=150, facecolor=self.figure.get_facecolor())

    def show(self, quit_ms: int = 0) -> None:
        if quit_ms > 0:
            timer = self.figure.canvas.new_timer(interval=quit_ms)
            timer.add_callback(plt.close, self.figure)
            timer.start()
        plt.show()

    @staticmethod
    def _generate_distinct_rgb_colors(color_count: int) -> list[tuple[float, float, float]]:
        saturation = 0.9
        brightness = 0.95
        rgb_colors: list[tuple[float, float, float]] = []
        for index in range(max(color_count, 1)):
            hue = index / max(color_count, 1)
            red, green, blue = colorsys.hsv_to_rgb(hue, saturation, brightness)
            rgb_colors.append((red, green, blue))
        return rgb_colors
