from __future__ import annotations

import colorsys
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.widgets import Button, CheckButtons, TextBox

try:
    from .loader import SampleRecord, collect_sample_csv_paths, discover_class_directories, load_sample_record
except ImportError:
    from loader import SampleRecord, collect_sample_csv_paths, discover_class_directories, load_sample_record


def bootstrap_esp_csi_tool_path() -> Path:
    repo_root = Path(__file__).resolve().parents[2]
    # 展示工具复用 PC 端上位机里的 CSI 预处理与绘图配置。
    tool_root = repo_root / "collect" / "PC"
    if str(tool_root) not in sys.path:
        sys.path.insert(0, str(tool_root))
    return repo_root


REPO_ROOT = bootstrap_esp_csi_tool_path()

from core.constants import CSI_SAMPLE_RATE, DEFAULT_UNIT, DEFAULT_VALID_SUBCARRIERS  # noqa: E402
from core.csi_processing import CsiBufferProcessor  # noqa: E402


plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "Arial Unicode MS", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


GRID_ROWS = 5
GRID_COLS = 5
GRID_SIZE = GRID_ROWS * GRID_COLS


class SessionSampleViewer:
    def __init__(self, initial_session_dir: Path | None = None) -> None:
        self.session_dir: Path | None = None
        self.class_dirs: list[Path] = []
        self.current_class_index = -1
        self.filter_enabled = True
        self.sample_cache: dict[Path, SampleRecord] = {}
        self.waveform_cache: dict[tuple[Path, bool], np.ndarray] = {}
        self._syncing_textbox = False

        self.figure, axes_grid = plt.subplots(GRID_ROWS, GRID_COLS, figsize=(24, 14))
        self.axes = [axis for row_axes in np.atleast_2d(axes_grid) for axis in row_axes]
        self.figure.patch.set_facecolor("#111111")
        self.figure.subplots_adjust(left=0.03, right=0.99, bottom=0.05, top=0.84, wspace=0.18, hspace=0.32)
        try:
            self.figure.canvas.manager.set_window_title("CSI Session Sample Viewer")
        except Exception:
            pass

        self._build_controls()
        self._render_empty_grid()
        self._update_summary("尚未选择 session。")

        if initial_session_dir is not None:
            self.load_session_dir(initial_session_dir)

    def _build_controls(self) -> None:
        self.summary_text = self.figure.text(
            0.03,
            0.885,
            "",
            color="white",
            fontsize=11,
            ha="left",
            va="center",
        )

        session_box_ax = self.figure.add_axes([0.08, 0.92, 0.42, 0.035])
        session_box_ax.set_facecolor("#f5f5f5")
        self.session_text_box = TextBox(session_box_ax, "Session ", initial="")
        self.session_text_box.on_submit(self._on_session_text_submit)

        browse_ax = self.figure.add_axes([0.52, 0.92, 0.08, 0.035])
        self.button_browse = Button(browse_ax, "选择Session", color="#d9d9d9", hovercolor="#efefef")
        self.button_browse.on_clicked(self._on_browse_clicked)

        prev_ax = self.figure.add_axes([0.62, 0.92, 0.07, 0.035])
        self.button_prev = Button(prev_ax, "上一类", color="#d9d9d9", hovercolor="#efefef")
        self.button_prev.on_clicked(self._on_previous_clicked)

        next_ax = self.figure.add_axes([0.71, 0.92, 0.07, 0.035])
        self.button_next = Button(next_ax, "下一类", color="#d9d9d9", hovercolor="#efefef")
        self.button_next.on_clicked(self._on_next_clicked)

        filter_ax = self.figure.add_axes([0.82, 0.905, 0.14, 0.06])
        filter_ax.set_facecolor("#111111")
        self.filter_checks = CheckButtons(filter_ax, ["低通滤波"], [self.filter_enabled])
        for text in self.filter_checks.labels:
            text.set_color("white")
        for rectangle in getattr(self.filter_checks, "rectangles", []):
            rectangle.set_edgecolor("white")
            rectangle.set_facecolor("#111111")
        for pair in getattr(self.filter_checks, "lines", []):
            for line in pair:
                line.set_color("#56b4e9")
        self.filter_checks.on_clicked(self._on_filter_toggled)

    def _on_browse_clicked(self, _event) -> None:
        selected_dir = self._choose_session_dir()
        if selected_dir is None:
            return
        self.load_session_dir(selected_dir)

    def _on_previous_clicked(self, _event) -> None:
        if self.current_class_index > 0:
            self.current_class_index -= 1
            self.render_current_class()

    def _on_next_clicked(self, _event) -> None:
        if 0 <= self.current_class_index < len(self.class_dirs) - 1:
            self.current_class_index += 1
            self.render_current_class()

    def _on_filter_toggled(self, _label) -> None:
        self.filter_enabled = not self.filter_enabled
        self.render_current_class()

    def _on_session_text_submit(self, session_text: str) -> None:
        if self._syncing_textbox:
            return
        session_text = session_text.strip()
        if not session_text:
            return
        self.load_session_dir(Path(session_text))

    def _choose_session_dir(self) -> Path | None:
        try:
            import tkinter as tk
            from tkinter import filedialog
        except Exception as exc:
            self._update_summary(f"无法打开目录选择器: {exc}")
            return None

        default_dir = self.session_dir or (REPO_ROOT / "data")
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected_dir = filedialog.askdirectory(
            title="选择 session 目录",
            initialdir=str(default_dir),
        )
        root.destroy()
        if not selected_dir:
            return None
        return Path(selected_dir)

    def load_session_dir(self, session_dir: Path) -> None:
        try:
            class_dirs = discover_class_directories(session_dir)
        except Exception as exc:
            self._update_summary(f"加载失败: {exc}")
            return

        self.session_dir = session_dir.resolve()
        self.class_dirs = class_dirs
        self.current_class_index = 0
        self.sample_cache.clear()
        self.waveform_cache.clear()
        self._set_session_text(str(self.session_dir))
        self.render_current_class()

    def render_current_class(self) -> None:
        if not self.class_dirs or self.current_class_index < 0:
            self._render_empty_grid()
            self._update_summary("尚未选择类别。")
            self.figure.canvas.draw_idle()
            return

        class_dir = self.class_dirs[self.current_class_index]
        sample_paths = collect_sample_csv_paths(class_dir)
        visible_paths = sample_paths[:GRID_SIZE]
        line_colors = self._generate_distinct_rgb_colors(len(DEFAULT_VALID_SUBCARRIERS))

        for slot_index, axis in enumerate(self.axes):
            axis.clear()
            self._style_axis(axis)

            if slot_index >= len(visible_paths):
                axis.set_title(f"样本 {slot_index + 1}", color="white", fontsize=8)
                axis.text(
                    0.5,
                    0.5,
                    "空槽位",
                    color="#bbbbbb",
                    ha="center",
                    va="center",
                    transform=axis.transAxes,
                    fontsize=9,
                )
                continue

            sample_record = self._get_sample_record(visible_paths[slot_index])
            waveform = self._get_waveform(sample_record, self.filter_enabled)
            self._render_sample_axis(axis, sample_record, waveform, slot_index, line_colors)

        filter_text = "开启" if self.filter_enabled else "关闭"
        shown_count = len(visible_paths)
        total_count = len(sample_paths)
        extra_suffix = ""
        if total_count > GRID_SIZE:
            extra_suffix = f"；仅显示前 {GRID_SIZE} 个样本。"

        self._update_summary(
            f"Session: {self.session_dir.name} | 类别 {self.current_class_index + 1}/{len(self.class_dirs)}: "
            f"{class_dir.name} | 当前显示 {shown_count}/{total_count} 个样本 | 低通滤波: {filter_text}{extra_suffix}"
        )
        self.figure.canvas.draw_idle()

    def _render_sample_axis(
        self,
        axis,
        sample_record: SampleRecord,
        waveform: np.ndarray,
        slot_index: int,
        line_colors: list[tuple[float, float, float]],
    ) -> None:
        axis.set_title(f"{slot_index + 1}. {sample_record.path.name}", color="white", fontsize=7)

        if waveform.size == 0:
            axis.text(
                0.5,
                0.5,
                f"无有效 CSI\n跳过 {sample_record.skipped_rows} 条",
                color="#bbbbbb",
                ha="center",
                va="center",
                transform=axis.transAxes,
                fontsize=8,
            )
            return

        x_axis = np.arange(waveform.shape[0], dtype=np.float64)
        for column_index in range(waveform.shape[1]):
            axis.plot(
                x_axis,
                waveform[:, column_index],
                color=line_colors[column_index],
                linewidth=0.6,
                alpha=0.9,
            )

        axis.text(
            0.01,
            0.98,
            f"有效 {len(sample_record.events)} | 跳过 {sample_record.skipped_rows}",
            color="#cccccc",
            ha="left",
            va="top",
            transform=axis.transAxes,
            fontsize=6,
            bbox={"facecolor": "#111111", "edgecolor": "none", "alpha": 0.65, "pad": 1.0},
        )

    def _render_empty_grid(self) -> None:
        for slot_index, axis in enumerate(self.axes):
            axis.clear()
            self._style_axis(axis)
            axis.set_title(f"样本 {slot_index + 1}", color="white", fontsize=8)
            axis.text(
                0.5,
                0.5,
                "空槽位",
                color="#bbbbbb",
                ha="center",
                va="center",
                transform=axis.transAxes,
                fontsize=9,
            )

    def _style_axis(self, axis) -> None:
        axis.set_facecolor("#000000")
        axis.grid(True, alpha=0.15, color="white", linewidth=0.4)
        axis.tick_params(axis="both", colors="#dddddd", labelsize=6)
        for spine in axis.spines.values():
            spine.set_color("#666666")
        axis.set_xlabel("")
        axis.set_ylabel("")

    def _get_sample_record(self, sample_path: Path) -> SampleRecord:
        cached_record = self.sample_cache.get(sample_path)
        if cached_record is not None:
            return cached_record

        sample_record = load_sample_record(sample_path)
        self.sample_cache[sample_path] = sample_record
        return sample_record

    def _get_waveform(self, sample_record: SampleRecord, filter_enabled: bool) -> np.ndarray:
        cache_key = (sample_record.path, filter_enabled)
        cached_waveform = self.waveform_cache.get(cache_key)
        if cached_waveform is not None:
            return cached_waveform

        processor = CsiBufferProcessor(
            buffer_size=max(len(sample_record.events), 1),
            sample_rate=CSI_SAMPLE_RATE,
            valid_subcarriers=list(DEFAULT_VALID_SUBCARRIERS),
            display_unit=DEFAULT_UNIT,
            filter_enabled=filter_enabled,
        )
        waveform = processor.build_waveform_from_events(sample_record.events)
        self.waveform_cache[cache_key] = waveform
        return waveform

    def _update_summary(self, message: str) -> None:
        self.summary_text.set_text(message)

    def _set_session_text(self, session_text: str) -> None:
        self._syncing_textbox = True
        self.session_text_box.set_val(session_text)
        self._syncing_textbox = False

    def save_preview(self, output_path: Path) -> None:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        self.figure.savefig(output_path, dpi=150, facecolor=self.figure.get_facecolor())

    def show(self, quit_ms: int = 0) -> None:
        if quit_ms > 0:
            timer = self.figure.canvas.new_timer(interval=quit_ms)
            timer.add_callback(plt.close, self.figure)
            timer.start()
        plt.show()

    @staticmethod
    def _generate_distinct_rgb_colors(color_count: int) -> list[tuple[float, float, float]]:
        saturation = 0.9
        brightness = 0.95
        rgb_colors: list[tuple[float, float, float]] = []
        for index in range(max(color_count, 1)):
            hue = index / max(color_count, 1)
            red, green, blue = colorsys.hsv_to_rgb(hue, saturation, brightness)
            rgb_colors.append((red, green, blue))
        return rgb_colors
