from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pyqtgraph as pg
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QFileDialog,
    QCheckBox,
    QComboBox,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)
from pyqtgraph import PlotWidget

try:
    from .loader import SampleRecord, collect_sample_csv_paths, discover_class_directories, load_sample_record
except ImportError:
    from loader import SampleRecord, collect_sample_csv_paths, discover_class_directories, load_sample_record


def bootstrap_esp_csi_tool_path() -> Path:
    repo_root = Path(__file__).resolve().parents[2]
    # 展示工具复用 PC 端上位机里的 CSI 预处理与绘图配置。
    tool_root = repo_root / "collect" / "PC"
    if str(tool_root) not in sys.path:
        sys.path.insert(0, str(tool_root))
    return repo_root


REPO_ROOT = bootstrap_esp_csi_tool_path()

from core.constants import CSI_SAMPLE_RATE, DEFAULT_UNIT, DEFAULT_VALID_SUBCARRIERS  # noqa: E402
from core.csi_processing import CsiBufferProcessor  # noqa: E402
from ui.plot_controller import SubcarrierPlotController  # noqa: E402


GRID_ROWS = 5
GRID_COLS = 5
GRID_SIZE = GRID_ROWS * GRID_COLS


class SamplePlotTile(QWidget):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.title_label = QLabel("空样本槽位")
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setWordWrap(True)

        self.info_label = QLabel("")
        self.info_label.setAlignment(Qt.AlignCenter)
        self.info_label.setWordWrap(True)

        self.plot_widget = PlotWidget()
        self.plot_widget.setBackground("k")
        self.plot_widget.plotItem.vb.setMouseMode(pg.ViewBox.PanMode)
        self.plot_widget.setMouseEnabled(x=True, y=False)
        self.plot_widget.showGrid(x=True, y=True, alpha=0.2)

        self.controller = SubcarrierPlotController(self.plot_widget, show_legend=False)
        self.controller.load_static_dataset(
            DEFAULT_VALID_SUBCARRIERS,
            np.zeros((0, len(DEFAULT_VALID_SUBCARRIERS)), dtype=np.float64),
            [],
            1,
        )

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)
        layout.addWidget(self.title_label)
        layout.addWidget(self.info_label)
        layout.addWidget(self.plot_widget, stretch=1)

        self.setMinimumSize(280, 190)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def render_blank(self, slot_index: int) -> None:
        self.title_label.setText(f"样本 {slot_index + 1}")
        self.info_label.setText("空槽位")
        self.controller.load_static_dataset(
            DEFAULT_VALID_SUBCARRIERS,
            np.zeros((0, len(DEFAULT_VALID_SUBCARRIERS)), dtype=np.float64),
            [],
            1,
        )

    def render_sample(
        self,
        sample: SampleRecord,
        waveform: np.ndarray,
        slot_index: int,
    ) -> None:
        self.title_label.setText(f"样本 {slot_index + 1}: {sample.path.name}")
        self.info_label.setText(
            f"有效 CSI: {len(sample.events)} 条 | 跳过: {sample.skipped_rows} 条"
        )
        self.controller.load_static_dataset(
            DEFAULT_VALID_SUBCARRIERS,
            waveform,
            [],
            max(int(waveform.shape[0]), 1),
        )


class SessionSampleViewer(QMainWindow):
    def __init__(self, initial_session_dir: Path | None = None) -> None:
        super().__init__()
        self.session_dir: Path | None = None
        self.class_dirs: list[Path] = []
        self.current_class_index = -1
        self.sample_cache: dict[Path, SampleRecord] = {}
        self.waveform_cache: dict[tuple[Path, bool], np.ndarray] = {}

        self.setWindowTitle("CSI Session Sample Viewer")
        self.resize(1800, 1100)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        self.line_edit_session = QLineEdit()
        self.line_edit_session.setPlaceholderText("选择一个 session 目录")

        self.button_browse = QPushButton("导入 Session")
        self.button_prev_class = QPushButton("上一类")
        self.button_next_class = QPushButton("下一类")

        self.combo_class = QComboBox()
        self.combo_class.setMinimumWidth(220)

        self.check_box_filter = QCheckBox("低通滤波")
        self.check_box_filter.setChecked(True)

        self.label_summary = QLabel("尚未选择 session。")
        self.label_summary.setWordWrap(True)

        top_layout = QHBoxLayout()
        top_layout.addWidget(QLabel("Session"))
        top_layout.addWidget(self.line_edit_session, stretch=1)
        top_layout.addWidget(self.button_browse)
        top_layout.addSpacing(12)
        top_layout.addWidget(self.button_prev_class)
        top_layout.addWidget(self.combo_class)
        top_layout.addWidget(self.button_next_class)
        top_layout.addSpacing(12)
        top_layout.addWidget(self.check_box_filter)

        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setContentsMargins(8, 8, 8, 8)
        self.grid_layout.setHorizontalSpacing(8)
        self.grid_layout.setVerticalSpacing(8)

        self.tiles: list[SamplePlotTile] = []
        for row in range(GRID_ROWS):
            for col in range(GRID_COLS):
                tile = SamplePlotTile()
                self.grid_layout.addWidget(tile, row, col)
                self.tiles.append(tile)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(self.grid_container)

        root_layout = QVBoxLayout(central_widget)
        root_layout.addLayout(top_layout)
        root_layout.addWidget(self.label_summary)
        root_layout.addWidget(scroll_area, stretch=1)

        self.button_browse.clicked.connect(self.select_session_dir)
        self.line_edit_session.returnPressed.connect(self.load_session_from_text)
        self.button_prev_class.clicked.connect(self.show_previous_class)
        self.button_next_class.clicked.connect(self.show_next_class)
        self.combo_class.currentIndexChanged.connect(self.set_class_index)
        self.check_box_filter.toggled.connect(self.render_current_class)

        self._update_navigation_state()
        self._render_empty_grid()

        if initial_session_dir is not None:
            self.load_session_dir(initial_session_dir)

    def select_session_dir(self) -> None:
        default_dir = self.session_dir or (REPO_ROOT / "data")
        selected_dir = QFileDialog.getExistingDirectory(
            self,
            "选择 session 目录",
            str(default_dir),
        )
        if not selected_dir:
            return
        self.load_session_dir(Path(selected_dir))

    def load_session_from_text(self) -> None:
        session_text = self.line_edit_session.text().strip()
        if not session_text:
            return
        self.load_session_dir(Path(session_text))

    def load_session_dir(self, session_dir: Path) -> None:
        try:
            class_dirs = discover_class_directories(session_dir)
        except Exception as exc:
            QMessageBox.warning(self, "加载失败", str(exc))
            return

        self.session_dir = session_dir.resolve()
        self.class_dirs = class_dirs
        self.current_class_index = 0 if class_dirs else -1
        self.sample_cache.clear()
        self.waveform_cache.clear()

        self.line_edit_session.setText(str(self.session_dir))

        self.combo_class.blockSignals(True)
        self.combo_class.clear()
        self.combo_class.addItems([path.name for path in self.class_dirs])
        self.combo_class.blockSignals(False)

        if self.class_dirs:
            self.combo_class.setCurrentIndex(0)
            self.render_current_class()
        else:
            self._render_empty_grid()
            self.label_summary.setText("当前 session 下没有类别目录。")

        self._update_navigation_state()

    def set_class_index(self, class_index: int) -> None:
        if not self.class_dirs:
            self.current_class_index = -1
            self._render_empty_grid()
            self._update_navigation_state()
            return

        bounded_index = max(0, min(int(class_index), len(self.class_dirs) - 1))
        if bounded_index != class_index:
            self.combo_class.blockSignals(True)
            self.combo_class.setCurrentIndex(bounded_index)
            self.combo_class.blockSignals(False)

        self.current_class_index = bounded_index
        self.render_current_class()
        self._update_navigation_state()

    def show_previous_class(self) -> None:
        if self.current_class_index > 0:
            self.set_class_index(self.current_class_index - 1)

    def show_next_class(self) -> None:
        if 0 <= self.current_class_index < len(self.class_dirs) - 1:
            self.set_class_index(self.current_class_index + 1)

    def render_current_class(self) -> None:
        if not self.class_dirs or self.current_class_index < 0:
            self._render_empty_grid()
            self.label_summary.setText("尚未选择类别。")
            return

        class_dir = self.class_dirs[self.current_class_index]
        sample_paths = collect_sample_csv_paths(class_dir)
        visible_paths = sample_paths[:GRID_SIZE]

        for slot_index, tile in enumerate(self.tiles):
            if slot_index < len(visible_paths):
                sample_path = visible_paths[slot_index]
                sample_record = self._get_sample_record(sample_path)
                waveform = self._get_waveform(sample_record, self.check_box_filter.isChecked())
                tile.render_sample(sample_record, waveform, slot_index)
            else:
                tile.render_blank(slot_index)

        total_categories = len(self.class_dirs)
        shown_count = len(visible_paths)
        total_count = len(sample_paths)
        filter_text = "开启" if self.check_box_filter.isChecked() else "关闭"
        extra_suffix = ""
        if total_count > GRID_SIZE:
            extra_suffix = f"；仅显示前 {GRID_SIZE} 个样本。"

        self.label_summary.setText(
            f"Session: {self.session_dir.name} | 类别 {self.current_class_index + 1}/{total_categories}: "
            f"{class_dir.name} | 当前显示 {shown_count}/{total_count} 个样本 | 低通滤波: {filter_text}{extra_suffix}"
        )

    def _get_sample_record(self, sample_path: Path) -> SampleRecord:
        cached_record = self.sample_cache.get(sample_path)
        if cached_record is not None:
            return cached_record

        sample_record = load_sample_record(sample_path)
        self.sample_cache[sample_path] = sample_record
        return sample_record

    def _get_waveform(self, sample_record: SampleRecord, filter_enabled: bool) -> np.ndarray:
        cache_key = (sample_record.path, filter_enabled)
        cached_waveform = self.waveform_cache.get(cache_key)
        if cached_waveform is not None:
            return cached_waveform

        processor = CsiBufferProcessor(
            buffer_size=max(len(sample_record.events), 1),
            sample_rate=CSI_SAMPLE_RATE,
            valid_subcarriers=list(DEFAULT_VALID_SUBCARRIERS),
            display_unit=DEFAULT_UNIT,
            filter_enabled=filter_enabled,
        )
        waveform = processor.build_waveform_from_events(sample_record.events)
        self.waveform_cache[cache_key] = waveform
        return waveform

    def _render_empty_grid(self) -> None:
        for slot_index, tile in enumerate(self.tiles):
            tile.render_blank(slot_index)

    def _update_navigation_state(self) -> None:
        has_classes = bool(self.class_dirs)
        self.button_prev_class.setEnabled(has_classes and self.current_class_index > 0)
        self.button_next_class.setEnabled(
            has_classes and 0 <= self.current_class_index < len(self.class_dirs) - 1
        )
        self.combo_class.setEnabled(has_classes)
