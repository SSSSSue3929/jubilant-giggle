from __future__ import annotations

import ast
import csv
from dataclasses import dataclass
from pathlib import Path


IGNORED_CSV_NAMES = {"remark.csv", "keyframe_marks.csv", "csi_data.csv"}


@dataclass(frozen=True)
class SampleRecord:
    path: Path
    events: list[dict[str, object]]
    skipped_rows: int


@dataclass(frozen=True)
class DatasetCatalog:
    root_dir: Path
    session_dirs: list[Path]
    class_names: list[str]
    class_dirs_by_session: dict[Path, dict[str, Path]]
    initial_session_index: int


def _resolve_directory(path: Path, label: str) -> Path:
    resolved_path = path.expanduser().resolve()
    if not resolved_path.exists():
        raise FileNotFoundError(f"{label} does not exist: {resolved_path}")
    if not resolved_path.is_dir():
        raise NotADirectoryError(f"{label} is not a directory: {resolved_path}")
    return resolved_path


def _directory_contains_sample_csv_files(directory: Path) -> bool:
    return any(
        path.is_file() and path.suffix.lower() == ".csv" and path.name not in IGNORED_CSV_NAMES
        for path in directory.iterdir()
    )


def looks_like_session_dir(candidate_dir: Path) -> bool:
    if not candidate_dir.exists() or not candidate_dir.is_dir():
        return False

    child_dirs = [path for path in candidate_dir.iterdir() if path.is_dir()]
    if not child_dirs:
        return False

    return any(_directory_contains_sample_csv_files(path) for path in child_dirs)


def discover_class_directory_map(session_dir: Path) -> dict[str, Path]:
    resolved_session_dir = _resolve_directory(session_dir, "Session path")
    class_dir_map = {
        class_dir.name: class_dir.resolve()
        for class_dir in sorted(resolved_session_dir.iterdir())
        if class_dir.is_dir()
    }
    if not class_dir_map:
        raise ValueError(f"No class directories found under session: {resolved_session_dir}")
    return class_dir_map


def discover_class_directories(session_dir: Path) -> list[Path]:
    return list(discover_class_directory_map(session_dir).values())


def discover_session_directories(dataset_root: Path) -> list[Path]:
    resolved_root = _resolve_directory(dataset_root, "Dataset root")
    session_dirs: list[Path] = []

    for candidate_dir in sorted(resolved_root.iterdir()):
        if not candidate_dir.is_dir():
            continue
        if looks_like_session_dir(candidate_dir):
            session_dirs.append(candidate_dir.resolve())

    if not session_dirs:
        raise ValueError(f"No session directories found under root: {resolved_root}")
    return session_dirs


def discover_dataset_catalog(selected_path: Path) -> DatasetCatalog:
    resolved_path = _resolve_directory(selected_path, "Selected dataset path")
    preferred_session_name: str | None = None

    if looks_like_session_dir(resolved_path):
        dataset_root = resolved_path.parent.resolve()
        preferred_session_name = resolved_path.name
    else:
        dataset_root = resolved_path

    session_dirs = discover_session_directories(dataset_root)
    class_dirs_by_session: dict[Path, dict[str, Path]] = {}
    all_class_names: set[str] = set()

    for session_dir in session_dirs:
        class_dir_map = discover_class_directory_map(session_dir)
        class_dirs_by_session[session_dir] = class_dir_map
        all_class_names.update(class_dir_map)

    class_names = sorted(all_class_names)
    if not class_names:
        raise ValueError(f"No class directories found across sessions under: {dataset_root}")

    initial_session_index = 0
    if preferred_session_name is not None:
        for session_index, session_dir in enumerate(session_dirs):
            if session_dir.name == preferred_session_name:
                initial_session_index = session_index
                break

    return DatasetCatalog(
        root_dir=dataset_root,
        session_dirs=session_dirs,
        class_names=class_names,
        class_dirs_by_session=class_dirs_by_session,
        initial_session_index=initial_session_index,
    )


def collect_sample_csv_paths(class_dir: Path) -> list[Path]:
    return [
        path
        for path in sorted(class_dir.glob("*.csv"))
        if path.is_file() and path.name not in IGNORED_CSV_NAMES
    ]


def load_csi_events_from_csv(csi_csv_path: Path) -> tuple[list[dict[str, object]], int]:
    events: list[dict[str, object]] = []
    skipped_rows = 0

    with csi_csv_path.open("r", newline="", encoding="utf-8") as file_obj:
        reader = csv.DictReader(file_obj)
        for row in reader:
            try:
                raw_values = ast.literal_eval(row["data"])
                if not isinstance(raw_values, list):
                    raise ValueError("CSI data field is not a list.")

                events.append(
                    {
                        "data": [int(value) for value in raw_values],
                        "len": int(row["len"]),
                        "rssi": int(row.get("rssi", 0) or 0),
                    }
                )
            except Exception:
                skipped_rows += 1

    return events, skipped_rows


def load_sample_record(csi_csv_path: Path) -> SampleRecord:
    events, skipped_rows = load_csi_events_from_csv(csi_csv_path)
    return SampleRecord(path=csi_csv_path, events=events, skipped_rows=skipped_rows)
