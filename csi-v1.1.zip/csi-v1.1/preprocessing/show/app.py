from __future__ import annotations

import argparse
from pathlib import Path

try:
    from .multi_session_viewer import SessionSampleViewer
except ImportError:
    from multi_session_viewer import SessionSampleViewer


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Browse CSI samples across sessions with a lightweight 4x5 chart grid."
    )
    parser.add_argument(
        "--root",
        type=Path,
        help="Optional dataset root directory or a single session directory to load on startup.",
    )
    parser.add_argument(
        "--session",
        type=Path,
        help="Deprecated compatibility alias for passing a single session directory.",
    )
    parser.add_argument(
        "--quit-ms",
        type=int,
        default=0,
        help="Optional auto-quit delay in milliseconds, useful for smoke tests.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    initial_path = args.root or args.session
    viewer = SessionSampleViewer(initial_dataset_path=initial_path)
    viewer.show(quit_ms=args.quit_ms)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
