# preprocessing/show

`preprocessing/show` 用于浏览 `data/` 下不同 `session`、不同类别的 CSI 样本波形。

## 主要用途

- 快速检查某个数据集目录下的样本质量。
- 对比不同 `session`、不同类别的波形差异。
- 复用 PC 端上位机中的低通滤波与波形构建逻辑做离线展示。

## 启动方式

```powershell
conda run -n esp-csi python .\preprocessing\show\app.py --root .\data
```

如果直接给某个 `session` 目录，也会自动回退到其父目录并选中该 `session`：

```powershell
conda run -n esp-csi python .\preprocessing\show\app.py --session .\data\<session>
```

## 数据目录约定

```text
data/                               # 数据集根目录
└── <session>/                      # 单次采集会话目录
    └── <class>/                    # 动作类别目录
        └── *.csv                   # 单个样本文件
```

## 说明

- 默认入口为 `app.py`，当前会调用 `multi_session_viewer.py`。
- `低通滤波` 复用 `collect/PC/core/csi_processing.py` 中的 `CsiBufferProcessor`。
- `remark.csv`、`keyframe_marks.csv`、`csi_data.csv` 会自动忽略。

## 目录结构

```text
preprocessing/show/                 # 样本展示工具目录
├── app.py                          # 启动入口
├── loader.py                       # 样本扫描与读取
├── matplotlib_viewer.py            # Matplotlib 波形展示
├── multi_session_viewer.py         # 多 session 浏览界面
└── viewer.py                       # 单窗口样本浏览组件
```
