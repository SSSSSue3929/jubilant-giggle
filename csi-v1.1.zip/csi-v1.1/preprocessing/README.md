# preprocessing

`preprocessing` 存放训练前的数据增强工具和样本展示工具。

## 主要用途

- `enhancement/`：对 `data/` 下的样本做滑窗增强，输出到 `preprocessing/enhancement/output/`。
- `show/`：浏览 `data/` 下不同 session、不同类别的样本波形。

## 用法

生成增强样本：

```powershell
conda run -n esp-csi python ".\preprocessing\enhancement\augment.py" --input-dir .\data --output-dir ".\preprocessing\enhancement\output"
```

打开样本展示工具：

```powershell
conda run -n esp-csi python ".\preprocessing\show\app.py" --root .\data
```

## 目录结构

```text
preprocessing/                      # 预处理工具总目录
├── enhancement/                    # 样本增强工具
│   ├── dataset/                    # 增强过程使用的本地数据目录
│   └── output/                     # 增强样本输出目录
└── show/                           # 样本波形展示工具
```
